(function (root) {
  'use strict';
  const { C } = root.YB;
  const OUT = '#2B1D0E';
  const TAU = Math.PI * 2;

  function rng(seed) {
    let s = seed >>> 0;
    return () => { s = (s + 0x6D2B79F5) >>> 0; let t = s; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  function rr(ctx, x, y, w, h, r) {
    ctx.beginPath();
    if (ctx.roundRect) ctx.roundRect(x, y, w, h, r);
    else { ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
  }
  function circle(ctx, x, y, r) { ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); }

  const THEMES = {
    noon: {
      sky: ['#FFC93C', '#FFE27A', '#FFF4C7'], sun: { x: 1560, y: 170, r: 62, core: '#FFFBE3' },
      cloud: 'rgba(255,255,255,0.94)', cloudShade: 'rgba(255,200,90,0.30)',
      hills: ['#FFD45C', '#F7B733', '#E99A1C'], trees: '#D98A14', ground: ['#8A5524', '#5E3812'], pebble: 'rgba(60,30,8,0.45)',
      grass: ['#C2D234', '#93A81E', '#D8E64E'], haze: 'rgba(255,250,225,0.35)', stars: false,
      light: [0.42, -0.91], ambient: 'pollen', flock: true,
    },
    sunset: {
      sky: ['#FF8A3D', '#FFB45A', '#FFE3A0'], sun: { x: 1440, y: 600, r: 115, core: '#FFF1C4' },
      cloud: 'rgba(255,228,208,0.94)', cloudShade: 'rgba(255,120,80,0.35)',
      hills: ['#F7A452', '#E07B35', '#BF5A24'], trees: '#A94B1C', ground: ['#7A4219', '#4F270C'], pebble: 'rgba(40,18,4,0.45)',
      grass: ['#CDB833', '#A08A1E', '#E6D04A'], haze: 'rgba(255,205,150,0.30)', stars: false,
      light: [0.78, -0.62], ambient: 'leaves', flock: true,
    },
    dusk: {
      sky: ['#47388A', '#B45C8E', '#FFB45C'], sun: { x: 1400, y: 720, r: 125, core: '#FFE6A8' },
      cloud: 'rgba(252,205,225,0.78)', cloudShade: 'rgba(80,55,140,0.40)',
      hills: ['#A15E8C', '#77436F', '#543152'], trees: '#3F2440', ground: ['#5A3418', '#33190A'], pebble: 'rgba(20,8,2,0.5)',
      grass: ['#B9AB3C', '#877C22', '#D2C452'], haze: 'rgba(255,170,140,0.22)', stars: true,
      light: [0.86, -0.5], ambient: 'fireflies',
    },
    night: {
      sky: ['#10173A', '#27306E', '#5B5A9C'], sun: { x: 1500, y: 215, r: 72, core: '#FFF3BE', moon: true },
      cloud: 'rgba(150,165,225,0.45)', cloudShade: 'rgba(20,25,70,0.45)',
      hills: ['#3A4283', '#2B3168', '#1D214C'], trees: '#12153A', ground: ['#3F2D1E', '#1D120A'], pebble: 'rgba(10,5,0,0.5)',
      grass: ['#7C9C3C', '#566F24', '#9CBB50'], haze: 'rgba(120,135,230,0.16)', stars: true,
      light: [0.4, -0.92], ambient: 'fireflies',
    },

    winter: {
      sky: ['#9CC8F0', '#CFE6FA', '#F2F8FF'], sun: { x: 1520, y: 190, r: 64, core: '#FFFFFF' },
      cloud: 'rgba(255,255,255,0.95)', cloudShade: 'rgba(140,180,230,0.30)',
      hills: ['#E6F1FC', '#C9DDF2', '#A9C3E3'], trees: '#2F5E5A', ground: ['#6A5A50', '#3E322C'], pebble: 'rgba(30,26,40,0.45)',
      grass: ['#8E9A6A', '#5E6A44', '#A8B07C'], haze: 'rgba(235,245,255,0.40)', stars: false,
      light: [0.5, -0.87], ambient: 'snow', flock: false, snow: true, noFlowers: true,
    },

    volcano: {
      sky: ['#2A1424', '#7A2A2A', '#E0662E'], sun: { x: 430, y: 240, r: 70, core: '#FFD9A8' },
      cloud: 'rgba(120,80,80,0.75)', cloudShade: 'rgba(40,10,20,0.45)',
      hills: ['#5A2E2A', '#3E1F1E', '#2A1414'], trees: '#1E1010', ground: ['#3E2E2C', '#1A1212'], pebble: 'rgba(255,110,30,0.45)',
      grass: ['#6E5A3A', '#46381F', '#8A7246'], haze: 'rgba(255,110,60,0.18)', stars: true,
      light: [-0.55, -0.83], ambient: 'embers', flock: false, noFlowers: true, lava: true,
    },
  };
  let theme = THEMES.noon;
  function setTheme(name) { theme = THEMES[name] || THEMES.noon; themeName = THEMES[name] ? name : 'noon'; }

  const clouds = [];
  {
    const r = rng(42);
    for (let i = 0; i < 9; i++) clouds.push({ x: i * 465 + r() * 220 - 850, y: 15 + r() * 435, s: 0.69 + r() * 0.81, v: 3 + r() * 7 });
  }
  const starsPos = [];
  { const r = rng(5); for (let i = 0; i < 70; i++) starsPos.push({ x: r() * 2600 - 340, y: r() * 420 - 150, s: 1 + r() * 2.2, p: r() * 6 }); }

  const wideClouds = clouds.concat([
    { x: 3420, y: 130, s: 1.16, v: 5.4 }, { x: 3950, y: 264, s: 1.48, v: 7.5 },
    { x: 4310, y: 40, s: 0.91, v: 4.2 }, { x: 4750, y: 180, s: 1.12, v: 6.9 },
  ]);
  const wideStars = starsPos.concat(starsPos.map((s) => ({ ...s, x: s.x + 2530, p: s.p + 2.1 })));

  function hillY(x, base, amp, f, ph, amp2, f2) { return base - Math.sin(x * f + ph) * amp - Math.sin(x * f2 + ph * 2) * amp2; }
  function hillPath(ctx, x0, x1, base, amp, f, ph, amp2, f2) {
    ctx.beginPath(); ctx.moveTo(x0, C.GROUND_Y + 5);
    for (let x = x0; x <= x1 + 40; x += 40) ctx.lineTo(x, hillY(x, base, amp, f, ph, amp2, f2));
    ctx.lineTo(x1 + 40, C.GROUND_Y + 5); ctx.closePath();
  }

  const PAINT = {
    noon: {
      sky: ['#68A6CC', '#A5CFDB', '#F4EAC0', '#FFF0C7'],
      hills: [['#E8D3A5', '#D9C18A'], ['#C7C188', '#A6A368'], ['#A9AA60', '#798044']],
      tree: ['#778437', '#B5B756', '#505F30'], trunk: '#72562F',
      cloud: ['#FFFAEB', '#DFE7E8', '#A6B9C4'], haze: 'rgba(255,240,199,0.30)',
    },
    sunset: {
      sky: ['#5B4A8E', '#B55C8C', '#F0844E', '#FFC066'],
      hills: [['#C7768A', '#B0647C'], ['#94566A', '#7A4658'], ['#5E5A3A', '#46452A']],
      tree: ['#3F4A2A', '#C9853E', '#2C3420'], trunk: '#3A2414',
      cloud: ['#FFDCAB', '#F0A084', '#9E668F'], haze: 'rgba(255,170,130,0.24)',
    },
    dusk: {
      sky: ['#2C2A68', '#6E4A8E', '#D0708A', '#FFB060'],
      hills: [['#8E5E8E', '#7A4E7C'], ['#634A78', '#533E66'], ['#3E3A55', '#2E2C44']],
      tree: ['#2E2C46', '#A86E86', '#1E1E32'], trunk: '#241A26',
      cloud: ['#ECB9C4', '#C084A7', '#63558F'], haze: 'rgba(240,150,170,0.18)',
    },
    night: {
      sky: ['#0A0F2C', '#18214F', '#2E377A', '#4A4E92'],
      hills: [['#33407E', '#2A346C'], ['#242C62', '#1C2352'], ['#171C46', '#10143A']],
      tree: ['#10163A', '#4E62A8', '#0A0E2A'], trunk: '#0E1230',
      cloud: ['#92A0DC', '#626FB1', '#303D77'], haze: 'rgba(110,130,220,0.11)',
    },
    winter: {
      sky: ['#7FB2E6', '#A9D0F2', '#D6EAFB', '#F4F9FF'],
      hills: [['#EEF5FD', '#D8E6F6'], ['#DCE9F7', '#BFD3EC'], ['#C6D9EF', '#A2BCDD']],
      tree: ['#2E5E58', '#4E8A7E', '#1C3E3C'], trunk: '#4A3426', pines: true,
      cloud: ['#FFFFFF', '#E5EFFB', '#B4CAE4'], haze: 'rgba(240,247,255,0.30)',
    },
    volcano: {
      sky: ['#1C0E1A', '#4E1E2A', '#A8382A', '#F07A36'],
      hills: [['#6A2E2C', '#521F20'], ['#46201F', '#341616'], ['#2A1414', '#1C0C0C']],
      tree: ['#2A1A16', '#7A3A22', '#140A08'], trunk: '#1A0E0A', dead: true,
      cloud: ['#BA8071', '#765263', '#372337'], haze: 'rgba(255,100,50,0.16)', volcano: true,
    },
  };
  let themeName = 'noon';

  const LIGHT = {
    noon:   { rim: 'rgba(255,248,215,0.74)', tint: [255, 233, 172], shade: [30, 55, 53], shafts: [2.18, 0.70, 0.30] },
    sunset: { rim: 'rgba(255,205,145,0.77)', tint: [255, 194, 131], shade: [49, 26, 51], shafts: [-2.76, 0.42, 0.27] },
    dusk:   { rim: 'rgba(255,188,203,0.72)', tint: [255, 171, 169], shade: [33, 25, 61] },
    night:  { rim: 'rgba(198,220,255,0.71)', tint: [179, 205, 255], shade: [13, 20, 57] },
    winter: { rim: 'rgba(240,249,255,0.78)', tint: [225, 246, 255], shade: [39, 66, 102], shafts: [2.26, 0.64, 0.25] },
    volcano:{ rim: 'rgba(255,168,100,0.77)', tint: [255, 133, 57], shade: [53, 15, 28] },
  };
  const lightCfg = () => LIGHT[themeName] || LIGHT.noon;

  const BG = { X0: -700, Y0: -320, W: 3320, H: 1310 };
  const bgCache = new Map();

  function paintSunShafts(ctx, sun, light) {
    if (!light.shafts) return;
    const [direction, spread, intensity] = light.shafts;
    const field = document.createElement('canvas');
    const w = field.width = 720, h = field.height = 284;
    const g = field.getContext('2d');
    const pixels = g.createImageData(w, h), data = pixels.data;
    const angleCount = 1024, angular = new Float32Array(angleCount), r = rng(723);
    for (let i = 0; i < 10; i++) {
      const angle = direction + ((i + 0.25 + r() * 0.5) / 9 - 0.5) * 2 * spread;
      const width = 0.016 + r() * 0.033, amount = 0.30 + r() * 0.65;
      for (let k = 0; k < angleCount; k++) {
        const delta = (k * TAU / angleCount - angle + 2 * TAU + Math.PI) % TAU - Math.PI;
        angular[k] += amount * Math.exp(-0.5 * (delta / width) ** 2);
      }
    }
    for (let y = 0, j = 0; y < h; y++) for (let x = 0; x < w; x++, j += 4) {
      const dx = BG.X0 + (x + 0.5) * BG.W / w - sun.x;
      const dy = BG.Y0 + (y + 0.5) * BG.H / h - sun.y;
      const distance = Math.hypot(dx, dy);
      const angle = (Math.atan2(dy, dx) + TAU) % TAU * angleCount / TAU;
      const k = Math.floor(angle), blend = angle - k;
      const ray = angular[k] * (1 - blend) + angular[(k + 1) % angleCount] * blend;
      const start = Math.min(1, Math.max(0, (distance - sun.r * 0.62) / 220));
      const falloff = Math.max(0, 1 - distance / 1580);
      const alpha = intensity * ray * start * start * falloff ** 1.4;
      data[j] = light.tint[0]; data[j + 1] = light.tint[1]; data[j + 2] = light.tint[2]; data[j + 3] = 255 * alpha;
    }
    g.putImageData(pixels, 0, 0);
    ctx.save(); ctx.globalCompositeOperation = 'screen';
    ctx.drawImage(field, BG.X0, BG.Y0, BG.W, BG.H);
    ctx.restore();
  }

  function paintTree(ctx, x, y, size, P, sunX, r) {
    const dir = sunX > x ? 1 : -1;
    const height = size * (0.95 + r() * 0.53), lean = (r() - 0.5) * size * 0.65;
    const top = y - height, cy = top + size * 0.14;
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    const bark = ctx.createLinearGradient(x - size * 0.11, y, x + size * 0.11, y);
    bark.addColorStop(0, mix(P.trunk, P.tree[2], 0.53)); bark.addColorStop(1, mix(P.trunk, '#EEBC79', 0.25));
    ctx.strokeStyle = bark; ctx.lineWidth = size * 0.14;
    ctx.beginPath(); ctx.moveTo(x, y);
    ctx.bezierCurveTo(x + lean * 0.28, y - height * 0.42, x + lean * 0.98, y - height * 0.61, x + lean, top);
    ctx.stroke();
    ctx.lineWidth = size * 0.065;
    ctx.beginPath(); ctx.moveTo(x + lean * 0.57, y - height * 0.47);
    ctx.quadraticCurveTo(x + lean - size * 0.38, cy + size * 0.41, x + lean - size * 0.46, cy + size * 0.19);
    ctx.moveTo(x + lean * 0.72, y - height * 0.56);
    ctx.quadraticCurveTo(x + lean + size * 0.36, cy + size * 0.30, x + lean + size * 0.53, cy + size * 0.06);
    ctx.stroke();

    for (let i = 0; i < 4; i++) {
      const bx = x + lean + (i - 1.5) * size * 0.31, by = cy - Math.sin((i + 0.5) / 4 * Math.PI) * size * 0.25;
      const width = size * (0.34 + r() * 0.22), depth = width * (0.62 + r() * 0.33);
      const leaves = ctx.createRadialGradient(bx + dir * width * 0.39, by - depth * 0.46, 0, bx, by, width * 1.08);
      leaves.addColorStop(0, P.tree[1]); leaves.addColorStop(0.56, P.tree[0]); leaves.addColorStop(1, P.tree[2]);
      ctx.fillStyle = leaves; ctx.beginPath();
      for (let k = 0; k < 30; k++) {
        const a = k * TAU / 30, jag = 0.86 + r() * 0.19;
        const vx = bx + Math.cos(a) * width * jag, vy = by + Math.sin(a) * depth * jag;
        if (k === 0) ctx.moveTo(vx, vy); else ctx.lineTo(vx, vy);
      }
      ctx.closePath(); ctx.fill();
      ctx.save(); ctx.clip();
      for (let k = 0; k < 23; k++) {
        const u = (r() - 0.5) * 2, v = (r() - 0.5) * 2, leaf = size * (0.018 + r() * 0.035);
        ctx.fillStyle = u * dir - v > 0.3 ? P.tree[1] : P.tree[2];
        ctx.globalAlpha = 0.18 + r() * 0.33;
        ctx.beginPath(); ctx.ellipse(bx + u * width, by + v * depth, leaf, leaf * 0.55, u - v, 0, TAU); ctx.fill();
      }
      ctx.restore();
    }
    ctx.lineCap = 'butt';
  }

  function paintPine(ctx, x, y, size, P, sunX, r) {
    const height = size * (1.55 + r() * 0.49), width = size * 0.60;
    const side = sunX > x ? 1 : -1;
    ctx.fillStyle = P.trunk; ctx.fillRect(x - size * 0.071, y - height * 0.19, size * 0.142, height * 0.20);
    for (let i = 3; i >= 0; i--) {
      const top = y - height + i * height * 0.172, bottom = top + height * (0.46 - i * 0.026);
      const w = width * (0.44 + i * 0.22), length = bottom - top;
      const tier = ctx.createLinearGradient(x - side * w, bottom, x + side * w * 0.67, top + length * 0.2);
      tier.addColorStop(0, P.tree[2]); tier.addColorStop(0.55, P.tree[0]); tier.addColorStop(1, P.tree[1]);
      ctx.fillStyle = tier; ctx.beginPath(); ctx.moveTo(x - w * 0.032, top);
      ctx.quadraticCurveTo(x + w * 0.31, bottom - length * 0.38, x + w, bottom - length * 0.08);
      ctx.lineTo(x + w * 0.69, bottom - length * 0.09);
      ctx.lineTo(x + w * 0.81, bottom + length * 0.075);
      ctx.quadraticCurveTo(x, bottom + length * 0.22, x - w * 0.87, bottom + length * 0.01);
      ctx.lineTo(x - w * 0.63, bottom - length * 0.18); ctx.lineTo(x - w, bottom - length * 0.13);
      ctx.quadraticCurveTo(x - w * 0.31, bottom - length * 0.43, x - w * 0.032, top); ctx.fill();
      const powder = ctx.createLinearGradient(0, top, 0, bottom);
      powder.addColorStop(0, '#F9FCFF'); powder.addColorStop(1, '#C1DCE8');
      ctx.fillStyle = powder; ctx.beginPath(); ctx.moveTo(x, top + 2);
      ctx.quadraticCurveTo(x + w * 0.33, bottom - length * 0.36, x + w * 0.70, bottom - length * 0.21);
      ctx.quadraticCurveTo(x + w * 0.43, bottom - length * 0.06, x + w * 0.11, bottom - length * 0.23);
      ctx.quadraticCurveTo(x - w * 0.03, bottom - length * 0.34, x - w * 0.40, bottom - length * 0.26);
      ctx.quadraticCurveTo(x - w * 0.13, bottom - length * 0.64, x, top + 2); ctx.fill();
    }
  }

  function paintDead(c, x, y, s, P, sunX, r) {
    c.strokeStyle = P.tree[0]; c.lineCap = 'round';
    const H = s * (1.1 + r() * 0.5);
    c.lineWidth = s * 0.13; c.beginPath(); c.moveTo(x, y); c.quadraticCurveTo(x + (r() - 0.5) * s * 0.3, y - H * 0.5, x + (r() - 0.5) * s * 0.25, y - H); c.stroke();
    c.lineWidth = s * 0.06;
    for (let i = 0; i < 4; i++) {
      const hy = y - H * (0.4 + i * 0.15), d = i % 2 ? 1 : -1, L = s * (0.35 - i * 0.05);
      c.beginPath(); c.moveTo(x, hy); c.quadraticCurveTo(x + d * L * 0.5, hy - L * 0.2, x + d * L, hy - L * 0.6); c.stroke();
    }
    c.lineCap = 'butt';
  }

  function paintVolcano(c) {
    const cx = 1180, base = 760, top = 300, bw = 760, tw = 120;
    const g = c.createLinearGradient(0, top, 0, base);
    g.addColorStop(0, '#4A2422'); g.addColorStop(1, '#2A1416');
    c.fillStyle = g; c.beginPath();
    c.moveTo(cx - bw, base); c.quadraticCurveTo(cx - bw * 0.35, base - 120, cx - tw, top); c.lineTo(cx + tw, top); c.quadraticCurveTo(cx + bw * 0.35, base - 120, cx + bw, base); c.closePath(); c.fill();
    c.save(); c.clip();

    const rock = rng(681);
    for (let i = 0; i < 13; i++) {
      const rootX = cx - tw + rock() * tw * 2, endX = cx - bw + i * bw / 6;
      const rim = 25 + rock() * 90;
      const slope = c.createLinearGradient(rootX, top, endX, base);
      slope.addColorStop(0, i % 2 ? 'rgba(41,15,21,0.30)' : 'rgba(247,98,53,0.16)');
      slope.addColorStop(1, 'rgba(31,14,21,0.05)');
      c.fillStyle = slope; c.beginPath(); c.moveTo(rootX, top);
      c.bezierCurveTo(rootX + (endX - rootX) * 0.17, top + 140, endX - rim, base - 95, endX, base);
      c.lineTo(endX + rim, base);
      c.quadraticCurveTo(rootX + (endX - rootX) * 0.20, top + 175, rootX + 12, top);
      c.fill();
    }

    c.lineCap = 'round';
    for (const [dx, len, w] of [[-72, 308, 13], [18, 377, 16], [77, 219, 10]]) {
      c.beginPath(); c.moveTo(cx + dx * 0.76, top);
      c.bezierCurveTo(cx + dx * 0.59 + 35, top + len * 0.4, cx + dx * 1.68 - 49, top + len * 0.48, cx + dx * 1.63, top + len * 0.71);
      c.quadraticCurveTo(cx + dx * 2.04 + 37, top + len * 0.83, cx + dx * 2.32, top + len);
      const flow = c.createLinearGradient(0, top, 0, top + len);
      flow.addColorStop(0, '#FFF3AC'); flow.addColorStop(0.36, '#FFC460');
      flow.addColorStop(0.76, '#F46E33'); flow.addColorStop(1, 'rgba(170,40,24,0)');
      c.strokeStyle = flow;
      for (const [width, opacity] of [[3.1, 0.10], [1.65, 0.22], [0.95, 0.78], [0.28, 1]]) {
        c.globalAlpha = opacity; c.lineWidth = w * width; c.stroke();
      }
    }
    c.restore();

    const cg = c.createRadialGradient(cx, top, 10, cx, top, 260);
    cg.addColorStop(0, 'rgba(255,200,100,0.9)'); cg.addColorStop(0.25, 'rgba(255,110,40,0.45)'); cg.addColorStop(1, 'rgba(255,80,30,0)');
    c.fillStyle = cg; c.beginPath(); c.arc(cx, top, 260, 0, TAU); c.fill();
    c.fillStyle = '#FFAB48'; c.beginPath(); c.ellipse(cx, top + 3, tw * 0.95, 13, 0, 0, TAU); c.fill();
    c.fillStyle = '#FFF2A4'; c.beginPath(); c.ellipse(cx + 7, top + 4, tw * 0.72, 5, 0, 0, TAU); c.fill();
  }

  function buildBackdrop(name, sc, width) {
    const extra = width - C.W;
    const bg = { ...BG, W: BG.W + extra };
    const key = name + '|' + sc + '|' + width;
    if (bgCache.has(key)) return bgCache.get(key);
    if (typeof document === 'undefined') return null;
    for (const k of bgCache.keys()) if (k.split('|')[1] !== String(sc)) bgCache.delete(k);
    const T = THEMES[name] || THEMES.noon, P = PAINT[name] || PAINT.noon, S = T.sun, light = LIGHT[name];
    const cv = document.createElement('canvas'); cv.width = Math.round(bg.W * sc); cv.height = Math.round(bg.H * sc);
    const c = cv.getContext('2d');
    c.scale(sc, sc); c.translate(-bg.X0, -bg.Y0);
    const x0 = bg.X0, x1 = bg.X0 + bg.W, r = rng(77 + name.length);

    const g = c.createLinearGradient(0, bg.Y0, 0, 900);
    g.addColorStop(0, P.sky[0]); g.addColorStop(0.42, P.sky[1]); g.addColorStop(0.75, P.sky[2]); g.addColorStop(1, P.sky[3]);
    c.fillStyle = g; c.fillRect(x0, bg.Y0, bg.W, bg.H);

    paintSunShafts(c, S, light);
    const tint = light.tint.join(',');
    c.save(); c.globalCompositeOperation = 'screen';
    for (const [scale, intensity] of [[9.4, S.moon ? 0.28 : 0.54], [2.8, S.moon ? 0.28 : 0.87]]) {
      const radius = S.r * scale;
      const glow = c.createRadialGradient(S.x, S.y, S.r * 0.45, S.x, S.y, radius);
      glow.addColorStop(0, `rgba(${tint},${intensity})`);
      glow.addColorStop(0.2, `rgba(${tint},${intensity * 0.42})`);
      glow.addColorStop(0.52, `rgba(${tint},${intensity * 0.11})`);
      glow.addColorStop(1, `rgba(${tint},0)`);
      c.fillStyle = glow; circle(c, S.x, S.y, radius); c.fill();
    }
    c.restore();
    const disk = c.createRadialGradient(S.x - S.r * 0.24, S.y - S.r * 0.26, 0, S.x, S.y, S.r);
    disk.addColorStop(0, '#FFFFFF'); disk.addColorStop(0.64, S.core); disk.addColorStop(1, S.core);
    c.fillStyle = disk; circle(c, S.x, S.y, S.r); c.fill();
    if (S.moon) {
      c.fillStyle = 'rgba(214,180,96,0.38)';
      [[-22, -16, 15], [24, 8, 11], [-6, 30, 8], [14, -34, 6]].forEach(([dx, dy, rr2]) => { c.beginPath(); c.arc(S.x + dx, S.y + dy, rr2, 0, TAU); c.fill(); });
    }

    if (P.volcano) paintVolcano(c);
    if (P.pines) paintWinterPeaks(c, x0, x1);

    if (!P.pines && !P.volcano) paintDistantRidge(c, P, S, bg);
    const layers = [
      { base: 640, amp: 46, f: 0.0032, ph: 0.6, a2: 22, f2: 0.009, count: 22, scale: 21, depth: 0.28 },
      { base: 739, amp: 52, f: 0.0045, ph: 2.0, a2: 18, f2: 0.012, count: 15, scale: 36, depth: 0.18 },
      { base: 838, amp: 41, f: 0.0062, ph: 3.9, a2: 12, f2: 0.018, count: 10, scale: 55, depth: 0.08 },
    ];
    const terrain = layers.map((layer, i) => {
      const y = layer.base - 270, height = 995 - y;
      const tile = document.createElement('canvas');
      tile.width = cv.width; tile.height = Math.ceil(height * sc);
      const c = tile.getContext('2d'); c.scale(sc, sc); c.translate(-x0, -y);
      const { base, amp, f, ph, a2, f2 } = layer;
      const ridge = (x) => hillY(x, base, amp, f, ph, a2, f2);
      const colors = P.hills[i];
      const grade = c.createLinearGradient(0, base - amp - a2, 0, base + 170);
      grade.addColorStop(0, colors[0]); grade.addColorStop(1, colors[1]);
      c.fillStyle = grade; c.beginPath(); c.moveTo(x0, 990);
      for (let x = x0; x <= x1 + 12; x += 12) c.lineTo(x, ridge(x));
      c.lineTo(x1 + 25, 990); c.closePath(); c.fill();
      c.save(); c.clip();
      paintHillside(c, P, S, ridge, i, bg);
      c.restore();

      const painter = P.pines ? paintPine : P.dead ? paintDead : paintTree;
      const groveCount = Math.round(layer.count * bg.W / BG.W);
      for (let j = 0; j < groveCount; j++) {
        const grove = x0 + (j + 0.12 + r() * 0.72) * bg.W / groveCount;
        const count = 1 + Math.floor(r() * 4);
        const trees = Array.from({ length: count }, (_, k) => ({
          x: grove + (k - (count - 1) / 2) * layer.scale * (0.7 + r() * 0.48),
          size: layer.scale * (0.66 + r() * 0.79),
        }));
        trees.sort((a, b) => a.size - b.size);
        for (const { x, size } of trees) painter(c, x, ridge(x) + size * 0.30, size, P, S.x, r);
      }
      if (i < 2) {
        c.globalCompositeOperation = 'source-atop';
        const haze = c.createLinearGradient(0, base - 130, 0, base + 110);
        haze.addColorStop(0, 'rgba(255,255,255,0)'); haze.addColorStop(1, P.haze);
        c.fillStyle = haze; c.fillRect(x0, base - 130, bg.W, 990 - base + 130);
      }
      return { tile, y, height, depth: layer.depth };
    });
    if (bgCache.size >= 2) bgCache.delete(bgCache.keys().next().value);
    const backdrop = { sky: cv, terrain, width: bg.W };
    bgCache.set(key, backdrop);
    return backdrop;
  }

  function paintDistantRidge(ctx, P, sun, bg) {
    const r = rng(183), start = bg.X0, end = start + bg.W;
    for (let layer = 0; layer < 2; layer++) {
      const base = 622 + layer * 58, points = [];
      for (let x = start - 150; x < end + 250; x += 65 + r() * 138) {
        const saddle = Math.exp(-(((x - sun.x) / 420) ** 2));
        points.push([x, base - (36 + r() * 108) * (1 - 0.78 * saddle)]);
      }
      const color = ctx.createLinearGradient(0, base - 142, 0, base);
      color.addColorStop(0, mix(P.hills[0][0], P.sky[1], layer ? 0.36 : 0.63));
      color.addColorStop(1, mix(P.hills[0][0], P.sky[3], 0.53));
      ctx.fillStyle = color; ctx.beginPath(); ctx.moveTo(start - 150, 820);
      ctx.lineTo(points[0][0], points[0][1]);
      for (let i = 1; i < points.length; i++) {
        const [x, y] = points[i], [px, py] = points[i - 1];
        ctx.quadraticCurveTo(px, py, (px + x) / 2, (py + y) / 2);
      }
      ctx.lineTo(end + 250, 820); ctx.fill();
    }
  }

  function paintHillside(ctx, P, sun, ridge, layer, bg) {
    const r = rng(428 + layer * 72), colors = P.hills[layer];
    const stripe = ctx.createRadialGradient(sun.x, sun.y + 190, 80, sun.x, sun.y + 415, 1300);
    stripe.addColorStop(0, 'rgba(255,217,161,0.31)');
    stripe.addColorStop(0.52, 'rgba(255,227,181,0.065)');
    stripe.addColorStop(1, 'rgba(255,225,175,0)');
    ctx.fillStyle = stripe; ctx.fillRect(bg.X0, 440, bg.W, 560);
    for (let j = 0; j < Math.round(52 * bg.W / BG.W); j++) {
      const x = bg.X0 + r() * bg.W, w = 22 + r() * 150, y = ridge(x) + 4 + r() * 145;
      ctx.fillStyle = j % 2 ? mix(colors[0], colors[1], 0.54) : mix(colors[0], P.sky[3], 0.41);
      ctx.globalAlpha = 0.13 + r() * 0.17;
      ctx.beginPath(); ctx.moveTo(x - w, y + w * 0.15);
      ctx.quadraticCurveTo(x, y - w * 0.36, x + w, y - w * 0.09);
      ctx.quadraticCurveTo(x - w * 0.12, y + w * 0.12, x - w, y + w * 0.15); ctx.fill();
    }
    ctx.globalAlpha = 1;
  }

  function paintWinterPeaks(ctx, x0, x1) {
    const r = rng(442);
    const base = 695;
    for (let x = x0 + 160; x < x1; x += 360 + r() * 150) {
      const top = 310 + r() * 185, width = 265 + r() * 240, shoulder = (base - top) * 0.37;
      const rock = ctx.createLinearGradient(0, top, 0, base);
      rock.addColorStop(0, '#9CBBDA'); rock.addColorStop(1, '#D9E8F5');
      ctx.fillStyle = rock;
      ctx.beginPath(); ctx.moveTo(x - width, base);
      ctx.lineTo(x - width * 0.48, top + shoulder * 1.23); ctx.lineTo(x - width * 0.26, top + shoulder * 0.98);
      ctx.lineTo(x, top); ctx.lineTo(x + width * 0.34, top + shoulder * 0.8);
      ctx.lineTo(x + width * 0.52, top + shoulder * 1.47); ctx.lineTo(x + width, base); ctx.fill();
      ctx.fillStyle = '#E8F4FA';
      ctx.beginPath(); ctx.moveTo(x, top); ctx.lineTo(x + width * 0.34, top + shoulder * 0.8);
      ctx.lineTo(x + width * 0.52, top + shoulder * 1.47); ctx.lineTo(x + width * 0.10, top + shoulder * 0.91);
      ctx.lineTo(x + width * 0.03, top + shoulder * 1.24); ctx.lineTo(x - width * 0.26, top + shoulder * 0.98); ctx.fill();
    }
  }

  const cloudSprites = new Map();
  function cloudSet(name) {
    if (cloudSprites.has(name)) return cloudSprites.get(name);
    if (typeof document === 'undefined') return null;
    const P = PAINT[name] || PAINT.noon, set = [], r = rng(500 + name.length);
    for (let n = 0; n < 6; n++) {
      const W = 300 + r() * 220, H = 150 + r() * 50, cv = document.createElement('canvas');
      const puffs = [];
      const cnt = 9 + Math.floor(r() * 6);
      for (let i = 0; i < cnt; i++) {
        const t = i / (cnt - 1), px = W * (0.12 + 0.76 * t) + (r() - 0.5) * 20;
        const rad = (H * 0.3 + r() * H * 0.18) * (1 - Math.abs(t - 0.5) * 0.85);
        puffs.push([px, H * 0.72 - rad * (0.55 + r() * 0.5), rad]);
      }

      let bx0 = W * 0.08, bx1 = W * 0.92, by0 = H * 0.6, by1 = H * 0.86;
      for (const [x, y, rad] of puffs) { bx0 = Math.min(bx0, x - rad - 4); bx1 = Math.max(bx1, x + rad + 4); by0 = Math.min(by0, y - rad - 4); by1 = Math.max(by1, y + rad * 1.12 + 4); }
      const pad = 6, ox = Math.floor(bx0) - pad, oy = Math.floor(by0) - pad;
      cv.width = Math.ceil(bx1 - ox + pad); cv.height = Math.ceil(by1 - oy + pad);
      const c = cv.getContext('2d'); c.translate(-ox, -oy);
      c.beginPath();
      c.ellipse(W / 2, H * 0.73, W * 0.42, H * 0.15, 0, 0, TAU);
      for (const [x, y, rad] of puffs) { c.moveTo(x + rad, y); c.arc(x, y, rad, 0, TAU); }
      c.clip();
      const shade = c.createLinearGradient(0, by0, 0, by1);
      shade.addColorStop(0, P.cloud[0]); shade.addColorStop(0.60, P.cloud[1]); shade.addColorStop(1, P.cloud[2]);
      c.fillStyle = shade; c.fillRect(ox, oy, cv.width, cv.height);
      for (const [x, y, rad] of puffs) {
        const lobe = c.createRadialGradient(x + rad * 0.22, y - rad * 0.37, 0, x, y, rad);
        lobe.addColorStop(0, mix(P.cloud[0], P.cloud[1], 0.15));
        lobe.addColorStop(1, 'rgba(255,255,255,0)');
        c.globalAlpha = 0.64; c.fillStyle = lobe; circle(c, x, y, rad); c.fill();
      }

      set.push({ cv, W: cv.width, H: cv.height, ax: W / 2 - ox, ay: H * 0.6 - oy });
    }
    cloudSprites.set(name, set);
    return set;
  }

  let bgScale = 0.7;
  function setBgScale(px) { bgScale = Math.max(0.45, Math.min(0.9, Math.round(px * 4) / 4)); }

  function drawBackdropLayer(ctx, image, x, y, w, h, left, right) {
    ctx.drawImage(image, x, y, w, h);

    if (left < x) ctx.drawImage(image, 0, 0, 1, image.height, left, y, x - left + 0.3, h);
    if (right > x + w) {
      ctx.drawImage(image, image.width - 1, 0, 1, image.height, x + w - 0.3, y, right - x - w + 0.3, h);
    }
  }

  function background(ctx, v, t, parallax = 0, width = C.W) {
    const { x0, x1, y0, y1 } = v, T = theme, P = PAINT[themeName] || PAINT.noon;
    const bd = buildBackdrop(themeName, bgScale, width);
    if (bd) drawBackdropLayer(ctx, bd.sky, BG.X0, BG.Y0, bd.width, BG.H, x0, x1);
    if (y0 < BG.Y0) { ctx.fillStyle = P.sky[0]; ctx.fillRect(x0, y0, x1 - x0, BG.Y0 - y0 + 1); }

    if (T.stars) {
      for (const s of width > C.W ? wideStars : starsPos) {
        if (s.x < x0 || s.x > x1 || s.y > 420) continue;
        ctx.globalAlpha = 0.25 + 0.62 * (0.5 + 0.5 * Math.sin(t * 1.3 + s.p));
        ctx.fillStyle = s.p > 3 ? '#D2DFFF' : '#FFF6D8';
        if (s.s > 2.85) star(ctx, s.x, s.y, s.s * 1.8);
        else circle(ctx, s.x, s.y, s.s * 0.68);
        ctx.fill();
      }
      ctx.globalAlpha = 1;
    }

    if (P.volcano) {
      for (let i = 0; i < 9; i++) {
        const k = ((t * 0.06 + i / 9) % 1), x = 1180 + Math.sin(k * 5 + i) * 30 + k * 260, y = 290 - k * 520, rad = 40 + k * 120;
        ctx.globalAlpha = (1 - k) * 0.47 * Math.min(1, k * 7);
        const smoke = ctx.createRadialGradient(x, y + rad * 0.12, 0, x, y, rad);
        smoke.addColorStop(0, '#533141'); smoke.addColorStop(0.43, '#533141'); smoke.addColorStop(1, 'rgba(83,49,65,0)');
        ctx.fillStyle = smoke; circle(ctx, x, y, rad); ctx.fill();
      }
      ctx.globalAlpha = 1;
    }

    const set = cloudSet(themeName);
    if (set) {
      const span = 4550 + width - C.W, origin = -1320;
      const coverage = width > C.W ? wideClouds : clouds;
      coverage.forEach((cl, i) => {
        const sp = set[i % set.length], w = sp.W * cl.s, h = sp.H * cl.s;
        const cx = origin + ((cl.x + t * cl.v - origin) % span + span) % span;
        if (cx + w < x0 || cx - w > x1) return;
        ctx.globalAlpha = T.sun.moon ? 0.66 : 0.91;
        ctx.drawImage(sp.cv, cx - sp.ax * cl.s, cl.y - sp.ay * cl.s, w, h);
      });
      ctx.globalAlpha = 1;
    }

    if (T.flock) {
      const fw = (x1 - x0) + 500, fx = x0 - 250 + ((t * 38) % fw), fy = 250 + Math.sin(t * 0.4) * 24;
      ctx.strokeStyle = 'rgba(70,35,10,0.5)'; ctx.lineWidth = 3; ctx.lineCap = 'round';
      for (let i = 0; i < 5; i++) {
        const bx = fx - Math.abs(i - 2) * 34 - (i % 2) * 6, by = fy + (i - 2) * 20, w = Math.sin(t * 7 + i) * 7;
        ctx.beginPath(); ctx.moveTo(bx - 11, by - 4 + w); ctx.quadraticCurveTo(bx - 4, by - 7, bx, by); ctx.quadraticCurveTo(bx + 4, by - 7, bx + 11, by - 4 + w); ctx.stroke();
      }
      ctx.lineCap = 'butt';
    }

    if (bd) for (const { tile, y, height, depth } of bd.terrain) {
      drawBackdropLayer(ctx, tile, BG.X0 + parallax * depth, y, bd.width, height, x0, x1);
    }

    now = t;
    fillSoil(ctx, x0, C.GROUND_Y, x1 - x0, y1 - C.GROUND_Y + 2, C.GROUND_Y);
    grassStrip(ctx, x0, x1, C.GROUND_Y, true);
  }

  const TILE_W = 512, TILE_H = 320;
  const soilCache = new Map();
  function soilPattern(ctx) {
    const T = theme, key = T.ground.join() + T.pebble + (T.lava ? '|lava' : '');
    if (soilCache.has(key)) return soilCache.get(key);
    if (typeof document === 'undefined') return null;
    const cv = document.createElement('canvas'); cv.width = TILE_W; cv.height = TILE_H;
    const c = cv.getContext('2d'), r = rng(2024);

    const wrap = (fn) => { for (const dx of [-TILE_W, 0, TILE_W]) { c.save(); c.translate(dx, 0); fn(); c.restore(); } };
    const g = c.createLinearGradient(0, 0, 0, TILE_H);
    g.addColorStop(0, T.ground[0]); g.addColorStop(0.55, mix(T.ground[0], T.ground[1], 0.6)); g.addColorStop(1, T.ground[1]);
    c.fillStyle = g; c.fillRect(0, 0, TILE_W, TILE_H);

    for (let k = 0; k < 5; k++) {
      const y = 40 + k * 58 + r() * 14, amp = 4 + r() * 6, ph = r() * 6.28, dark = k % 2 === 0;
      c.fillStyle = dark ? 'rgba(0,0,0,0.10)' : 'rgba(255,230,190,0.05)';
      c.beginPath(); c.moveTo(0, y);
      for (let x = 0; x <= TILE_W; x += 16) c.lineTo(x, y + Math.sin((x / TILE_W) * TAU * 2 + ph) * amp);
      for (let x = TILE_W; x >= 0; x -= 16) c.lineTo(x, y + 10 + r() * 6 + Math.sin((x / TILE_W) * TAU * 2 + ph) * amp);
      c.closePath(); c.fill();
    }

    for (let i = 0; i < 700; i++) {
      const x = r() * TILE_W, y = r() * TILE_H, z = 0.8 + r() * 1.8;
      c.fillStyle = r() < 0.55 ? 'rgba(0,0,0,0.18)' : 'rgba(255,225,170,0.10)';
      c.fillRect(x, y, z, z);
    }

    c.lineCap = 'round';
    for (let i = 0; i < 16; i++) {
      const x = r() * TILE_W, len = 14 + r() * 30;
      wrap(() => {
        c.strokeStyle = 'rgba(40,20,5,0.45)'; c.lineWidth = 1.2 + r() * 1.2;
        c.beginPath(); c.moveTo(x, 14); c.quadraticCurveTo(x + (r() - 0.5) * 20, 14 + len * 0.6, x + (r() - 0.5) * 18, 14 + len);
        if (r() < 0.6) { c.moveTo(x + 1, 18 + len * 0.3); c.lineTo(x + (r() < 0.5 ? -8 : 8), 22 + len * 0.55); }
        c.stroke();
      });
    }

    if (T.lava) {
      c.lineCap = 'round'; c.lineJoin = 'round';
      for (let i = 0; i < 9; i++) {
        const x = r() * TILE_W, y = 30 + r() * (TILE_H - 60), pts = [[x, y]];
        for (let k = 0; k < 5; k++) { const [px, py] = pts[pts.length - 1]; pts.push([px + 10 + r() * 22, py + (r() - 0.5) * 26]); }
        wrap(() => {
          for (const [col, lw] of [['rgba(255,80,20,0.25)', 9], ['rgba(255,110,30,0.85)', 3.2], ['rgba(255,220,120,0.9)', 1.2]]) {
            c.strokeStyle = col; c.lineWidth = lw; c.beginPath(); pts.forEach(([px, py], k) => (k ? c.lineTo(px, py) : c.moveTo(px, py))); c.stroke();
          }
        });
      }
    }

    for (let i = 0; i < 46; i++) {
      const x = r() * TILE_W, y = 26 + r() * (TILE_H - 40), rx = 3 + r() * (r() < 0.15 ? 15 : 7), ry = rx * (0.55 + r() * 0.3), a = (r() - 0.5) * 0.8;
      const stone = r() < 0.35;
      wrap(() => {
        c.save(); c.translate(x, y); c.rotate(a);
        c.fillStyle = stone ? mix(T.ground[0], 'rgb(160,150,135)', 0.55) : T.pebble;
        c.beginPath(); c.ellipse(0, 0, rx, ry, 0, 0, TAU); c.fill();
        c.fillStyle = 'rgba(0,0,0,0.22)'; c.beginPath(); c.ellipse(rx * 0.15, ry * 0.35, rx * 0.85, ry * 0.55, 0, 0, TAU); c.fill();
        c.fillStyle = 'rgba(255,240,210,' + (stone ? 0.35 : 0.14) + ')'; c.beginPath(); c.ellipse(-rx * 0.3, -ry * 0.35, rx * 0.4, ry * 0.25, -0.3, 0, TAU); c.fill();
        c.restore();
      });
    }

    for (let i = 0; i < 4; i++) {
      const x = 40 + i * 128 + r() * 60, y = 34 + r() * 26, rx = 16 + r() * 12, ry = rx * (0.55 + r() * 0.15);
      wrap(() => {
        c.save(); c.translate(x, y);
        const sg = c.createLinearGradient(0, -ry, 0, ry);
        sg.addColorStop(0, mix('#B6AA94', T.ground[0], 0.35)); sg.addColorStop(1, mix('#504A47', T.ground[1], 0.37));
        c.fillStyle = sg; c.beginPath(); c.moveTo(-rx, 0);
        c.lineTo(-rx * 0.71, -ry * 0.76); c.lineTo(rx * 0.12, -ry); c.lineTo(rx * 0.73, -ry * 0.46);
        c.lineTo(rx, ry * 0.46); c.lineTo(rx * 0.42, ry); c.lineTo(-rx * 0.48, ry * 0.88); c.closePath(); c.fill();
        c.strokeStyle = 'rgba(30,15,0,0.29)'; c.lineWidth = 1.5; c.stroke();
        c.fillStyle = 'rgba(239,224,193,0.30)'; c.beginPath();
        c.moveTo(-rx * 0.71, -ry * 0.76); c.lineTo(rx * 0.12, -ry); c.lineTo(rx * 0.73, -ry * 0.46);
        c.lineTo(rx * 0.3, -ry * 0.08); c.lineTo(-rx * 0.37, -ry * 0.15); c.fill();
        c.restore();
      });
    }

    for (let i = 0; i < 3; i++) {
      const x = 60 + r() * (TILE_W - 120), y = 120 + r() * 170;
      c.strokeStyle = 'rgba(255,235,200,0.22)'; c.lineWidth = 2;
      c.beginPath(); for (let k = 0; k < 26; k++) { const a = k * 0.45, rad = 1 + k * 0.32; c.lineTo(x + Math.cos(a) * rad, y + Math.sin(a) * rad); } c.stroke();
    }
    const pat = ctx.createPattern(cv, 'repeat');
    soilCache.set(key, pat);
    return pat;
  }

  function fillSoil(ctx, x, y, w, h, top) {
    const pat = soilPattern(ctx), T = theme;
    if (!pat) { ctx.fillStyle = T.ground[0]; ctx.fillRect(x, y, w, h); return; }
    ctx.save(); ctx.translate(0, top); ctx.fillStyle = pat; ctx.fillRect(x, y - top, w, h); ctx.restore();

    if (y + h > top + TILE_H) { ctx.fillStyle = T.ground[1]; ctx.fillRect(x, top + TILE_H, w, y + h - top - TILE_H); }
  }

  let now = 0, detail = 1;
  function setDetail(low) { detail = low ? 2 : 1; }

  function wind(x, t) {
    const gust = Math.pow(Math.max(0, Math.sin(t * 0.42 - x * 0.0016)), 6);
    return 0.10 + Math.sin(t * 1.35 + x * 0.0065) * 0.11 + Math.sin(t * 3.1 + x * 0.021) * 0.04 + gust * 0.32;
  }

  const hash = (n) => { const v = Math.sin(n * 127.1 + 311.7) * 43758.5453; return v - Math.floor(v); };

  const GT = 480, GUP = 50, GDN = 28, GH = GUP + GDN, GSC = 1.5, GN = 12, WMIN = -0.06, WMAX = 0.58, CHUNK = 16;
  const grassCache = new Map();
  function drawBlades(c, y, lean0, x0, x1, wrapW) {
    const G = theme.grass, hx = (x) => (wrapW ? ((x % wrapW) + wrapW) % wrapW : x);

    c.fillStyle = G[0]; c.fillRect(x0, y - 2, x1 - x0, 15);
    c.fillStyle = G[1]; c.beginPath(); c.moveTo(x0, y + 11);
    for (let x = Math.floor(x0 / 14) * 14; x <= x1 + 14; x += 14) {
      const h = hash(hx(x) * 0.37);
      c.lineTo(x, y + 11); c.quadraticCurveTo(x + 7, y + 16 + h * 9, x + 14, y + 11);
    }
    c.lineTo(x1 + 14, y + 8); c.lineTo(x0, y + 8); c.closePath(); c.fill();
    c.fillStyle = 'rgba(255,255,200,0.16)'; c.fillRect(x0, y - 2, x1 - x0, 3);

    const step = 5;
    for (let layer = 0; layer < 2; layer++) {
      c.fillStyle = layer === 0 ? mix(G[1], G[0], 0.35) : G[2]; c.beginPath();
      for (let x = Math.floor(x0 / step) * step - (layer ? 2 : 0); x < x1 + step; x += step) {
        const k = hx(x), h1 = hash(k + layer * 7.7), h2 = hash(k * 1.9 + 3.3 + layer);
        if (layer === 1 && h1 < 0.25) continue;
        const bx = x + (h2 - 0.5) * 4;
        const H = (layer === 0 ? 15 : 11) + h1 * 13 + (h2 > 0.9 ? 11 : 0);
        const w = 2.2 + h2 * 2.2;
        const lean = (h1 - 0.5) * 0.5 + lean0 * (0.7 + h1 * 0.6) * (layer ? 1 : 0.85);
        const tx = bx + Math.sin(lean) * H, ty = y + 1 - Math.cos(lean) * H;
        c.moveTo(bx - w, y + 2);
        c.quadraticCurveTo(bx - w * 0.3 + (tx - bx) * 0.35, y - H * 0.5, tx, ty);
        c.quadraticCurveTo(bx + w * 0.4 + (tx - bx) * 0.4, y - H * 0.45, bx + w, y + 2);
      }
      c.fill();
    }

    if (theme.snow) {
      c.fillStyle = '#EEF5FD'; c.beginPath(); c.moveTo(x0, y + 13);
      for (let x = Math.floor(x0 / 22) * 22; x <= x1 + 22; x += 22) { const h = hash(hx(x) * 0.53); c.quadraticCurveTo(x + 11, y - 9 - h * 10, x + 22, y - 3 - hash(hx(x + 22) * 0.53) * 4); }
      c.lineTo(x1 + 22, y + 13); c.closePath(); c.fill();
      c.fillStyle = 'rgba(160,190,230,0.45)'; c.fillRect(x0, y + 7, x1 - x0, 6);
      c.fillStyle = '#FFFFFF'; c.beginPath();
      for (let x = Math.floor(x0 / 22) * 22; x <= x1 + 22; x += 22) { const h = hash(hx(x) * 0.53); c.moveTo(x + 4, y - 2 - h * 5); c.quadraticCurveTo(x + 11, y - 9 - h * 10, x + 18, y - 3 - h * 5); }
      c.lineWidth = 3; c.strokeStyle = '#FFFFFF'; c.stroke();

      c.fillStyle = 'rgba(255,255,255,0.95)';
      for (let x = Math.floor(x0 / 31) * 31; x < x1; x += 31) { const h = hash(hx(x) * 2.7); if (h > 0.55) c.fillRect(x + h * 10, y - 1 + h * 8, 2, 2); }
      return;
    }

    c.strokeStyle = 'rgba(255,255,210,0.35)'; c.lineWidth = 1.2; c.beginPath();
    for (let x = Math.floor(x0 / 37) * 37; x < x1; x += 37) {
      const h = hash(hx(x) * 3.1); if (h < 0.5) continue;
      const H = 12 + h * 8, lean = lean0 * 1.1, tx = x + Math.sin(lean) * H, ty = y - Math.cos(lean) * H;
      c.moveTo(x + (tx - x) * 0.55, y - H * 0.5); c.lineTo(tx, ty);
    }
    c.stroke();
  }
  function grassFrames() {
    const key = theme.grass.join() + (theme.snow ? '|snow' : '');
    if (grassCache.has(key)) return grassCache.get(key);
    if (typeof document === 'undefined') return null;
    const frames = [];
    for (let f = 0; f < GN; f++) {
      const cv = document.createElement('canvas'); cv.width = GT * GSC; cv.height = GH * GSC;
      const c = cv.getContext('2d'); c.scale(GSC, GSC);

      drawBlades(c, GUP, WMIN + (f * (WMAX - WMIN)) / (GN - 1), -40, GT + 40, GT);
      frames.push(cv);
    }
    grassCache.set(key, frames);
    return frames;
  }

  function grassStrip(ctx, x0, x1, y, flowers) {
    const G = theme.grass, t = now, frames = grassFrames();
    if (!frames) { drawBlades(ctx, y, wind(0, t), x0, x1, 0); return; }
    const step = CHUNK * detail;
    for (let cx = Math.floor(x0 / step) * step; cx < x1; cx += step) {
      const k = (wind(cx + step / 2, t) - WMIN) / (WMAX - WMIN);
      const fr = frames[Math.max(0, Math.min(GN - 1, Math.round(k * (GN - 1))))];
      const sx = ((cx % GT) + GT) % GT;
      const w = Math.min(step, GT - sx);
      ctx.drawImage(fr, sx * GSC, 0, w * GSC, GH * GSC, cx, y - GUP, w, GH);
      if (w < step) ctx.drawImage(frames[0] === fr ? fr : fr, 0, 0, (step - w) * GSC, GH * GSC, cx + w, y - GUP, step - w, GH);
    }
    if (!flowers || theme.noFlowers) return;

    const cols = ['#FFFFFF', '#FFFFFF', '#FFE14D', '#FF8FB1', '#FF9A3C', '#B9A6FF'];
    ctx.lineCap = 'round';
    for (let x = Math.floor(x0 / 55) * 55; x < x1; x += 55) {
      const h = hash(x * 0.71);
      if (h < 0.3) continue;
      const fx0 = x + h * 40, stem = 14 + h * 14, lean = wind(fx0, t) * 0.9;
      const fx = fx0 + Math.sin(lean) * stem, fy = y - Math.cos(lean) * stem;
      ctx.strokeStyle = G[1]; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(fx0, y + 2); ctx.quadraticCurveTo(fx0, y - stem * 0.5, fx, fy); ctx.stroke();
      ctx.fillStyle = cols[Math.floor(h * 97) % cols.length];
      for (let q = 0; q < 5; q++) { circle(ctx, fx + Math.cos(q * 1.256 + lean) * 4, fy + Math.sin(q * 1.256 + lean) * 4, 3); ctx.fill(); }
      ctx.fillStyle = '#E8A300'; circle(ctx, fx, fy, 2.4); ctx.fill();
    }
    ctx.lineCap = 'butt';
  }

  const vergeCache = new Map();
  function verge(ctx, x0, x1) {
    let layer = vergeCache.get(themeName);
    const width = 1280, height = 145;
    if (!layer) {
      layer = document.createElement('canvas'); layer.width = width; layer.height = height;
      const c = layer.getContext('2d'), r = rng(935 + themeName.length), P = PAINT[themeName];
      const ground = height - 3;
      for (let i = 0; i < 21; i++) {
        const x = 30 + i * 58 + r() * 28, scale = 11 + r() * 24;
        if (P.volcano || P.pines || r() > 0.66) {
          const w = scale * (1.3 + r() * 0.96), h = scale * (0.41 + r() * 0.35);
          c.fillStyle = mix(P.hills[2][1], P.tree[2], 0.55);
          c.beginPath(); c.moveTo(x - w, ground); c.lineTo(x - w * 0.58, ground - h * 0.79);
          c.lineTo(x + w * 0.16, ground - h); c.lineTo(x + w * 0.66, ground - h * 0.53);
          c.lineTo(x + w, ground); c.fill();
          c.fillStyle = mix(P.hills[2][0], P.sky[3], P.pines ? 0.68 : 0.16);
          c.beginPath(); c.moveTo(x - w * 0.58, ground - h * 0.79);
          c.lineTo(x + w * 0.16, ground - h); c.lineTo(x + w * 0.66, ground - h * 0.53);
          c.lineTo(x - w * 0.1, ground - h * 0.41); c.fill();
        } else {
          for (let j = 0; j < 6; j++) {
            const stem = x + (r() - 0.5) * scale * 1.8, bend = (r() - 0.35) * scale, h = scale * (0.55 + r() * 0.92);
            c.fillStyle = j % 3 ? P.tree[0] : P.tree[1];
            c.beginPath(); c.moveTo(stem, ground);
            c.quadraticCurveTo(stem + bend * 0.2 - 5, ground - h * 0.55, stem + bend, ground - h);
            c.quadraticCurveTo(stem + bend * 0.65 + 6, ground - h * 0.54, stem + 4, ground);
            c.fill();
          }
        }
      }
      vergeCache.set(themeName, layer);
    }
    ctx.save(); ctx.globalAlpha = 0.62;
    for (let x = Math.floor(x0 / width) * width; x < x1; x += width) ctx.drawImage(layer, x, C.GROUND_Y - height + 1);
    ctx.restore();
  }

  const leafSprites = new Map();
  function leafSprite(name) {
    if (leafSprites.has(name)) return leafSprites.get(name);
    if (typeof document === 'undefined') return null;
    const P = PAINT[name] || PAINT.noon, cv = document.createElement('canvas'), W = 340, H = 240;
    cv.width = W; cv.height = H; const c = cv.getContext('2d'), r = rng(9 + name.length);
    try { c.filter = 'blur(2.5px)'; } catch (e) {}
    const leaf = (x, y, len, w, a, dark) => {
      c.save(); c.translate(x, y); c.rotate(a);
      c.fillStyle = dark ? P.tree[2] : P.tree[0];
      c.beginPath(); c.moveTo(0, 0); c.quadraticCurveTo(w, -len * 0.45, 0, -len); c.quadraticCurveTo(-w, -len * 0.45, 0, 0); c.fill();
      c.strokeStyle = 'rgba(255,255,220,0.18)'; c.lineWidth = 2; c.beginPath(); c.moveTo(0, -4); c.lineTo(0, -len * 0.9); c.stroke();
      c.fillStyle = P.tree[1]; c.globalAlpha = 0.25; c.beginPath(); c.moveTo(0, -len * 0.1); c.quadraticCurveTo(w * 0.8, -len * 0.45, 0, -len * 0.95); c.fill(); c.globalAlpha = 1;
      c.restore();
    };
    for (let i = 0; i < 9; i++) leaf(W * 0.5 + (r() - 0.5) * 70, H + 10, 130 + r() * 90, 26 + r() * 18, (r() - 0.5) * 1.9, i % 3 === 0);
    for (let i = 0; i < 5; i++) leaf(W * 0.5 + (r() - 0.5) * 90, H + 10, 80 + r() * 50, 20 + r() * 10, (r() - 0.5) * 2.3, false);
    leafSprites.set(name, cv);
    return cv;
  }
  function foreground(ctx, v, t) {
    const sp = leafSprite(themeName);
    if (!sp) return;
    const bottom = v.y1, h = Math.min(210, bottom - C.GROUND_Y + 70);
    if (h < 70) return;
    const w = h * (340 / 240);
    for (const [x, flip, ph] of [[v.x0 + w * 0.32, -1, 0], [v.x1 - w * 0.3, 1, 1.7]]) {
      ctx.save(); ctx.translate(x, bottom + 6);
      ctx.rotate((Math.sin(t * 1.1 + ph) * 0.035 + wind(x, t) * 0.06) * flip);
      ctx.scale(flip, 1);
      ctx.drawImage(sp, -w / 2, -h, w, h);
      ctx.restore();
    }
  }

  function ambient(ctx, v, t) {
    const kind = theme.ambient, r = rng(31), W = v.x1 - v.x0;
    if (kind === 'fireflies') {
      ctx.globalCompositeOperation = 'lighter';
      for (let i = 0; i < 30; i++) {
        const bx = v.x0 + r() * W, by = 500 + r() * 430, ph = r() * 6.28, f = 0.3 + r() * 0.5;
        const x = bx + Math.sin(t * f + ph) * 60 + Math.sin(t * f * 2.3 + ph) * 20, y = by + Math.cos(t * f * 1.3 + ph) * 40;
        const a = 0.2 + 0.8 * Math.max(0, Math.sin(t * (1 + f * 2) + ph * 3));
        ctx.fillStyle = '#FFF2AD';
        ctx.globalAlpha = a * 0.86; circle(ctx, x, y, 2.2 + a * 1.9); ctx.fill();
        emission(x, y, 10, '#FFCF59', a * 0.83);
      }
      ctx.globalCompositeOperation = 'source-over';
      ctx.globalAlpha = 1;
    } else if (kind === 'leaves') {
      const cols = ['#E8641A', '#F29C2A', '#C9471A'];
      for (let i = 0; i < 22; i++) {
        const sp = 26 + r() * 30, ph = r() * 6.28;
        const y = 160 + ((r() * 820 + t * sp) % 820), x = v.x0 + ((r() * W + t * 14 + Math.sin(t * 1.2 + ph) * 50) % W + W) % W;
        ctx.save(); ctx.translate(x, y); ctx.rotate(t * 1.5 + ph); ctx.globalAlpha = 0.85;
        ctx.fillStyle = cols[i % 3]; ctx.beginPath(); ctx.ellipse(0, 0, 9, 4.5, 0, 0, TAU); ctx.fill();
        ctx.strokeStyle = 'rgba(90,30,0,0.5)'; ctx.lineWidth = 1; line(ctx, -9, 0, 9, 0);
        ctx.restore();
      }
    } else if (kind === 'snow') {

      ctx.fillStyle = '#FFFFFF';
      for (let i = 0; i < 70; i++) {
        const near = i % 3 === 0, sp = near ? 60 + r() * 30 : 28 + r() * 20, ph = r() * 6.28, sz = near ? 3 + r() * 2.5 : 1.4 + r() * 1.6;
        const y = v.y0 - 20 + ((r() * 1100 + t * sp) % 1100), x = v.x0 + ((r() * W + Math.sin(t * 0.8 + ph) * 40 - t * 10) % W + W) % W;
        ctx.globalAlpha = near ? 0.9 : 0.55; circle(ctx, x, y, sz); ctx.fill();
      }
    } else if (kind === 'embers') {

      ctx.globalCompositeOperation = 'lighter';
      for (let i = 0; i < 42; i++) {
        const sp = 30 + r() * 50, ph = r() * 6.28, life = 900;
        const y = C.GROUND_Y + 20 - ((r() * life + t * sp) % life), x = v.x0 + ((r() * W + Math.sin(t * 1.3 + ph) * 30) % W + W) % W;
        const a = (0.4 + 0.6 * Math.max(0, Math.sin(t * 4 + ph * 5))) * Math.min(1, (y - 100) / 300);
        if (a <= 0) continue;
        ctx.fillStyle = `rgba(255,${150 + Math.floor(r() * 80)},60,${a.toFixed(2)})`;
        circle(ctx, x, y, 1.5 + r() * 2.2); ctx.fill();
        if (i % 3 === 0) emission(x, y, 5, '#FF8F38', a * 0.67);
      }
      ctx.globalCompositeOperation = 'source-over';
    } else if (kind === 'pollen') {
      ctx.fillStyle = '#FFFFFF';
      for (let i = 0; i < 30; i++) {
        const ph = r() * 6.28, sp = 8 + r() * 14;
        const x = v.x0 + ((r() * W + t * sp) % W), y = 300 + r() * 620 + Math.sin(t * 0.7 + ph) * 26;
        ctx.globalAlpha = 0.25 + 0.3 * (0.5 + 0.5 * Math.sin(t * 1.3 + ph));
        circle(ctx, x, y, 2 + r() * 2.5); ctx.fill();
      }
    }
    ctx.globalAlpha = 1;
  }

  function decals(ctx, list) {
    for (const d of list) {
      ctx.save(); ctx.translate(d.x, d.y + 3); ctx.scale(1, 0.2);
      const g = ctx.createRadialGradient(0, 0, d.r * 0.1, 0, 0, d.r);
      g.addColorStop(0, 'rgba(25,12,4,0.7)'); g.addColorStop(0.6, 'rgba(25,12,4,0.35)'); g.addColorStop(1, 'rgba(25,12,4,0)');
      ctx.fillStyle = g; circle(ctx, 0, 0, d.r); ctx.fill();
      ctx.restore();
    }
  }

  function statics(ctx, list) {
    const T = theme, G = C.GROUND_Y;
    const rects = list.filter((s) => !s.poly && s.size).map((s) => ({ x0: s.position.x - s.size.w / 2, x1: s.position.x + s.size.w / 2, y: s.position.y - s.size.h / 2 }));
    const polys = list.filter((s) => s.poly);
    rects.sort((a, b) => b.y - a.y);

    for (const s of polys) {
      const vs = s.vertices, top = Math.min(...vs.map((p) => p.y)), xs = vs.map((p) => p.x);
      ctx.save(); ctx.beginPath(); vs.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y))); ctx.closePath(); ctx.clip();
      fillSoil(ctx, Math.min(...xs), top, Math.max(...xs) - Math.min(...xs), G - top + 4, top);
      ctx.restore();

      let best = null;
      for (let i = 0; i < vs.length; i++) {
        const a = vs[i], b = vs[(i + 1) % vs.length];
        if (Math.abs(a.y - b.y) < 1 || Math.abs(a.x - b.x) < 1) continue;
        const len = Math.hypot(a.x - b.x, a.y - b.y);
        if (!best || len > best.len) best = { a, b, len };
      }
      if (best) {

        ctx.lineCap = 'butt';
        ctx.strokeStyle = OUT; ctx.lineWidth = 19; line(ctx, best.a.x, best.a.y + 3, best.b.x, best.b.y + 3);
        ctx.lineCap = 'round';
        ctx.strokeStyle = T.grass[1]; ctx.lineWidth = 14; line(ctx, best.a.x, best.a.y + 3, best.b.x, best.b.y + 3);
        ctx.strokeStyle = T.grass[0]; ctx.lineWidth = 9; line(ctx, best.a.x, best.a.y, best.b.x, best.b.y);
        ctx.lineCap = 'butt';
      }
    }

    const exposed = (R, side) => {
      const ex = side < 0 ? R.x0 : R.x1;
      let bottom = G;
      for (const o of rects) if (o !== R && Math.abs((side < 0 ? o.x1 : o.x0) - ex) < 6) bottom = Math.min(bottom, Math.max(R.y, o.y));
      for (const s of polys) for (const p of s.vertices) if (Math.abs(p.x - ex) < 6 && p.y < G - 5) bottom = Math.min(bottom, Math.max(R.y, p.y));
      return bottom;
    };

    for (const R of rects) {
      const x = R.x0, y = R.y, w = R.x1 - R.x0;
      fillSoil(ctx, x, y, w, G - y + 2, y);
      ctx.strokeStyle = OUT; ctx.lineWidth = 5; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
      const lb = exposed(R, -1), rb = exposed(R, 1);
      ctx.beginPath();
      const rampAtTop = polys.some((s) => s.vertices.some((p) => Math.abs(p.x - x) < 6 && Math.abs(p.y - y) < 6));
      if (lb > y + 1) { ctx.moveTo(x, lb); ctx.lineTo(x, y); } else ctx.moveTo(x + (rampAtTop ? 8 : 0), y);
      ctx.lineTo(x + w, y);
      if (rb > y + 1) ctx.lineTo(x + w, rb);
      ctx.stroke(); ctx.lineCap = 'butt';
      ctx.save(); ctx.beginPath(); ctx.rect(x + 2, y + 2, w - 4, G - y); ctx.clip(); grassStrip(ctx, x, x + w, y + 2, true); ctx.restore();
    }

    const spans = rects.map((R) => [R.x0 - 4, R.x1 + 4]);
    for (const s of polys) { const xs = s.vertices.map((p) => p.x); spans.push([Math.min(...xs) - 16, Math.max(...xs) + 4]); }
    for (const [a, b] of spans) {
      ctx.save(); ctx.beginPath(); ctx.rect(a, G - 70, b - a, 100); ctx.clip();
      grassStrip(ctx, a, b, G, true);
      ctx.restore();
    }
  }

  function surfaceY(x, list) {
    let y = C.GROUND_Y;
    for (const s of list) {
      if (s.poly || !s.size) continue;
      if (x > s.position.x - s.size.w / 2 && x < s.position.x + s.size.w / 2) y = Math.min(y, s.position.y - s.size.h / 2);
    }
    return y;
  }

  function surfaceList(list, ground) {
    if (ground) return [{ x0: -1e5, x1: 1e5, y: C.GROUND_Y, ground: true }];
    return list.filter((s) => !s.poly && s.size).map((s) => ({ x0: s.position.x - s.size.w / 2, x1: s.position.x + s.size.w / 2, y: s.position.y - s.size.h / 2 }));
  }
  const shadeCache = new WeakMap();
  function unitShade(ctx) {
    if (!shadeCache.has(ctx)) {
      const g = ctx.createRadialGradient(0, 0, 0, 0, 0, 1);
      g.addColorStop(0, 'rgba(30,14,0,1)'); g.addColorStop(0.55, 'rgba(30,14,0,0.7)'); g.addColorStop(1, 'rgba(30,14,0,0)');
      shadeCache.set(ctx, g);
    }
    return shadeCache.get(ctx);
  }
  function softEllipse(ctx, x, y, rx, ry, alpha) {
    ctx.save(); ctx.translate(x, y); ctx.scale(rx, ry); ctx.globalAlpha = alpha;
    ctx.fillStyle = unitShade(ctx); ctx.beginPath(); ctx.arc(0, 0, 1, 0, TAU); ctx.fill();
    ctx.restore();
  }

  function groundFx(ctx, bodies, decalList, list, ground) {
    for (const S of surfaceList(list, ground)) {
      ctx.save();
      ctx.beginPath();

      if (S.ground) ctx.rect(-1e5, S.y + 1, 2e5, 18); else ctx.rect(S.x0 + 3, S.y + 1, S.x1 - S.x0 - 6, 16);
      ctx.clip();
      for (const d of decalList) {
        if (Math.abs(d.y - S.y) > 1) continue;
        softEllipse(ctx, d.x, d.y + 3, d.r * 0.85, Math.min(10, d.r * 0.06), 0.55);
      }
      for (const b of bodies) {
        const bb = b.bounds, cx = (bb.min.x + bb.max.x) / 2, w = bb.max.x - bb.min.x;
        if (cx < S.x0 - w / 2 || cx > S.x1 + w / 2) continue;
        if (!S.ground && (cx < S.x0 || cx > S.x1)) continue;
        if (S.ground && surfaceY(cx, list) !== S.y) continue;
        const gap = S.y - bb.max.y;
        if (gap < -8 || gap > 60) continue;
        const k = 1 - Math.max(0, gap) / 60;
        const offset = -theme.light[0] * (13 + Math.max(0, gap) * 0.65);
        if (detail === 1) softEllipse(ctx, cx + offset, S.y + 6, w * 0.63 + Math.abs(offset), 9, 0.27 * k);
        softEllipse(ctx, cx, S.y + 1, w * 0.52, 3 + 2 * k, 0.46 * k * k);
      }
      ctx.restore();
    }
  }

  const DEPTH = { x: 12, y: -9 };
  const SIDE = {
    wood:  ['rgb(222,160,84)', 'rgb(122,72,26)'],
    glass: ['rgba(205,240,255,0.80)', 'rgba(80,150,190,0.75)'],
    stone: ['rgb(190,185,175)', 'rgb(98,94,86)'],
    tnt:   ['rgb(230,90,60)', 'rgb(110,26,14)'],
  };
  const colorCache = new Map();
  function parseCol(c) {
    if (colorCache.has(c)) return colorCache.get(c);
    let m;
    if (c[0] === '#') { const n = parseInt(c.slice(1), 16); m = [(n >> 16) & 255, (n >> 8) & 255, n & 255, 1]; }
    else { m = c.match(/[\d.]+/g).map(Number); if (m.length === 3) m.push(1); }
    colorCache.set(c, m); return m;
  }
  function mix(c1, c2, k) {
    const a = parseCol(c1), b = parseCol(c2), q = Math.round(k * 8) / 8;
    return `rgba(${Math.round(a[0] + (b[0] - a[0]) * q)},${Math.round(a[1] + (b[1] - a[1]) * q)},${Math.round(a[2] + (b[2] - a[2]) * q)},${(a[3] + (b[3] - a[3]) * q).toFixed(2)})`;
  }

  function extrude(ctx, vs, lightCol, darkCol, depth, faceCol) {
    const D = depth || DEPTH, L = theme.light;
    let cx = 0, cy = 0; for (const v of vs) { cx += v.x; cy += v.y; } cx /= vs.length; cy /= vs.length;
    ctx.lineJoin = 'round'; ctx.lineWidth = 2; ctx.strokeStyle = 'rgba(43,29,14,0.55)';
    for (let i = 0; i < vs.length; i++) {
      const a = vs[i], b = vs[(i + 1) % vs.length];
      let nx = b.y - a.y, ny = a.x - b.x; const nl = Math.hypot(nx, ny) || 1; nx /= nl; ny /= nl;
      if (((a.x + b.x) / 2 - cx) * nx + ((a.y + b.y) / 2 - cy) * ny < 0) { nx = -nx; ny = -ny; }
      if (nx * D.x + ny * D.y <= 0.5) continue;
      const lit = Math.max(0, Math.min(1, 0.5 + 0.6 * (nx * L[0] + ny * L[1])));
      ctx.fillStyle = faceCol ? faceCol(nx, ny, lit) : mix(darkCol, lightCol, lit);
      ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.lineTo(b.x + D.x, b.y + D.y); ctx.lineTo(a.x + D.x, a.y + D.y); ctx.closePath();
      ctx.fill(); ctx.stroke();
    }
  }

  function extrudeCircle(ctx, x, y, r, col) {
    const D = DEPTH, dl = Math.hypot(D.x, D.y), px = -D.y / dl * r, py = D.x / dl * r;
    ctx.fillStyle = col; ctx.strokeStyle = 'rgba(43,29,14,0.55)'; ctx.lineWidth = 2;
    circle(ctx, x + D.x, y + D.y, r); ctx.fill(); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(x + px, y + py); ctx.lineTo(x - px, y - py); ctx.lineTo(x - px + D.x, y - py + D.y); ctx.lineTo(x + px + D.x, y + py + D.y); ctx.closePath(); ctx.fill();
  }

  function blockSides(ctx, b) {
    const g = b.game, c = SIDE[g.m];
    if (g.shape === 'circle') extrudeCircle(ctx, b.position.x, b.position.y, g.w / 2, mix(c[1], c[0], 0.35));
    else extrude(ctx, b.vertices, c[0], c[1]);
  }

  function sphereShade(ctx, r, la, sx = 1, sy = 1) {
    const lx = Math.cos(la), ly = Math.sin(la);
    ctx.save(); ctx.scale(sx, sy); circle(ctx, 0, 0, r * 0.95); ctx.clip();
    const g = ctx.createRadialGradient(lx * r * 0.45, ly * r * 0.45, r * 0.1, lx * r * 0.15, ly * r * 0.15, r * 1.15);
    g.addColorStop(0, 'rgba(255,249,236,0.31)'); g.addColorStop(0.47, 'rgba(255,255,255,0)');
    g.addColorStop(0.77, 'rgba(40,31,47,0.10)'); g.addColorStop(1, 'rgba(33,20,39,0.44)');
    ctx.fillStyle = g; ctx.fillRect(-r, -r, r * 2, r * 2);

    ctx.strokeStyle = 'rgba(172,220,248,0.28)'; ctx.lineWidth = r * 0.09; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.arc(0, 0, r * 0.87, la + Math.PI - 0.7, la + Math.PI + 0.7); ctx.stroke();

    ctx.strokeStyle = lightCfg().rim; ctx.lineWidth = r * 0.078;
    ctx.beginPath(); ctx.arc(0, 0, r * 0.9, la - 0.85, la + 0.85); ctx.stroke(); ctx.lineCap = 'butt';
    ctx.restore();
  }
  function lightAngle() { return Math.atan2(theme.light[1], theme.light[0]); }

  const crackCache = new WeakMap();
  function cracks(g) {
    if (crackCache.has(g)) return crackCache.get(g);
    const r = rng(g.seed * 131), out = [];
    for (let k = 0; k < 3; k++) {
      const pts = []; let x = (r() - 0.5) * g.w * 0.8, y = (r() < 0.5 ? -1 : 1) * g.h / 2;
      pts.push([x, y]);
      for (let i = 0; i < 4; i++) { x += (r() - 0.5) * g.w * 0.35; y = (r() - 0.5) * g.h * 0.9; pts.push([x, y]); }
      out.push(pts);
    }
    crackCache.set(g, out); return out;
  }

  function shapePath(ctx, g) {
    const w = g.w, h = g.h;
    if (g.shape === 'tri') { ctx.beginPath(); ctx.moveTo(-w / 2, h / 3); ctx.lineTo(w / 2, h / 3); ctx.lineTo(0, -2 * h / 3); ctx.closePath(); }
    else if (g.shape === 'circle') circle(ctx, 0, 0, w / 2);
    else rr(ctx, -w / 2, -h / 2, w, h, g.m === 'stone' ? 6 : g.m === 'glass' ? 3 : 4);
  }

  function rimLight(ctx, g, ang) {
    const L = theme.light, ca = Math.cos(ang), sa = Math.sin(ang);
    const lx = L[0] * ca + L[1] * sa, ly = -L[0] * sa + L[1] * ca;
    const w = g.w, h = g.h, col = lightCfg().rim, inset = 2.5;
    ctx.save(); ctx.strokeStyle = col; ctx.lineCap = 'round'; ctx.lineWidth = g.m === 'glass' ? 3.5 : 3;
    if (g.shape === 'circle') {
      const a = Math.atan2(ly, lx);
      ctx.globalAlpha = 0.9; ctx.beginPath(); ctx.arc(0, 0, w / 2 - inset, a - 1.0, a + 1.0); ctx.stroke();
    } else {
      const vs = g.shape === 'tri' ? [[-w / 2, h / 3], [w / 2, h / 3], [0, -2 * h / 3]] : [[-w / 2, -h / 2], [w / 2, -h / 2], [w / 2, h / 2], [-w / 2, h / 2]];
      let cx = 0, cy = 0; vs.forEach(([x, y]) => { cx += x; cy += y; }); cx /= vs.length; cy /= vs.length;
      for (let i = 0; i < vs.length; i++) {
        const [ax, ay] = vs[i], [bx, by] = vs[(i + 1) % vs.length];
        let nx = by - ay, ny = ax - bx; const nl = Math.hypot(nx, ny) || 1; nx /= nl; ny /= nl;
        if (((ax + bx) / 2 - cx) * nx + ((ay + by) / 2 - cy) * ny < 0) { nx = -nx; ny = -ny; }
        const k = nx * lx + ny * ly;
        if (k < 0.2) continue;
        ctx.globalAlpha = Math.min(1, (k - 0.1) * 1.1);

        const ix = -nx * inset, iy = -ny * inset, tx = (bx - ax) * 0.06, ty = (by - ay) * 0.06;
        ctx.beginPath(); ctx.moveTo(ax + ix + tx, ay + iy + ty); ctx.lineTo(bx + ix - tx, by + iy - ty); ctx.stroke();
      }
    }
    ctx.restore();
  }

  let bloom = null, emit = null;
  function beginBloom(ctx, enabled, scale, x, y) {
    emit = null;
    if (!enabled) return;
    const fullW = ctx.canvas.width, fullH = ctx.canvas.height;
    const ratio = Math.min(0.39, 560 / Math.max(fullW, fullH));
    const w = Math.max(1, Math.round(fullW * ratio)), h = Math.max(1, Math.round(fullH * ratio));
    if (!bloom) {
      const source = document.createElement('canvas'), spread = document.createElement('canvas');
      bloom = { source, spread, mask: source.getContext('2d'), blur: spread.getContext('2d') };
    }
    const { source, spread, mask } = bloom;
    if (source.width !== w || source.height !== h) {
      source.width = spread.width = w;
      source.height = spread.height = h;
    }
    mask.setTransform(1, 0, 0, 1, 0, 0);
    mask.clearRect(0, 0, w, h);
    const rx = w / fullW, ry = h / fullH;
    mask.setTransform(scale * rx, 0, 0, scale * ry, x * rx, y * ry);
    bloom.radius = scale * ratio;
    bloom.dirty = false;
    emit = mask;
  }

  function emission(x, y, radius, color, strength, ry = radius) {
    if (!emit || strength <= 0) return;
    bloom.dirty = true;
    emit.globalAlpha = Math.min(1, strength);
    emit.fillStyle = color;
    if (radius === ry) circle(emit, x, y, radius);
    else { emit.beginPath(); emit.ellipse(x, y, radius, ry, 0, 0, TAU); }
    emit.fill();
  }

  function finishBloom(ctx) {
    if (!emit) return;
    emit = null;
    if (!bloom.dirty) return;
    const { source, spread, blur, radius } = bloom;
    const w = source.width, h = source.height;
    ctx.save();
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.globalCompositeOperation = 'screen';
    ctx.imageSmoothingEnabled = true;
    if ('filter' in blur) {
      blur.clearRect(0, 0, w, h);
      blur.globalCompositeOperation = 'lighter';
      for (const [size, alpha] of [[23, 0.82], [67, 0.56]]) {
        blur.globalAlpha = alpha;
        blur.filter = `blur(${Math.max(1, size * radius).toFixed(1)}px)`;
        blur.drawImage(source, 0, 0);
      }
      blur.filter = 'none';
      ctx.drawImage(spread, 0, 0, ctx.canvas.width, ctx.canvas.height);
    } else {
      const bw = Math.max(1, Math.round(w / 7)), bh = Math.max(1, Math.round(h / 7));
      blur.clearRect(0, 0, bw, bh);
      blur.imageSmoothingQuality = 'high';
      blur.drawImage(source, 0, 0, bw, bh);
      ctx.globalAlpha = 0.66;
      ctx.drawImage(spread, 0, 0, bw, bh, 0, 0, ctx.canvas.width, ctx.canvas.height);
    }
    ctx.restore();
  }

  function impactLight(ctx, x, y, power, color) {
    const radius = 38 + 115 * power;
    const g = ctx.createRadialGradient(x, y, 0, x, y, radius);
    const rgb = parseCol(color).slice(0, 3).join(',');
    g.addColorStop(0, `rgba(${rgb},${Math.min(0.44, power * 0.37)})`);
    g.addColorStop(0.26, `rgba(${rgb},${power * 0.14})`);
    g.addColorStop(1, `rgba(${rgb},0)`);
    ctx.save(); ctx.globalCompositeOperation = 'screen';
    ctx.fillStyle = g; circle(ctx, x, y, radius); ctx.fill();
    ctx.restore();
    emission(x, y, 13 + 41 * power, color, Math.min(0.83, power));
  }

  let frameTone = {};
  function finishFrame(ctx, low) {
    finishBloom(ctx);
    if (low) return;
    const { width: w, height: h } = ctx.canvas, light = lightCfg();
    if (frameTone.w !== w || frameTone.h !== h || frameTone.light !== light) {
      const tint = light.tint.join(','), shade = light.shade.join(',');
      const tone = ctx.createLinearGradient(0, 0, 0, h);
      tone.addColorStop(0, `rgba(${tint},0.19)`);
      tone.addColorStop(0.63, `rgba(${tint},0.055)`);
      tone.addColorStop(1, `rgba(${shade},0.27)`);
      const corners = ctx.createRadialGradient(w * 0.50, h * 0.47, Math.min(w, h) * 0.34,
        w * 0.50, h * 0.47, Math.hypot(w, h) * 0.56);
      corners.addColorStop(0, `rgba(${shade},0)`);
      corners.addColorStop(0.66, `rgba(${shade},0.04)`);
      corners.addColorStop(1, `rgba(${shade},0.23)`);
      frameTone = { w, h, light, tone, corners };
    }
    ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.globalCompositeOperation = 'soft-light'; ctx.fillStyle = frameTone.tone; ctx.fillRect(0, 0, w, h);
    ctx.globalCompositeOperation = 'multiply'; ctx.fillStyle = frameTone.corners; ctx.fillRect(0, 0, w, h);
    ctx.restore();
  }

  function flightTrail(ctx, points, radius, power) {
    if (points.length < 2) return;
    const tip = points[points.length - 1], tail = points[0];
    const tint = power ? '255,178,75' : '255,246,199';
    const core = ctx.createLinearGradient(tail.x, tail.y, tip.x, tip.y);
    core.addColorStop(0, `rgba(${tint},0)`);
    core.addColorStop(1, `rgba(${tint},0.94)`);
    ctx.save(); ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.strokeStyle = core;
    ctx.beginPath(); ctx.moveTo(tail.x, tail.y);
    for (let i = 1; i < points.length - 1; i++) {
      const p = points[i], next = points[i + 1];
      ctx.quadraticCurveTo(p.x, p.y, (p.x + next.x) / 2, (p.y + next.y) / 2);
    }
    ctx.lineTo(tip.x, tip.y);
    ctx.lineWidth = radius * 0.38; ctx.globalAlpha = 0.23; ctx.stroke();
    ctx.lineWidth = radius * 0.14; ctx.globalAlpha = 0.84; ctx.stroke();
    ctx.restore();
    for (let i = 1; i < points.length; i += 2) {
      const p = points[i], k = i / (points.length - 1);
      emission(p.x, p.y, radius * (0.34 + k * 0.19), power ? '#FF983D' : '#FFF2B0', k * 0.76);
    }
  }

  const MAT_STYLE = {
    wood:  { light: '#EEC483', mid: '#CC9053', dark: '#83502E', edge: '#533423' },
    glass: { light: 'rgba(228,253,255,0.77)', mid: 'rgba(125,202,216,0.42)', dark: 'rgba(34,114,147,0.79)', edge: '#356D83' },
    stone: { light: '#D9D6CC', mid: '#ABAFA9', dark: '#727871', edge: '#464945' },
    tnt:   { light: '#E86B49', mid: '#BF422C', dark: '#70211F', edge: '#462828' },
  };
  const blockFaces = new WeakMap();

  function paintWood(ctx, g, r) {
    const length = Math.max(g.w, g.h), breadth = Math.min(g.w, g.h);
    if (g.h > g.w && g.shape !== 'tri') ctx.rotate(Math.PI / 2);
    const knot = (r() - 0.5) * length * 0.54;
    const bend = Math.min(9, breadth * 0.22);
    for (let i = 0; i < 17; i++) {
      const y = (i / 16 - 0.5) * breadth * 1.62, sign = y > 0 ? 1 : -1;
      const offset = sign * bend * Math.max(0, 1 - Math.abs(y) / (breadth * 0.45));
      const reach = length * (0.15 + r() * 0.13);
      ctx.strokeStyle = i % 3 === 0 ? 'rgba(252,217,158,0.56)' : 'rgba(110,58,28,0.30)';
      ctx.lineWidth = 0.65 + r() * 1.5;
      ctx.beginPath(); ctx.moveTo(-length * 0.62, y - 3 + r() * 6);
      ctx.bezierCurveTo(knot - reach, y, knot - reach * 0.65, y + offset, knot, y + offset);
      ctx.bezierCurveTo(knot + reach * 0.85, y + offset, knot + reach, y, length * 0.62, y - 4 + r() * 8);
      ctx.stroke();
    }
    if (breadth > 16) {
      for (let i = 3; i >= 0; i--) {
        ctx.fillStyle = ['#71432B', '#AE7145', '#8A512F', '#D29A5B'][i];
        ctx.beginPath(); ctx.ellipse(knot, 0, 2 + i * 2.8, 1.2 + i * (bend * 0.27), -0.08, 0, TAU); ctx.fill();
      }
    }
    if (g.shape === 'rect' && length > 62) for (const x of [-length * 0.5 + 8, length * 0.5 - 8]) rivet(ctx, x, 0, 2.55);
  }

  function paintStone(ctx, g, r) {
    const { w, h } = g;
    const count = Math.min(56, Math.max(10, Math.round(w * h / 210)));
    for (let i = 0; i < count; i++) {
      const x = (r() - 0.5) * w, y = (r() - 0.49) * h, z = 1 + r() * Math.min(11, w * 0.19);
      ctx.fillStyle = i % 3 ? 'rgba(67,79,76,0.20)' : 'rgba(247,242,215,0.28)';
      ctx.beginPath(); ctx.moveTo(x - z, y); ctx.lineTo(x - z * 0.17, y - z * 0.48);
      ctx.lineTo(x + z, y - z * 0.16); ctx.lineTo(x + z * 0.47, y + z * 0.48); ctx.fill();
    }
    const rows = g.shape === 'rect' ? Math.max(1, Math.floor(h / 29)) : 3;
    ctx.lineJoin = 'round';
    for (let j = 0; j < rows; j++) {
      const y = g.shape === 'tri' ? g.h / 3 - j * h / 3 : -h * 0.5 + j * h / rows;
      if (j > 0) {
        const v = y + (r() - 0.5) * 6;
        ctx.strokeStyle = 'rgba(242,235,211,0.49)'; ctx.lineWidth = 3.2;
        ctx.beginPath(); ctx.moveTo(-w / 2, y + 1); ctx.lineTo(-w * 0.15, v + 2); ctx.lineTo(w / 2, y); ctx.stroke();
        ctx.strokeStyle = 'rgba(55,65,59,0.68)'; ctx.lineWidth = 1.7;
        ctx.beginPath(); ctx.moveTo(-w / 2, y); ctx.lineTo(-w * 0.15, v); ctx.lineTo(w / 2, y - 2); ctx.stroke();
      }
      if (g.shape === 'rect' && w > 47) {
        const x = w * (j % 2 ? 0.17 : -0.21);
        ctx.strokeStyle = 'rgba(55,65,59,0.55)'; ctx.lineWidth = 1.5;
        line(ctx, x, y, x + 4, y + h / rows);
      }
    }
  }

  function paintGlass(ctx, g) {
    const { w, h } = g, size = Math.max(w, h);
    const luster = ctx.createLinearGradient(-size * 0.4, -size * 0.1, size * 0.4, size * 0.1);
    luster.addColorStop(0.18, 'rgba(230,255,255,0)');
    luster.addColorStop(0.23, 'rgba(230,255,255,0.66)');
    luster.addColorStop(0.43, 'rgba(188,250,253,0.25)');
    luster.addColorStop(0.46, 'rgba(220,252,255,0)');
    luster.addColorStop(0.52, 'rgba(235,255,255,0.78)');
    luster.addColorStop(0.58, 'rgba(235,255,255,0.08)');
    luster.addColorStop(1, 'rgba(128,220,248,0)');
    ctx.fillStyle = luster; ctx.fillRect(-w / 2, -2 * h / 3, w, h * 1.33);
    if (g.shape === 'rect') {
      const bevel = Math.min(5.5, Math.min(w, h) * 0.19);
      ctx.strokeStyle = 'rgba(13,93,131,0.54)'; ctx.lineWidth = 1.6;
      rr(ctx, -w / 2 + bevel, -h / 2 + bevel, w - bevel * 2, h - bevel * 2, 2); ctx.stroke();
      ctx.strokeStyle = 'rgba(234,255,251,0.84)'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(-w / 2 + bevel, h / 2 - bevel * 1.5);
      ctx.lineTo(-w / 2 + bevel, -h / 2 + bevel); ctx.lineTo(w / 2 - bevel * 1.4, -h / 2 + bevel); ctx.stroke();
    }
  }

  function rivet(ctx, x, y, r) {
    ctx.fillStyle = '#483B34'; circle(ctx, x, y + r * 0.26, r); ctx.fill();
    ctx.fillStyle = '#B5AAA0'; circle(ctx, x, y, r * 0.79); ctx.fill();
    ctx.fillStyle = '#F9E7CA'; circle(ctx, x - r * 0.25, y - r * 0.27, r * 0.27); ctx.fill();
  }

  function paintCrate(ctx, g) {
    const { w, h } = g, rail = Math.min(w, h) * 0.125;
    for (const x of [-w / 2, w / 2 - rail]) {
      ctx.fillStyle = '#592C28'; ctx.fillRect(x, -h / 2, rail, h);
      ctx.fillStyle = '#985443'; ctx.fillRect(x + 1, -h / 2, rail * 0.50, h);
    }
    ctx.fillStyle = '#4B2D28'; ctx.fillRect(-w / 2, -h / 2, w, rail); ctx.fillRect(-w / 2, h / 2 - rail, w, rail);
    ctx.fillStyle = '#B86B4D'; ctx.fillRect(-w / 2, -h / 2 + rail * 0.2, w, rail * 0.24);
    for (const x of [-w / 2 + rail * 0.70, w / 2 - rail * 0.70]) {
      for (const y of [-h / 2 + rail * 0.67, h / 2 - rail * 0.67]) rivet(ctx, x, y, rail * 0.31);
    }
    const plate = ctx.createLinearGradient(0, -h * 0.19, 0, h * 0.21);
    plate.addColorStop(0, '#FFF0AD'); plate.addColorStop(1, '#F2B83E');
    rr(ctx, -w * 0.35, -h * 0.19, w * 0.70, h * 0.38, 3);
    ctx.fillStyle = plate; ctx.fill(); ctx.strokeStyle = '#593629'; ctx.lineWidth = 1.5; ctx.stroke();
    ctx.fillStyle = '#67302B'; ctx.font = `900 ${Math.round(h * 0.25)}px "Trebuchet MS", sans-serif`;
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('TNT', 0, 1);
  }

  function makeBlockFace(g) {
    const { w, h } = g, style = MAT_STYLE[g.m], top = g.shape === 'tri' ? -2 * h / 3 : -h / 2;
    const pad = 3, height = h + pad * 2, width = w + pad * 2;
    const tile = document.createElement('canvas');
    tile.width = Math.ceil(width * 1.45); tile.height = Math.ceil(height * 1.45);
    const ctx = tile.getContext('2d'), r = rng(g.seed + 245);
    ctx.scale(tile.width / width, tile.height / height);
    ctx.translate(w / 2 + pad, -top + pad);
    const color = ctx.createLinearGradient(-w * 0.32, top, w * 0.24, top + h);
    color.addColorStop(0, style.light); color.addColorStop(0.55, style.mid); color.addColorStop(1, style.dark);
    shapePath(ctx, g);
    ctx.fillStyle = color; ctx.fill();
    ctx.save(); ctx.clip();
    if (g.m === 'wood') paintWood(ctx, g, r);
    else if (g.m === 'glass') paintGlass(ctx, g);
    else if (g.m === 'stone') paintStone(ctx, g, r);
    else paintCrate(ctx, g);
    ctx.restore();
    shapePath(ctx, g);
    ctx.strokeStyle = style.edge; ctx.lineWidth = g.m === 'glass' ? 2.1 : 2.7; ctx.stroke();
    return { tile, left: -w / 2 - pad, top: top - pad, width, height };
  }

  function block(ctx, b) {
    const g = b.game;
    let face = blockFaces.get(g);
    if (!face) { face = makeBlockFace(g); blockFaces.set(g, face); }
    ctx.save(); ctx.translate(b.position.x, b.position.y); ctx.rotate(b.angle);
    ctx.drawImage(face.tile, face.left, face.top, face.width, face.height);
    rimLight(ctx, g, b.angle);
    const damage = 1 - g.hp / g.maxHp;
    if (damage > 0.20) {
      const lines = cracks(g), count = damage > 0.70 ? 3 : damage > 0.45 ? 2 : 1;
      const glass = g.m === 'glass';
      ctx.save(); shapePath(ctx, g); ctx.clip();
      ctx.lineJoin = 'round';
      for (let i = 0; i < count; i++) {
        ctx.beginPath();
        lines[i].forEach(([x, y], j) => (j ? ctx.lineTo(x, y) : ctx.moveTo(x, y)));
        ctx.strokeStyle = glass ? 'rgba(37,99,119,0.59)' : 'rgba(250,223,176,0.48)';
        ctx.lineWidth = glass ? 3.9 : 3.6; ctx.stroke();
        ctx.strokeStyle = glass ? '#E9FFFF' : '#52392C';
        ctx.lineWidth = glass ? 1.7 : 2.1; ctx.stroke();
      }
      ctx.restore();
    }
    ctx.restore();
  }

  const CHICK = {
    normal: { a: '#FFE95C', b: '#FFC21A', belly: '#FFF6C2', wing: '#F2AE00' },
    speed:  { a: '#FFC067', b: '#FF8A00', belly: '#FFE3B8', wing: '#E06F00' },
    bomb:   { a: '#7A6650', b: '#46372A', belly: '#9C8A73', wing: '#33271D' },
    split:  { a: '#FFC4DC', b: '#FF6FA8', belly: '#FFE6F0', wing: '#E85590' },
    heavy:  { a: '#C2B2FF', b: '#7454D8', belly: '#E4DCFF', wing: '#563AB0' },
    boomer: { a: '#C8F58A', b: '#58B52A', belly: '#ECFFD6', wing: '#3E8F18' },
    puff:   { a: '#FFFFFF', b: '#9ED8FF', belly: '#FFFFFF', wing: '#74C0F2' },
  };
  const BIRD_PROFILE = {
    normal: [1.02, 0.97], speed: [1.14, 0.85], bomb: [1.01, 1.02],
    split: [0.94, 1.04], heavy: [1.09, 0.97], boomer: [1.09, 0.90], puff: [1, 1],
  };

  function eye(ctx, x, y, r, dx, dy, iris) {
    const sclera = ctx.createLinearGradient(x, y - r, x, y + r);
    sclera.addColorStop(0, '#FFFFF4'); sclera.addColorStop(1, '#C9DCE2');
    ctx.fillStyle = sclera; ctx.lineWidth = r * 0.28;
    circle(ctx, x, y, r); ctx.fill(); ctx.stroke();
    ctx.fillStyle = iris; circle(ctx, x + dx, y + dy, r * 0.58); ctx.fill();
    ctx.fillStyle = '#192229'; circle(ctx, x + dx, y + dy, r * 0.40); ctx.fill();
    ctx.fillStyle = '#FFFFFF'; circle(ctx, x + dx - r * 0.17, y + dy - r * 0.22, r * 0.18); ctx.fill();
  }

  function chick(ctx, x, y, r, ang, type, o = {}) {
    const c = CHICK[type] || CHICK.normal;
    const [sx, sy] = BIRD_PROFILE[type] || BIRD_PROFILE.normal;
    ctx.save(); ctx.translate(x, y); ctx.rotate(ang);
    if (o.mirror) ctx.scale(1, -1);
    if (o.squash) ctx.scale(1 + o.squash, 1 - o.squash);
    ctx.lineJoin = 'round'; ctx.lineWidth = Math.max(2.5, r * 0.12); ctx.strokeStyle = OUT;

    for (let i = 2; i >= 0; i--) {
      const lean = (i - 1) * r * 0.29;
      ctx.fillStyle = mix(c.wing, c.a, 0.18 + i * 0.16);
      ctx.beginPath(); ctx.moveTo(-r * 0.69, r * 0.12);
      ctx.quadraticCurveTo(-r * 1.26, lean + r * 0.19, -r * (type === 'speed' ? 1.65 : 1.44), lean - r * 0.15);
      ctx.quadraticCurveTo(-r * 1.20, lean - r * 0.30, -r * 0.68, -r * 0.13);
      ctx.closePath(); ctx.fill(); ctx.stroke();
    }

    if (type === 'normal' || type === 'split') {
      ctx.fillStyle = type === 'split' ? '#FFD21F' : c.b;
      for (let i = 0; i < 3; i++) { ctx.beginPath(); ctx.ellipse(-r * 0.15 + i * r * 0.22, -r * 1.02, r * 0.12, r * 0.28, -0.4 + i * 0.4, 0, TAU); ctx.fill(); ctx.stroke(); }
    } else if (type === 'speed') {
      ctx.fillStyle = c.b;
      ctx.beginPath(); ctx.moveTo(r * 0.2, -r * 0.85); ctx.lineTo(-r * 0.9, -r * 1.25); ctx.lineTo(-r * 0.35, -r * 0.8); ctx.lineTo(-r * 1.0, -r * 0.95); ctx.lineTo(-r * 0.3, -r * 0.6); ctx.closePath(); ctx.fill(); ctx.stroke();
    } else if (type === 'heavy') {

      ctx.fillStyle = '#C9CED8';
      ctx.beginPath(); ctx.moveTo(-r * 0.12, -r * 0.9); ctx.lineTo(0, -r * 1.32); ctx.lineTo(r * 0.12, -r * 0.9); ctx.closePath(); ctx.fill(); ctx.stroke();
    } else if (type === 'boomer') {

      ctx.save(); ctx.translate(-r * 0.15, -r * 1.02); ctx.rotate(-0.3); ctx.scale(1.3, 1.3);
      ctx.fillStyle = '#C98A3E'; ctx.beginPath();
      ctx.moveTo(-r * 0.62, r * 0.05); ctx.quadraticCurveTo(-r * 0.2, -r * 0.08, 0, -r * 0.42); ctx.quadraticCurveTo(r * 0.2, -r * 0.08, r * 0.62, r * 0.05);
      ctx.lineTo(r * 0.56, r * 0.22); ctx.quadraticCurveTo(r * 0.1, r * 0.1, 0, -r * 0.14); ctx.quadraticCurveTo(-r * 0.1, r * 0.1, -r * 0.56, r * 0.22); ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.fillStyle = '#E8343A'; ctx.fillRect(-r * 0.46, r * 0.06, r * 0.1, r * 0.1); ctx.fillRect(r * 0.36, r * 0.06, r * 0.1, r * 0.1);
      ctx.restore();
    } else if (type === 'puff') {

      ctx.fillStyle = c.b;
      for (let i = 0; i < 3; i++) { circle(ctx, -r * 0.24 + i * r * 0.24, -r * 1.02 - (i === 1 ? r * 0.08 : 0), r * 0.17); ctx.fill(); ctx.stroke(); }
    } else if (type === 'bomb') {
      ctx.strokeStyle = OUT; ctx.lineWidth = r * 0.14;
      ctx.beginPath(); ctx.moveTo(0, -r * 0.95); ctx.quadraticCurveTo(r * 0.2, -r * 1.35, r * 0.45, -r * 1.3); ctx.stroke();
      const fl = 0.7 + Math.sin((o.time || 0) * 30) * 0.3;
      ctx.fillStyle = '#FFE14D'; circle(ctx, r * 0.5, -r * 1.32, r * 0.18 * fl + r * 0.08); ctx.fill();
      ctx.fillStyle = '#FF7A00'; circle(ctx, r * 0.5, -r * 1.32, r * 0.1 * fl); ctx.fill();
      ctx.lineWidth = Math.max(2.5, r * 0.12);
    }

    const g = ctx.createRadialGradient(-r * 0.35, -r * 0.4, r * 0.1, 0, 0, r * 1.05);
    g.addColorStop(0, mix(c.a, '#FFF5D4', 0.23)); g.addColorStop(0.46, c.a); g.addColorStop(1, c.b);
    if (type === 'puff') {

      const n = 14, fr = r * (o.puffed ? 0.2 : 0.24);
      ctx.fillStyle = c.b;
      for (let i = 0; i < n; i++) { const a = (i / n) * TAU + (o.time || 0) * (o.puffed ? 1.5 : 0); circle(ctx, Math.cos(a) * r * 0.9, Math.sin(a) * r * 0.9, fr); ctx.fill(); ctx.stroke(); }
      ctx.fillStyle = g; circle(ctx, 0, 0, r * 0.92); ctx.fill();
    } else {
      ctx.fillStyle = g; ctx.beginPath(); ctx.ellipse(0, 0, r * sx, r * sy, 0, 0, TAU); ctx.fill(); ctx.stroke();
    }

    ctx.save(); ctx.beginPath();
    ctx.ellipse(0, 0, r * sx - ctx.lineWidth / 2, r * sy - ctx.lineWidth / 2, 0, 0, TAU); ctx.clip();
    const belly = ctx.createLinearGradient(0, r * 0.15, 0, r);
    belly.addColorStop(0, c.belly); belly.addColorStop(1, mix(c.belly, c.b, 0.46));
    ctx.fillStyle = belly; ctx.beginPath(); ctx.ellipse(r * 0.18, r * 0.60, r * 0.74, r * 0.49, -0.18, 0, TAU); ctx.fill();
    ctx.strokeStyle = mix(c.a, '#FFF6CC', 0.60); ctx.globalAlpha = 0.48; ctx.lineWidth = r * 0.035;
    ctx.lineCap = 'round';
    for (const [px, py] of [[-0.48, -0.58], [-0.38, -0.72], [-0.24, -0.64], [-0.69, -0.32]]) {
      ctx.beginPath(); ctx.moveTo(px * r, py * r);
      ctx.quadraticCurveTo((px + 0.07) * r, (py - 0.09) * r, (px + 0.17) * r, (py - 0.04) * r); ctx.stroke();
    }
    ctx.restore();
    sphereShade(ctx, r, o.mirror ? ang - lightAngle() : lightAngle() - ang, sx, sy);
    if (type === 'heavy') {

      ctx.save(); circle(ctx, 0, 0, r + ctx.lineWidth); ctx.clip();
      const hg = ctx.createLinearGradient(0, -r, 0, -r * 0.3);
      hg.addColorStop(0, '#E6EAF0'); hg.addColorStop(1, '#8D95A5');
      ctx.fillStyle = hg; ctx.beginPath(); ctx.ellipse(0, -r * 0.42, r * 1.08, r * 0.72, 0, Math.PI, TAU); ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.fillStyle = '#7A8292'; rr(ctx, -r * 1.05, -r * 0.5, r * 2.1, r * 0.17, r * 0.06); ctx.fill(); ctx.stroke();
      ctx.fillStyle = '#E6EAF0'; for (const rx of [-0.7, -0.25, 0.25, 0.7]) { circle(ctx, rx * r, -r * 0.415, r * 0.045); ctx.fill(); }
      ctx.restore();
    }

    const flap = o.flap ? Math.sin((o.time || 0) * 34) : 0;
    ctx.save(); ctx.translate(-r * 0.30, r * 0.19); ctx.rotate(-0.15 + flap * 0.9);
    const wing = ctx.createLinearGradient(0, -r * 0.23, 0, r * 0.25);
    wing.addColorStop(0, mix(c.a, c.wing, 0.34)); wing.addColorStop(1, c.wing);
    ctx.fillStyle = wing; ctx.lineWidth = r * 0.077;
    ctx.beginPath(); ctx.moveTo(r * 0.29, -r * 0.05);
    ctx.bezierCurveTo(r * 0.12, -r * 0.37, -r * 0.29, -r * 0.26, -r * (o.flap ? 0.63 : 0.46), r * 0.11);
    ctx.quadraticCurveTo(-r * 0.20, r * 0.23, -r * 0.27, r * 0.32);
    ctx.bezierCurveTo(0, r * 0.29, r * 0.19, r * 0.23, r * 0.29, -r * 0.05); ctx.fill(); ctx.stroke();
    ctx.strokeStyle = 'rgba(255,247,221,0.46)'; ctx.lineWidth = r * 0.042; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(-r * 0.30, r * 0.06); ctx.quadraticCurveTo(-r * 0.06, 0, r * 0.10, -r * 0.14); ctx.stroke();
    ctx.restore();

    const ex1 = r * 0.12, ex2 = r * 0.52, ey = -r * 0.22, er = r * 0.25;
    if (o.blink) {
      ctx.lineWidth = r * 0.1;
      ctx.beginPath(); ctx.moveTo(ex1 - er, ey); ctx.lineTo(ex1 + er, ey); ctx.moveTo(ex2 - er * 0.9, ey); ctx.lineTo(ex2 + er * 0.9, ey); ctx.stroke();
    } else {
      eye(ctx, ex2, ey, er * 0.89, er * 0.31, er * 0.07, '#8A6550');
      eye(ctx, ex1, ey, er, er * 0.34, er * 0.06, '#765142');
    }

    if (type === 'speed' || type === 'bomb') {
      ctx.lineWidth = r * 0.12; ctx.beginPath();
      ctx.moveTo(ex1 - er, ey - er * 1.3); ctx.lineTo(ex1 + er, ey - er * 0.9);
      ctx.moveTo(ex2 - er * 0.8, ey - er * 0.9); ctx.lineTo(ex2 + er, ey - er * 1.3); ctx.stroke();
    } else if (type === 'heavy') {

      ctx.fillStyle = OUT; ctx.beginPath();
      ctx.moveTo(ex1 - er * 1.1, ey - er * 1.5); ctx.lineTo(ex1 + er * 1.05, ey - er * 0.85); ctx.lineTo(ex1 + er * 0.9, ey - er * 0.55); ctx.lineTo(ex1 - er * 1.1, ey - er * 1.05); ctx.closePath(); ctx.fill();
      ctx.beginPath();
      ctx.moveTo(ex2 - er * 0.9, ey - er * 0.85); ctx.lineTo(ex2 + er * 1.1, ey - er * 1.5); ctx.lineTo(ex2 + er * 1.1, ey - er * 1.05); ctx.lineTo(ex2 - er * 0.75, ey - er * 0.55); ctx.closePath(); ctx.fill();
    } else if (type === 'boomer') {

      ctx.lineWidth = r * 0.1; ctx.lineCap = 'round'; ctx.beginPath();
      ctx.moveTo(ex1 - er, ey - er * 1.55); ctx.quadraticCurveTo(ex1, ey - er * 2.0, ex1 + er, ey - er * 1.6);
      ctx.moveTo(ex2 - er * 0.8, ey - er * 1.1); ctx.lineTo(ex2 + er, ey - er * 1.2); ctx.stroke(); ctx.lineCap = 'butt';
    }

    const beak = ctx.createLinearGradient(0, -r * 0.09, 0, r * 0.29);
    beak.addColorStop(0, '#FFDD77'); beak.addColorStop(0.61, '#F9AA31'); beak.addColorStop(1, '#D05B24');
    ctx.lineWidth = Math.max(2, r * 0.082); ctx.fillStyle = beak;
    ctx.beginPath(); ctx.moveTo(r * 0.60, -r * 0.01);
    ctx.quadraticCurveTo(r * 0.84, -r * 0.17, r * 1.21, r * 0.16);
    ctx.quadraticCurveTo(r * 0.91, r * 0.38, r * 0.62, r * 0.26);
    ctx.quadraticCurveTo(r * 0.53, r * 0.13, r * 0.60, -r * 0.01); ctx.fill(); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(r * 0.61, r * 0.13);
    ctx.quadraticCurveTo(r * 0.84, r * 0.22, r * 1.18, r * 0.16); ctx.stroke();

    ctx.fillStyle = 'rgba(255,110,90,0.45)'; ctx.beginPath(); ctx.ellipse(r * 0.35, r * 0.18, r * 0.14, r * 0.08, 0, 0, TAU); ctx.fill();
    const sk = o.skin !== undefined ? o.skin : skin;
    if (sk && sk !== 'none') drawSkin(ctx, r, sk);
    ctx.restore();
  }

  let skin = 'none';
  function setSkin(s) { skin = s || 'none'; }
  function drawSkin(ctx, r, sk) {
    ctx.lineJoin = 'round'; ctx.strokeStyle = OUT; ctx.lineWidth = Math.max(2, r * 0.09);
    if (sk === 'cap') {
      ctx.fillStyle = '#3D8BFD';
      ctx.beginPath(); ctx.arc(-r * 0.05, -r * 0.5, r * 0.68, Math.PI * 1.02, Math.PI * 1.98); ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.fillStyle = '#2A62C4'; ctx.beginPath(); ctx.ellipse(r * 0.78, -r * 0.52, r * 0.42, r * 0.1, 0.12, 0, TAU); ctx.fill(); ctx.stroke();
      ctx.fillStyle = '#fff'; circle(ctx, -r * 0.05, -r * 1.16, r * 0.08); ctx.fill(); ctx.stroke();
    } else if (sk === 'glasses') {
      const ey = -r * 0.22;
      line(ctx, -r * 0.2, ey - r * 0.05, -r * 0.9, ey - r * 0.22);
      ctx.fillStyle = '#1B1B1B';
      rr(ctx, -r * 0.2, ey - r * 0.2, r * 0.5, r * 0.4, r * 0.1); ctx.fill(); ctx.stroke();
      rr(ctx, r * 0.36, ey - r * 0.2, r * 0.46, r * 0.4, r * 0.1); ctx.fill(); ctx.stroke();
      ctx.strokeStyle = 'rgba(255,255,255,0.75)'; ctx.lineWidth = r * 0.06; ctx.lineCap = 'round';
      line(ctx, -r * 0.1, ey - r * 0.09, r * 0.04, ey - r * 0.09); line(ctx, r * 0.46, ey - r * 0.09, r * 0.58, ey - r * 0.09);
      ctx.lineCap = 'butt';
    } else if (sk === 'bandana') {
      ctx.fillStyle = '#E8343A';
      ctx.beginPath(); ctx.moveTo(-r * 0.75, -r * 0.62); ctx.lineTo(-r * 1.32, -r * 0.88); ctx.lineTo(-r * 1.15, -r * 0.5); ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(-r * 0.78, -r * 0.52); ctx.lineTo(-r * 1.36, -r * 0.4); ctx.lineTo(-r * 1.1, -r * 0.2); ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.save(); circle(ctx, 0, 0, r); ctx.clip();
      ctx.fillRect(-r, -r * 0.8, r * 2, r * 0.32);
      ctx.lineWidth = Math.max(1.5, r * 0.06); line(ctx, -r, -r * 0.48, r, -r * 0.48);
      ctx.fillStyle = '#fff'; for (let i = -3; i <= 3; i++) { circle(ctx, i * r * 0.26, -r * 0.64, r * 0.05); ctx.fill(); }
      ctx.restore();
    } else if (sk === 'tophat') {
      ctx.fillStyle = '#2B2B33';
      rr(ctx, -r * 0.42, -r * 1.78, r * 0.84, r * 0.98, r * 0.06); ctx.fill(); ctx.stroke();
      ctx.fillStyle = '#FFC72C'; ctx.fillRect(-r * 0.4, -r * 1.14, r * 0.8, r * 0.17);
      ctx.fillStyle = '#2B2B33'; ctx.beginPath(); ctx.ellipse(0, -r * 0.84, r * 0.74, r * 0.14, 0, 0, TAU); ctx.fill(); ctx.stroke();
    } else if (sk === 'scarf') {

      ctx.save(); circle(ctx, 0, 0, r + 2); ctx.clip();
      ctx.fillStyle = '#E8343A'; ctx.beginPath(); ctx.ellipse(-r * 0.05, r * 0.62, r * 1.05, r * 0.24, 0.08, 0, TAU); ctx.fill(); ctx.stroke();
      ctx.fillStyle = '#FFFFFF'; for (let i = -3; i <= 3; i++) { ctx.fillRect(i * r * 0.3 - r * 0.06, r * 0.45, r * 0.12, r * 0.34); }
      ctx.restore();
      ctx.fillStyle = '#E8343A'; ctx.beginPath(); ctx.moveTo(-r * 0.55, r * 0.6); ctx.quadraticCurveTo(-r * 1.1, r * 0.75, -r * 1.45, r * 0.5); ctx.lineTo(-r * 1.38, r * 0.85); ctx.quadraticCurveTo(-r * 1.0, r * 1.0, -r * 0.5, r * 0.82); ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.fillStyle = '#FFFFFF'; ctx.fillRect(-r * 1.1, r * 0.66, r * 0.1, r * 0.24);
    } else if (sk === 'pilot') {

      ctx.fillStyle = '#8A5A2B';
      ctx.beginPath(); ctx.arc(0, -r * 0.1, r * 0.98, Math.PI * 1.05, Math.PI * 1.95); ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.beginPath(); ctx.ellipse(-r * 0.62, r * 0.05, r * 0.2, r * 0.34, 0.2, 0, TAU); ctx.fill(); ctx.stroke();
      ctx.strokeStyle = 'rgba(255,230,180,0.5)'; ctx.lineWidth = Math.max(1, r * 0.05);
      ctx.beginPath(); ctx.arc(0, -r * 0.1, r * 0.75, Math.PI * 1.15, Math.PI * 1.85); ctx.stroke();
      ctx.strokeStyle = OUT; ctx.lineWidth = Math.max(2, r * 0.09);
      ctx.fillStyle = '#5A3A1A'; rr(ctx, -r * 0.55, -r * 0.82, r * 1.2, r * 0.16, r * 0.06); ctx.fill(); ctx.stroke();
      for (const gx of [-r * 0.12, r * 0.42]) { ctx.fillStyle = '#BFE6FF'; circle(ctx, gx, -r * 0.74, r * 0.2); ctx.fill(); ctx.stroke(); ctx.fillStyle = 'rgba(255,255,255,0.8)'; circle(ctx, gx - r * 0.06, -r * 0.8, r * 0.06); ctx.fill(); }
    } else if (sk === 'crown') {
      ctx.save(); ctx.translate(0, -r * 0.95);
      ctx.fillStyle = '#FFD21F'; ctx.beginPath();
      ctx.moveTo(-r * 0.5, r * 0.12); ctx.lineTo(-r * 0.58, -r * 0.4); ctx.lineTo(-r * 0.28, -r * 0.12); ctx.lineTo(0, -r * 0.52);
      ctx.lineTo(r * 0.28, -r * 0.12); ctx.lineTo(r * 0.58, -r * 0.4); ctx.lineTo(r * 0.5, r * 0.12); ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.fillStyle = '#E8343A'; circle(ctx, 0, -r * 0.05, r * 0.08); ctx.fill();
      ctx.fillStyle = '#3D8BFD'; circle(ctx, -r * 0.3, 0, r * 0.06); ctx.fill(); circle(ctx, r * 0.3, 0, r * 0.06); ctx.fill();
      ctx.restore();
    }
  }

  const DUDE = {
    blue: { a: '#7CC0FF', b: '#2E78E0', belly: '#B8DDFF', dark: '#1D4F9C' },
    red:  { a: '#FF8C7A', b: '#DE3427', belly: '#FFC2B8', dark: '#8E1C14' },
    boss: { a: '#FF7A8A', b: '#B8203A', belly: '#FFC7CF', dark: '#6E1020' },
  };

  function dude(ctx, x, y, r, ang, type, o = {}) {
    const c = DUDE[type] || DUDE.blue, hp = o.hp == null ? 1 : o.hp;
    ctx.save(); ctx.translate(x, y); ctx.rotate(ang);
    if (o.squash) ctx.scale(1 + o.squash, 1 - o.squash);
    ctx.lineJoin = 'round'; ctx.strokeStyle = OUT; ctx.lineWidth = Math.max(2.5, r * 0.11);

    const boots = ctx.createLinearGradient(0, r * 0.76, 0, r * 1.1);
    boots.addColorStop(0, mix(c.b, c.dark, 0.49)); boots.addColorStop(1, c.dark);
    for (const s of [-1, 1]) {
      ctx.fillStyle = boots;
      ctx.beginPath(); ctx.ellipse(s * r * 0.4, r * 0.92, r * 0.32, r * 0.16, s * 0.13, 0, TAU); ctx.fill(); ctx.stroke();
      ctx.strokeStyle = 'rgba(249,231,213,0.36)'; ctx.lineWidth = r * 0.06;
      line(ctx, s * r * 0.47, r * 0.96, s * r * 0.61, r * 0.93);
      ctx.strokeStyle = OUT; ctx.lineWidth = Math.max(2.5, r * 0.11);
    }

    if (type === 'blue') {
      ctx.fillStyle = c.dark; ctx.beginPath();
      ctx.moveTo(-r * 0.35, -r * 0.85); ctx.lineTo(-r * 0.2, -r * 1.3); ctx.lineTo(0, -r * 0.92); ctx.lineTo(r * 0.15, -r * 1.38); ctx.lineTo(r * 0.3, -r * 0.88);
      ctx.closePath(); ctx.fill(); ctx.stroke();
    }

    const g = ctx.createRadialGradient(-r * 0.35, -r * 0.4, r * 0.1, 0, 0, r * 1.05);
    g.addColorStop(0, mix(c.a, '#FFF2DA', 0.26)); g.addColorStop(0.37, c.a); g.addColorStop(1, c.b);
    ctx.fillStyle = g; circle(ctx, 0, 0, r); ctx.fill(); ctx.stroke();
    ctx.save(); circle(ctx, 0, 0, r - ctx.lineWidth / 2); ctx.clip();
    const chin = ctx.createLinearGradient(0, r * 0.24, 0, r);
    chin.addColorStop(0, c.belly); chin.addColorStop(1, mix(c.belly, c.b, 0.51));
    ctx.fillStyle = chin; ctx.beginPath(); ctx.ellipse(0, r * 0.63, r * 0.76, r * 0.43, 0, 0, TAU); ctx.fill();
    for (const side of [-1, 1]) {
      ctx.fillStyle = mix(c.a, '#FFB29F', 0.38);
      ctx.globalAlpha = 0.58;
      ctx.beginPath(); ctx.ellipse(r * 0.68 * side, r * 0.23, r * 0.18, r * 0.12, side * 0.19, 0, TAU); ctx.fill();
      ctx.fillStyle = c.dark; ctx.globalAlpha = 0.57;
      for (let i = 0; i < 3; i++) { circle(ctx, side * r * (0.57 + i * 0.09), r * (0.20 + i % 2 * 0.08), r * 0.029); ctx.fill(); }
    }
    ctx.restore();
    sphereShade(ctx, r, lightAngle() - ang);

    if (type === 'red') {
      const metal = ctx.createLinearGradient(-r * 0.67, -r * 0.93, r * 0.49, -r * 0.37);
      metal.addColorStop(0, '#758393'); metal.addColorStop(0.39, '#E7F2F1');
      metal.addColorStop(0.50, '#ABC1CD'); metal.addColorStop(1, '#516477');
      ctx.fillStyle = metal;
      ctx.beginPath(); ctx.arc(0, -r * 0.18, r * 0.98, Math.PI * 1.08, Math.PI * 1.92); ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.fillStyle = '#526478'; rr(ctx, -r * 1.02, -r * 0.42, r * 2.04, r * 0.2, r * 0.08); ctx.fill(); ctx.stroke();
      for (const x of [-0.82, -0.37, 0.37, 0.82]) rivet(ctx, x * r, -0.32 * r, r * 0.068);
      if (hp < 0.55) { ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(r * 0.1, -r * 1.12); ctx.lineTo(r * 0.25, -r * 0.85); ctx.lineTo(r * 0.12, -r * 0.65); ctx.stroke(); ctx.lineWidth = Math.max(2.5, r * 0.11); }
    }

    if (type === 'boss') {
      ctx.save(); ctx.translate(0, -r * 0.92); if (hp < 0.5) ctx.rotate(-0.35);
      const gold = ctx.createLinearGradient(0, -r * 0.5, 0, r * 0.13);
      gold.addColorStop(0, '#FFF4AD'); gold.addColorStop(0.42, '#F7C94E'); gold.addColorStop(1, '#B66B20');
      ctx.fillStyle = gold; ctx.lineWidth = Math.max(2.5, r * 0.08);
      ctx.beginPath(); ctx.moveTo(-r * 0.55, r * 0.12); ctx.lineTo(-r * 0.62, -r * 0.42); ctx.lineTo(-r * 0.3, -r * 0.14);
      ctx.lineTo(0, -r * 0.55); ctx.lineTo(r * 0.3, -r * 0.14); ctx.lineTo(r * 0.62, -r * 0.42); ctx.lineTo(r * 0.55, r * 0.12); ctx.closePath();
      ctx.fill(); ctx.stroke();
      ctx.strokeStyle = '#FFF1A0'; ctx.lineWidth = r * 0.045;
      line(ctx, -r * 0.46, r * 0.055, r * 0.46, r * 0.055);
      ctx.strokeStyle = OUT;
      ctx.fillStyle = '#3D8BFD'; circle(ctx, 0, -r * 0.05, r * 0.09); ctx.fill();
      ctx.fillStyle = '#E8343A'; circle(ctx, -r * 0.32, 0, r * 0.07); ctx.fill(); circle(ctx, r * 0.32, 0, r * 0.07); ctx.fill();
      ctx.restore();
      ctx.lineWidth = Math.max(2.5, r * 0.11);
    }

    const ey = -r * 0.1, er = r * 0.27, la = (o.look || 0) - ang;
    const lx = Math.cos(la) * er * 0.38, ly = Math.sin(la) * er * 0.38;
    for (const s of [-1, 1]) {
      const ex = s * r * 0.34;
      const swollen = hp < 0.6 && s === -1;
      if (o.blink || (hp < 0.3 && s === 1)) {
        ctx.lineWidth = r * 0.09; ctx.beginPath(); ctx.moveTo(ex - er * 0.8, ey); ctx.lineTo(ex + er * 0.8, ey); ctx.stroke();
      } else {
        if (swollen) { ctx.fillStyle = 'rgba(110,40,150,0.55)'; circle(ctx, ex, ey, er * 1.3); ctx.fill(); }
        eye(ctx, ex, ey, er * (swollen ? 0.86 : 1), lx, ly, type === 'blue' ? '#478DB0' : '#AF683D');
      }
    }

    ctx.lineWidth = r * 0.13; ctx.lineCap = 'round';
    const scared = o.scared;
    ctx.beginPath();
    if (scared || hp < 0.6) { ctx.moveTo(-r * 0.6, -r * 0.42); ctx.lineTo(-r * 0.16, -r * 0.52); ctx.moveTo(r * 0.16, -r * 0.52); ctx.lineTo(r * 0.6, -r * 0.42); }
    else { ctx.moveTo(-r * 0.6, -r * 0.55); ctx.lineTo(-r * 0.14, -r * 0.38); ctx.moveTo(r * 0.14, -r * 0.38); ctx.lineTo(r * 0.6, -r * 0.55); }
    ctx.stroke(); ctx.lineCap = 'butt';

    ctx.lineWidth = r * 0.08;
    if (scared || hp < 0.6) {
      ctx.fillStyle = '#5A1410'; ctx.beginPath(); ctx.ellipse(0, r * 0.35, r * 0.17, r * 0.13, 0, 0, TAU); ctx.fill(); ctx.stroke();
    } else {
      ctx.fillStyle = '#fff';
      ctx.beginPath(); ctx.moveTo(-r * 0.38, r * 0.22); ctx.quadraticCurveTo(0, r * 0.62, r * 0.38, r * 0.22); ctx.closePath(); ctx.fill(); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(0, r * 0.25); ctx.lineTo(0, r * 0.4); ctx.stroke();
    }

    if (type === 'boss') {
      ctx.fillStyle = c.dark; ctx.lineWidth = r * 0.05;
      for (const sd of [-1, 1]) {
        ctx.beginPath(); ctx.moveTo(0, r * 0.18);
        ctx.quadraticCurveTo(sd * r * 0.3, r * 0.05, sd * r * 0.55, r * 0.25);
        ctx.quadraticCurveTo(sd * r * 0.3, r * 0.3, 0, r * 0.24); ctx.closePath(); ctx.fill(); ctx.stroke();
      }
    }

    if (hp < 0.6) {
      ctx.save(); ctx.translate(r * 0.5, r * 0.28); ctx.rotate(0.6);
      ctx.fillStyle = '#F5D9A8'; ctx.lineWidth = 1.5;
      rr(ctx, -r * 0.28, -r * 0.08, r * 0.56, r * 0.16, 3); ctx.fill(); ctx.stroke();
      ctx.rotate(Math.PI / 2); rr(ctx, -r * 0.28, -r * 0.08, r * 0.56, r * 0.16, 3); ctx.fill(); ctx.stroke();
      ctx.restore();
    }
    ctx.restore();

    if (hp < 0.35) {
      const t = o.time || 0;
      ctx.fillStyle = '#FFE14D'; ctx.strokeStyle = OUT; ctx.lineWidth = 1.5;
      for (let i = 0; i < 3; i++) {
        const a = t * 3 + (i * TAU) / 3;
        star(ctx, x + Math.cos(a) * r * 0.9, y - r * 1.35 + Math.sin(a) * r * 0.25, r * 0.18);
        ctx.fill(); ctx.stroke();
      }
    }
  }

  function star(ctx, x, y, r) {
    ctx.beginPath();
    for (let i = 0; i < 10; i++) {
      const a = -Math.PI / 2 + (i * Math.PI) / 5, rad = i % 2 ? r * 0.45 : r;
      ctx.lineTo(x + Math.cos(a) * rad, y + Math.sin(a) * rad);
    }
    ctx.closePath();
  }

  const SX = C.SLING_X, SY = C.SLING_Y;
  const BACK_TIP = { x: SX + 37, y: SY - 22 }, FRONT_TIP = { x: SX - 38, y: SY - 19 };
  const slingTiles = new Map();

  function slingWood(ctx, front) {
    let tile = slingTiles.get(front);
    if (!tile) {
      tile = document.createElement('canvas');
      tile.width = 384; tile.height = 744;
      const c = tile.getContext('2d');
      c.scale(3, 3); c.translate(64, 42);
      const ground = C.GROUND_Y - SY;
      const tip = front ? FRONT_TIP : BACK_TIP;
      const tx = tip.x - SX, ty = tip.y - SY;
      const wood = c.createLinearGradient(-48, 0, 47, 25);
      wood.addColorStop(0, '#9F542E');
      wood.addColorStop(0.23, '#F2BE78');
      wood.addColorStop(0.48, '#B87541');
      wood.addColorStop(0.68, '#88462F');
      wood.addColorStop(0.88, '#CB8F54');
      wood.addColorStop(1, '#753928');

      if (!front) {
        c.save(); c.translate(0, ground + 1); c.scale(1, 0.25);
        const shade = c.createRadialGradient(0, 0, 0, 0, 0, 55);
        shade.addColorStop(0, 'rgba(46,26,22,0.54)');
        shade.addColorStop(1, 'rgba(46,26,22,0)');
        c.fillStyle = shade; c.fillRect(-55, -55, 110, 110); c.restore();

        c.beginPath();
        c.moveTo(-23, ground);
        c.bezierCurveTo(-11, ground - 30, -17, 104, -11, 63);
        c.bezierCurveTo(-6, 44, 11, 41, 19, 21);
        c.bezierCurveTo(26, 5, 24, -10, 25, -25);
        c.quadraticCurveTo(34, -39, 48, -27);
        c.bezierCurveTo(51, 3, 43, 39, 24, 66);
        c.bezierCurveTo(9, 102, 10, ground - 29, 24, ground);
        c.quadraticCurveTo(1, ground + 9, -23, ground);
      } else {
        c.beginPath();
        c.moveTo(-15, 86);
        c.bezierCurveTo(-17, 62, -45, 34, -50, -18);
        c.quadraticCurveTo(-49, -33, -35, -33);
        c.quadraticCurveTo(-26, -32, -25, -21);
        c.bezierCurveTo(-22, 17, -6, 36, 12, 56);
        c.bezierCurveTo(15, 70, 4, 81, -15, 86);
      }
      c.closePath();
      c.strokeStyle = '#452820'; c.lineWidth = 4; c.lineJoin = 'round'; c.lineCap = 'round';
      c.fillStyle = wood; c.fill(); c.stroke();

      c.save(); c.clip();
      c.strokeStyle = 'rgba(255,225,163,.68)'; c.lineWidth = 2.6;
      c.beginPath();
      if (front) {
        c.moveTo(-44, -22); c.bezierCurveTo(-45, 19, -26, 47, -13, 60);
      } else {
        c.moveTo(-13, ground - 7); c.bezierCurveTo(-9, 128, -7, 106, -2, 86);
        c.moveTo(24, 34); c.quadraticCurveTo(34, 13, 31, -16);
      }
      c.stroke();
      c.strokeStyle = 'rgba(81,39,27,.54)'; c.lineWidth = 1.6;
      for (let i = 0; i < 3; i++) {
        c.beginPath();
        if (front) {
          c.moveTo(-40 + i * 4, -6);
          c.quadraticCurveTo(-32 + i * 4, 32, -17 + i * 5, 48 + i * 4);
        } else {
          c.moveTo(-6 + i * 5, ground - 5);
          c.bezierCurveTo(3 + i * 5, 163, -7 + i * 5, 137, 4 + i * 5, 100 + i * 3);
        }
        c.stroke();
      }
      c.restore();

      if (!front) {
        rr(c, -17, ground - 40, 34, 31, 7);
        c.fillStyle = '#27595A'; c.fill(); c.stroke();
        for (let i = 0; i < 3; i++) {
          c.strokeStyle = i === 1 ? '#76A59A' : '#477C75'; c.lineWidth = 2;
          line(c, -12, ground - 34 + i * 7, 12, ground - 37 + i * 7);
        }
      }

      c.save(); c.translate(tx, ty); c.rotate(front ? -0.16 : 0.12);
      const brass = c.createLinearGradient(0, -9, 0, 18);
      brass.addColorStop(0, '#FFF0AE'); brass.addColorStop(0.4, '#E0A756'); brass.addColorStop(1, '#955231');
      rr(c, -12, -8, 24, 28, 7); c.fillStyle = brass;
      c.strokeStyle = '#583127'; c.lineWidth = 3;
      c.fill(); c.stroke();
      rr(c, -11, 6, 22, 10, 3); c.fillStyle = '#2F625E'; c.fill();
      rivet(c, 0, -2, 3.3);
      c.restore();
      slingTiles.set(front, tile);
    }
    ctx.drawImage(tile, SX - 64, SY - 42, 128, 248);
  }

  function slingBand(ctx, tip, grip, front, stretch) {
    const sag = 9 * (1 - stretch);
    ctx.beginPath();
    ctx.moveTo(tip.x, tip.y + 11);
    ctx.quadraticCurveTo((tip.x + grip.x) / 2, (tip.y + grip.y) / 2 + sag, grip.x, grip.y);
    ctx.lineCap = 'round';
    ctx.lineWidth = 11 - 3 * stretch;
    ctx.strokeStyle = '#214440'; ctx.stroke();
    ctx.lineWidth = 6 - 2 * stretch;
    ctx.strokeStyle = front ? '#67B2A5' : '#46847B'; ctx.stroke();
  }

  function slingGrip(pouch, r) {
    const dx = pouch.x - SX, dy = pouch.y - SY, pull = Math.hypot(dx, dy);
    const angle = pouch.angle ?? (pull < 5 ? Math.PI : Math.atan2(dy, dx));
    return {
      x: pouch.x + Math.cos(angle) * r * 0.82,
      y: pouch.y + Math.sin(angle) * r * 0.82,
      angle, stretch: Math.min(1, pull / C.MAX_PULL),
    };
  }

  function slingBack(ctx, pouch, r) {
    slingWood(ctx, false);
    const grip = slingGrip(pouch, r);
    ctx.save();
    slingBand(ctx, BACK_TIP, grip, false, grip.stretch);
    const nearEdge = {
      x: grip.x + Math.sin(grip.angle) * r * 0.26,
      y: grip.y - Math.cos(grip.angle) * r * 0.26,
    };
    slingBand(ctx, FRONT_TIP, nearEdge, true, grip.stretch);
    ctx.restore();
  }

  function slingFront(ctx, pouch, r) {
    const grip = slingGrip(pouch, r);
    ctx.save();
    ctx.translate(grip.x, grip.y); ctx.rotate(grip.angle);
    ctx.beginPath(); ctx.moveTo(-2, -r * 0.45);
    ctx.quadraticCurveTo(12, -r * 0.36, 11, 0);
    ctx.quadraticCurveTo(12, r * 0.36, -2, r * 0.45);
    ctx.quadraticCurveTo(3, 0, -2, -r * 0.45);
    ctx.fillStyle = '#894C35'; ctx.strokeStyle = '#492D27'; ctx.lineWidth = 2.5;
    ctx.fill(); ctx.stroke();
    ctx.strokeStyle = '#EDBB80'; ctx.lineWidth = 1.4;
    ctx.setLineDash([2, 3]);
    ctx.beginPath(); ctx.moveTo(5, -r * 0.28); ctx.quadraticCurveTo(12, 0, 5, r * 0.28); ctx.stroke();
    ctx.restore();
    slingWood(ctx, true);
  }
  function line(ctx, a, b, c, d) { ctx.beginPath(); ctx.moveTo(a, b); ctx.lineTo(c, d); ctx.stroke(); }

  function dots(ctx, pts, color, max) {
    ctx.fillStyle = color;
    const n = Math.min(pts.length, max || pts.length);
    for (let i = 0; i < n; i++) {
      ctx.globalAlpha = max ? 1 - i / n : 0.8;
      circle(ctx, pts[i].x, pts[i].y, max ? 7 - (i / n) * 4 : 4); ctx.fill();
    }
    ctx.globalAlpha = 1;
  }

  const MAT_COLORS = {
    wood: ['#D9A04E', '#B07432', '#8A5524'], glass: ['#CFF0FF', '#9FD6F0', '#FFFFFF'], stone: ['#A9A49B', '#7F7A72', '#C4C0B8'],
    tnt: ['#E2402B', '#7A4A1C', '#FFE14D'],
  };

  function particles(ctx, list) {

    for (let pass = 0; pass < 2; pass++) for (const p of list) {
      if ((p.kind === 'text' || p.kind === 'comic') !== (pass === 1)) continue;
      const k = p.life / p.max;
      ctx.globalAlpha = Math.min(1, k * 2);
      if (p.kind === 'chunk') {
        const z = p.s;
        ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.rot);
        ctx.fillStyle = p.color; ctx.strokeStyle = 'rgba(43,29,14,0.6)'; ctx.lineWidth = 1.5;
        ctx.beginPath();
        if (p.m === 'glass') {
          ctx.moveTo(-z * 0.7, z * 0.45); ctx.lineTo(z * 0.8, z * 0.2); ctx.lineTo(-z * 0.1, -z * 0.8);
          ctx.globalAlpha *= 0.85; ctx.strokeStyle = 'rgba(255,255,255,0.9)';
        } else if (p.m === 'wood') {
          ctx.moveTo(-z, -z * 0.16); ctx.lineTo(z * 0.7, -z * 0.2); ctx.lineTo(z, z * 0.05); ctx.lineTo(z * 0.6, z * 0.2); ctx.lineTo(-z * 0.8, z * 0.18);
        } else if (p.m === 'stone') {
          ctx.moveTo(-z * 0.55, -z * 0.2); ctx.lineTo(-z * 0.1, -z * 0.55); ctx.lineTo(z * 0.5, -z * 0.3); ctx.lineTo(z * 0.55, z * 0.3); ctx.lineTo(-z * 0.2, z * 0.5);
        } else ctx.rect(-z / 2, -z / 3, z, z * 0.66);
        ctx.closePath(); ctx.fill(); ctx.stroke();
        ctx.restore();
      } else if (p.kind === 'hat') {

        ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.rot); ctx.strokeStyle = OUT; ctx.lineWidth = 3; ctx.lineJoin = 'round';
        const z = p.s;
        if (p.t === 'boss') {
          ctx.fillStyle = '#FFD21F'; ctx.beginPath();
          ctx.moveTo(-z * 0.55, z * 0.3); ctx.lineTo(-z * 0.62, -z * 0.3); ctx.lineTo(-z * 0.3, 0); ctx.lineTo(0, -z * 0.45); ctx.lineTo(z * 0.3, 0); ctx.lineTo(z * 0.62, -z * 0.3); ctx.lineTo(z * 0.55, z * 0.3);
          ctx.closePath(); ctx.fill(); ctx.stroke();
        } else {
          ctx.fillStyle = '#B9BEC7'; ctx.beginPath(); ctx.arc(0, 0, z, Math.PI, 0); ctx.closePath(); ctx.fill(); ctx.stroke();
          ctx.fillStyle = '#8B919B'; rr(ctx, -z * 1.05, -z * 0.1, z * 2.1, z * 0.22, 3); ctx.fill(); ctx.stroke();
        }
        ctx.restore();
      } else if (p.kind === 'glow') {
        ctx.globalCompositeOperation = 'screen';
        const g = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.s * 0.62);
        g.addColorStop(0, p.color); g.addColorStop(0.23, p.color); g.addColorStop(1, 'rgba(255,160,40,0)');
        ctx.globalAlpha = Math.min(0.75, k * 1.25);
        ctx.fillStyle = g; circle(ctx, p.x, p.y, p.s * 0.62); ctx.fill();
        ctx.globalCompositeOperation = 'source-over';
        emission(p.x, p.y, p.s * 0.28, p.color, k * 0.89);
      } else if (p.kind === 'feather') {
        ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.rot);
        ctx.fillStyle = p.color; ctx.beginPath(); ctx.ellipse(0, 0, p.s, p.s * 0.35, 0, 0, TAU); ctx.fill();
        ctx.restore();
      } else if (p.kind === 'puff') {
        const r = p.s * (1.6 - k * 0.6);
        const g = ctx.createRadialGradient(p.x + r * theme.light[0] * 0.33, p.y + r * theme.light[1] * 0.30, r * 0.08, p.x, p.y, r);
        g.addColorStop(0, mix(p.color, '#FFF6E4', 0.34)); g.addColorStop(0.46, p.color);
        g.addColorStop(1, 'rgba(255,255,255,0)');
        ctx.fillStyle = g; circle(ctx, p.x, p.y, r); ctx.fill();
      } else if (p.kind === 'spark') {
        ctx.fillStyle = p.color; star(ctx, p.x, p.y, p.s * (0.62 + k * 0.38)); ctx.fill();
        ctx.fillStyle = '#FFF7D3'; circle(ctx, p.x, p.y, p.s * 0.21); ctx.fill();
        emission(p.x, p.y, p.s * 0.64, p.color, k * 0.76);
      } else if (p.kind === 'ring') {
        ctx.strokeStyle = p.color; ctx.lineWidth = 14 * k; circle(ctx, p.x, p.y, p.s * (1 - k) + 20); ctx.stroke();
      } else if (p.kind === 'confetti') {
        ctx.save(); ctx.translate(p.x + Math.sin(p.rot * 0.7) * 6, p.y); ctx.rotate(p.rot);
        ctx.scale(1, Math.cos(p.rot * 1.3)); ctx.fillStyle = p.color; ctx.fillRect(-p.s / 2, -p.s / 4, p.s, p.s / 2);
        ctx.restore();
      } else if (p.kind === 'comic') {

        const pop = Math.min(1, (1 - k) * 7);
        ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.rot); ctx.scale(pop, pop);
        ctx.fillStyle = p.color; ctx.strokeStyle = OUT; ctx.lineWidth = 5; ctx.lineJoin = 'round';
        ctx.beginPath();
        for (let i = 0; i < 22; i++) { const a = (i * TAU) / 22, rad = i % 2 ? p.s * 0.66 : p.s; ctx.lineTo(Math.cos(a) * rad * 1.3, Math.sin(a) * rad * 0.82); }
        ctx.closePath(); ctx.fill(); ctx.stroke();
        ctx.font = `900 ${Math.round(p.s * 0.5)}px "Trebuchet MS", "Arial Rounded MT Bold", system-ui, sans-serif`;
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.lineWidth = 7; ctx.strokeStyle = '#FFFFFF'; ctx.strokeText(p.text, 0, 2);
        ctx.fillStyle = OUT; ctx.fillText(p.text, 0, 2);
        ctx.restore();
      } else if (p.kind === 'text') {

        const pop = 1 + 0.45 * Math.max(0, (k - 0.78) / 0.22);
        ctx.font = `900 ${Math.round(p.s * pop)}px "Trebuchet MS", "Arial Rounded MT Bold", system-ui, sans-serif`;
        ctx.textAlign = 'center'; ctx.lineJoin = 'round';
        ctx.lineWidth = 7; ctx.strokeStyle = OUT; ctx.strokeText(p.text, p.x, p.y);
        ctx.fillStyle = p.color; ctx.fillText(p.text, p.x, p.y);
      }
    }
    ctx.globalAlpha = 1;
  }

  function bubble(ctx, x, y, text, k) {
    const s = 0.6 + 0.4 * Math.min(1, k * 4);
    ctx.save(); ctx.translate(x, y); ctx.scale(s, s);
    ctx.font = '900 26px "Trebuchet MS", system-ui, sans-serif';
    const w = ctx.measureText(text).width + 30, h = 42;
    ctx.fillStyle = '#FFFFFF'; ctx.strokeStyle = OUT; ctx.lineWidth = 4;
    rr(ctx, -w / 2, -h - 14, w, h, 16); ctx.fill(); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(-10, -16); ctx.lineTo(0, 0); ctx.lineTo(10, -16); ctx.closePath(); ctx.fill();
    ctx.beginPath(); ctx.moveTo(-10, -14); ctx.lineTo(0, 0); ctx.lineTo(10, -14); ctx.stroke();
    ctx.fillStyle = '#FFFFFF'; ctx.fillRect(-12, -20, 24, 8);
    ctx.fillStyle = OUT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(text, 0, -h / 2 - 14);
    ctx.restore();
  }

  function aura(ctx, x, y, r, t) {
    const k = 1 + Math.sin(t * 8) * 0.08;
    const g = ctx.createRadialGradient(x, y, r * 0.8, x, y, r * 1.7 * k);
    g.addColorStop(0, 'rgba(255,90,30,0.55)'); g.addColorStop(1, 'rgba(255,200,40,0)');
    ctx.fillStyle = g; circle(ctx, x, y, r * 1.7 * k); ctx.fill();
    emission(x, y, r * 0.78, '#FFC356', 0.54);
  }

  function nukeTarget(ctx, x, y, R, t, alpha = 1) {
    ctx.save(); ctx.globalAlpha = alpha;
    const pulse = 0.5 + Math.sin(t * 6) * 0.5;
    ctx.strokeStyle = `rgba(255,60,30,${0.35 + pulse * 0.3})`; ctx.lineWidth = 6; ctx.setLineDash([22, 16]);
    circle(ctx, x, y, R); ctx.stroke(); ctx.setLineDash([]);
    ctx.fillStyle = 'rgba(255,80,30,0.10)'; circle(ctx, x, y, R); ctx.fill();
    ctx.strokeStyle = 'rgba(255,40,20,0.9)'; ctx.lineWidth = 5;
    circle(ctx, x, y, 34 + pulse * 6); ctx.stroke();
    line(ctx, x - 60, y, x - 18, y); line(ctx, x + 18, y, x + 60, y); line(ctx, x, y - 60, x, y - 18); line(ctx, x, y + 18, x, y + 60);
    ctx.restore();
  }

  function nukeBomb(ctx, x, y, t) {
    const tilt = Math.sin(t * 9) * 0.06;
    emission(x + 44 * Math.cos(tilt) + 98 * Math.sin(tilt), y + 44 * Math.sin(tilt) - 98 * Math.cos(tilt), 15, '#FFD454', 0.85);
    ctx.save(); ctx.translate(x, y); ctx.rotate(tilt);
    ctx.lineJoin = 'round'; ctx.lineCap = 'round';

    ctx.strokeStyle = 'rgba(255,255,255,0.7)'; ctx.lineWidth = 4;
    for (const dx of [-30, 0, 30]) line(ctx, dx, -120, dx, -210 - Math.abs(dx) * 2);

    ctx.strokeStyle = '#8A5A2B'; ctx.lineWidth = 7;
    ctx.beginPath(); ctx.moveTo(30, -48); ctx.quadraticCurveTo(52, -78, 44, -96); ctx.stroke();
    const fl = 1 + Math.sin(t * 40) * 0.25;
    ctx.fillStyle = '#FFF3A0'; circle(ctx, 44, -98, 9 * fl); ctx.fill();
    ctx.fillStyle = '#FF9A1F'; circle(ctx, 44, -98, 5 * fl); ctx.fill();

    const g = ctx.createRadialGradient(-20, -22, 6, 0, 0, 70);
    g.addColorStop(0, '#6B5BA8'); g.addColorStop(0.5, '#3A2F66'); g.addColorStop(1, '#1E1838');
    ctx.fillStyle = g; ctx.strokeStyle = OUT; ctx.lineWidth = 5;
    circle(ctx, 0, 0, 60); ctx.fill(); ctx.stroke();

    ctx.fillStyle = '#C9A13A'; ctx.save(); ctx.translate(26, -48); ctx.rotate(0.5);
    ctx.fillRect(-12, -9, 24, 16); ctx.strokeRect(-12, -9, 24, 16); ctx.restore();

    ctx.fillStyle = 'rgba(255,255,255,0.35)'; ctx.beginPath(); ctx.ellipse(-24, -26, 16, 9, -0.6, 0, TAU); ctx.fill();

    ctx.save(); circle(ctx, 0, 0, 58); ctx.clip();
    ctx.fillStyle = '#FFC72C'; ctx.fillRect(-62, 8, 124, 16); ctx.restore();
    ctx.fillStyle = '#FFF1A8'; star(ctx, 0, 16, 12); ctx.fill(); ctx.stroke();

    ctx.fillStyle = '#FFD21F'; ctx.lineWidth = 4;
    ctx.beginPath(); ctx.moveTo(-30, -50); ctx.lineTo(-34, -84); ctx.lineTo(-16, -66); ctx.lineTo(0, -92); ctx.lineTo(16, -66); ctx.lineTo(30, -84); ctx.lineTo(26, -50); ctx.closePath(); ctx.fill(); ctx.stroke();
    ctx.fillStyle = '#FF4D6D'; circle(ctx, 0, -62, 5); ctx.fill();
    ctx.fillStyle = '#4DC3FF'; circle(ctx, -18, -58, 4); ctx.fill(); circle(ctx, 16, -58, 4); ctx.fill();
    ctx.restore();
  }

  root.YB = Object.assign(root.YB || {}, {
    Render: { beginBloom, finishFrame, impactLight, flightTrail, foreground, verge, setBgScale, setDetail, groundFx, setSkin, ambient, decals, bubble, blockSides, background, statics, block, setTheme, surfaceY, chick, dude, slingBack, slingFront, dots, particles, star, rr, aura, nukeTarget, nukeBomb, MAT_COLORS, CHICK, OUT },
  });
})(window);
