(function (root) {
  'use strict';
  const G = 960;

  const post = (x, base, h, m = 'wood', w = 22) => ({ k: 'block', m, x, y: base - h / 2, w, h });
  const beam = (x, base, w, m = 'wood', h = 22) => ({ k: 'block', m, x, y: base - h / 2, w, h });
  const tri = (x, base, w, h, m = 'wood') => ({ k: 'block', m, shape: 'tri', x, y: base - h / 2, w, h });
  const tnt = (x, base, s = 44) => ({ k: 'block', m: 'tnt', x, y: base - s / 2, w: s, h: s });
  const boulder = (x, base, r = 30) => ({ k: 'block', m: 'stone', shape: 'circle', x, y: base - r, w: r * 2, h: r * 2 });
  const R = { blue: 30, red: 34, boss: 46 };
  const enemy = (x, base, t = 'blue') => ({ k: 'enemy', t, x, y: base - R[t] - 1 });

  const ledge = (x, top, w) => ({ x, y: (top + G) / 2, w, h: G - top });
  const ramp = (x0, x1, top) => ({ tri: [[x0, G], [x1, G], [x1, top]] });
  const span = (x, base, width, height, left = 'wood', right = left, cap = 'wood', deck = 24) => [
    post(x - width / 2, base, height, left, 24),
    post(x + width / 2, base, height, right, 24),
    beam(x, base - height, width + 40, cap, deck),
  ];
  const shelter = (x, base, width, height, type, left, right, cap, deck) => [
    ...span(x, base, width, height, left, right, cap, deck),
    enemy(x, base, type),
  ];

  const LEVELS = [

    {
      id: 1, nameKey: 'lvl1',
      birds: ['normal', 'normal', 'normal'],
      stars: [0, 18000, 23000],
      theme: 'noon',
      statics: [],
      items: [
        tnt(885, G, 82), tnt(1040, G),

        post(975, G, 110, 'glass'), post(1075, G, 110, 'glass'), beam(1025, G - 110, 150),
        enemy(1025, G - 132, 'blue'),

        post(1250, G, 130, 'glass'), post(1370, G, 130, 'glass'), beam(1310, G - 130, 170),
        enemy(1310, G, 'blue'),
        post(1270, G - 152, 60), post(1350, G - 152, 60), beam(1310, G - 212, 120),
        tri(1310, G - 234, 140, 46),
      ],
    },

    {
      id: 2, nameKey: 'lvl2',
      birds: ['normal', 'speed', 'normal', 'speed'],
      stars: [0, 34000, 45000],
      startHint: 'hintTnt', theme: 'noon',
      statics: [],
      items: [
        tnt(1150, G, 54), tnt(1335, G),

        post(1240, G, 120), post(1370, G, 120, 'glass'), post(1460, G, 120),
        beam(1350, G - 120, 262),
        enemy(1280, G, 'blue'), enemy(1415, G, 'blue'),

        post(1270, G - 142, 100, 'glass'), post(1430, G - 142, 100, 'glass'),
        beam(1350, G - 242, 200),
        enemy(1350, G - 142, 'red'),
        post(1350, G - 264, 50, 'stone', 50),
        tri(1350, G - 314, 80, 36),

        post(1620, G, 80, 'stone', 30), post(1740, G, 80, 'stone', 30),
        beam(1680, G - 80, 180, 'wood', 24),
        enemy(1680, G, 'blue'),
        tnt(1680, G - 104, 40),
      ],
    },

    {
      id: 3, nameKey: 'lvl3',
      birds: ['normal', 'speed', 'bomb', 'speed', 'bomb'],
      stars: [0, 40000, 52000],
      startHint: 'hintTerrace', theme: 'noon',
      statics: [{ x: 1560, y: 880, w: 560, h: 160 }],
      items: [
        tnt(1135, G),

        post(1000, G, 160), post(1100, G, 160), beam(1050, G - 160, 150),
        enemy(1050, G, 'blue'),
        post(1015, G - 182, 70, 'glass'), post(1085, G - 182, 70, 'glass'),
        beam(1050, G - 252, 110, 'glass'),
        tri(1050, G - 274, 120, 40, 'glass'),

        post(1320, 800, 130, 'stone', 28), post(1440, 800, 130, 'stone', 28),
        beam(1380, 670, 160, 'stone'),
        enemy(1380, 800, 'red'),
        post(1500, 800, 130), post(1620, 800, 130),
        beam(1560, 670, 160),
        enemy(1560, 800, 'blue'),
        post(1680, 800, 130, 'glass'), post(1800, 800, 130, 'glass'),
        beam(1740, 670, 160),
        enemy(1740, 800, 'red'),

        post(1410, 648, 90), post(1710, 648, 90),
        beam(1560, 558, 340),
        enemy(1560, 536, 'blue'),
        boulder(1690, 536, 26),
      ],
    },

    {
      id: 4, nameKey: 'lvl4',
      birds: ['normal', 'split', 'bomb', 'normal', 'speed'],
      stars: [0, 46000, 58000],
      theme: 'noon',
      statics: [],
      items: [

        post(1090, G, 120, 'stone', 26), post(1210, G, 120, 'stone', 26), beam(1150, G - 120, 170),
        enemy(1150, G, 'blue'),
        post(1100, G - 142, 100), post(1200, G - 142, 100), beam(1150, G - 242, 150),
        enemy(1150, G - 142, 'red'),
        post(1115, G - 264, 70, 'glass'), post(1185, G - 264, 70, 'glass'), beam(1150, G - 334, 110, 'glass'),
        enemy(1150, G - 356, 'blue'),

        post(1300, G, 70), post(1400, G, 70), beam(1350, G - 70, 130, 'stone'),
        enemy(1350, G, 'blue'),
        tnt(1350, G - 92, 40),

        post(1480, G, 130, 'glass'), post(1620, G, 130, 'glass'), beam(1550, G - 130, 180, 'stone', 24),
        enemy(1550, G, 'red'),
        post(1490, G - 154, 110), post(1610, G - 154, 110), beam(1550, G - 264, 160),
        enemy(1550, G - 154, 'blue'),
        tri(1550, G - 286, 170, 56, 'glass'),
      ],
    },

    {
      id: 5, nameKey: 'lvl5',
      birds: ['speed', 'normal', 'bomb', 'speed', 'normal'],
      stars: [0, 42000, 54000],
      theme: 'sunset',
      statics: [{ x: 1500, y: 830, w: 500, h: 260 }],
      items: [

        post(1000, G, 90, 'glass'), post(1100, G, 90, 'glass'), beam(1050, G - 90, 150, 'glass'),
        enemy(1050, G, 'blue'),
        enemy(1050, G - 112, 'blue'),

        post(1290, 700, 150, 'stone', 30),
        tnt(1336, 700, 40),
        post(1380, 700, 120, 'stone', 26), post(1500, 700, 120, 'stone', 26), beam(1440, 580, 160, 'stone', 24),
        enemy(1440, 700, 'red'),
        post(1580, 700, 120), post(1700, 700, 120), beam(1640, 580, 160),
        enemy(1640, 700, 'blue'),
        enemy(1440, 556, 'red'),
        enemy(1640, 558, 'blue'),
      ],
    },

    {
      id: 6, nameKey: 'lvl6',
      birds: ['normal', 'speed', 'bomb', 'speed', 'bomb'],
      stars: [0, 52000, 64000],
      startHint: 'hintBoss', theme: 'sunset', mood: 'boss',
      statics: [],
      items: [

        post(1100, G, 100), post(1200, G, 100), beam(1150, G - 100, 140),
        enemy(1150, G, 'red'),
        enemy(1150, G - 122, 'blue'),

        post(1330, G, 140, 'stone', 28), post(1500, G, 140, 'stone', 28), post(1670, G, 140, 'stone', 28),
        beam(1500, G - 140, 380, 'stone', 24),
        enemy(1415, G, 'blue'), enemy(1585, G, 'blue'),
        tnt(1364, G, 38), tnt(1636, G, 38),

        post(1390, G - 164, 120, 'stone', 26), post(1610, G - 164, 120, 'stone', 26), beam(1500, G - 284, 260),
        enemy(1500, G - 164, 'boss'),

        post(1440, G - 306, 60, 'glass'), post(1560, G - 306, 60, 'glass'), beam(1500, G - 366, 160, 'glass'),
        enemy(1500, G - 388, 'red'),
      ],
    },

    {
      id: 7, nameKey: 'lvl7',
      birds: ['normal', 'speed', 'bomb', 'normal'],
      stars: [0, 36000, 46000],
      startHint: 'hintBoosters', theme: 'sunset',
      statics: [{ x: 1700, y: 870, w: 360, h: 180 }],
      items: [

        post(900, G, 110), post(1000, G, 110), beam(950, G - 110, 140),
        enemy(950, G, 'blue'), enemy(950, G - 132, 'blue'),
        tnt(1250, G),

        post(1310, G, 180, 'glass'), post(1390, G, 180, 'glass'), beam(1350, G - 180, 120),
        enemy(1350, G - 202, 'red'),

        post(1620, 780, 110, 'stone', 28), post(1760, 780, 110, 'stone', 28), beam(1690, 670, 190),
        enemy(1690, 780, 'red'), enemy(1690, 648, 'blue'),
        boulder(1562, 780, 28),
      ],
    },

    {
      id: 8, nameKey: 'lvl8',
      birds: ['speed', 'split', 'bomb', 'normal'],
      stars: [0, 42000, 54000],
      theme: 'sunset',
      statics: [{ x: 1880, y: 890, w: 70, h: 140 }],
      items: [

        post(920, G, 200, 'glass'), post(980, G, 200, 'glass'), beam(950, G - 200, 110),
        enemy(950, G - 222, 'blue'),
        tnt(1150, G),

        post(1330, G, 130, 'glass'), post(1450, G, 130, 'glass'), post(1570, G, 130, 'glass'),
        beam(1450, G - 130, 270, 'stone', 24),
        enemy(1390, G, 'blue'), enemy(1510, G, 'blue'),
        post(1360, G - 154, 110, 'glass'), post(1540, G - 154, 110, 'glass'), beam(1450, G - 264, 210),
        enemy(1450, G - 154, 'red'),
        post(1395, G - 286, 80, 'glass'), post(1505, G - 286, 80, 'glass'), beam(1450, G - 366, 140, 'glass'),
        enemy(1450, G - 388, 'blue'),

        post(1690, G, 80, 'wood', 26),
        enemy(1750, G, 'red'),
        tnt(1640, G, 40),
      ],
    },

    {
      id: 9, nameKey: 'lvl9',
      birds: ['normal', 'bomb', 'speed', 'normal', 'bomb'],
      stars: [0, 42000, 54000],
      startHint: 'hintBoulder', theme: 'dusk',
      statics: [{ x: 1120, y: 870, w: 260, h: 180 }, { x: 1720, y: 870, w: 300, h: 180 }],
      items: [

        beam(1410, 780, 380),
        enemy(1350, 758, 'blue'), enemy(1470, 758, 'blue'),
        enemy(1410, G, 'blue'),
        boulder(1262, 758, 26),
        tnt(1330, G, 40),

        post(1040, 780, 100), post(1140, 780, 100), beam(1090, 680, 130, 'stone'),
        enemy(1090, 780, 'red'),

        post(1660, 780, 120, 'stone', 28), post(1800, 780, 120, 'stone', 28), beam(1730, 660, 180, 'stone', 24),
        enemy(1730, 780, 'red'), enemy(1730, 636, 'blue'),
      ],
    },

    {
      id: 10, nameKey: 'lvl10',
      birds: ['bomb', 'normal', 'bomb'],
      stars: [0, 35000, 46000],
      theme: 'dusk',
      statics: [],
      items: [

        post(940, G, 90, 'stone', 30), post(1060, G, 90, 'stone', 30), beam(1000, G - 90, 160, 'stone', 26),
        enemy(1000, G, 'red'),
        tnt(1175, G),

        post(1290, G, 90, 'stone', 30), post(1410, G, 90, 'stone', 30), beam(1350, G - 90, 160, 'stone', 26),
        enemy(1350, G, 'red'),
        post(1300, G - 116, 70, 'glass'), post(1400, G - 116, 70, 'glass'), beam(1350, G - 186, 130, 'glass'),
        enemy(1350, G - 116, 'blue'),
        tnt(1540, G),

        post(1660, G, 90, 'stone', 30), post(1780, G, 90, 'stone', 30), beam(1720, G - 90, 160, 'wood', 24),
        enemy(1720, G, 'blue'), enemy(1720, G - 114, 'blue'),
      ],
    },

    {
      id: 11, nameKey: 'lvl11',
      birds: ['normal', 'split', 'bomb', 'speed', 'normal'],
      stars: [0, 48000, 60000],
      theme: 'dusk',
      statics: [],
      items: [

        post(950, G, 70, 'stone', 40),
        enemy(1010, G, 'blue'),

        post(1370, G, 110, 'stone', 26), post(1530, G, 110, 'stone', 26), beam(1450, G - 110, 200),
        enemy(1450, G, 'red'),
        post(1380, G - 132, 110), post(1520, G - 132, 110), beam(1450, G - 242, 180),
        enemy(1450, G - 132, 'blue'),
        post(1390, G - 264, 110, 'glass'), post(1510, G - 264, 110, 'glass'), beam(1450, G - 374, 160, 'stone'),
        enemy(1450, G - 264, 'blue'),
        post(1400, G - 396, 100), post(1500, G - 396, 100), beam(1450, G - 496, 140),
        enemy(1450, G - 396, 'red'),
        enemy(1450, G - 518, 'blue'),
        tnt(1600, G, 40),

        post(1750, G, 80, 'glass'), post(1850, G, 80, 'glass'), beam(1800, G - 80, 130),
        enemy(1800, G, 'blue'),
        tri(1800, G - 102, 150, 50),
      ],
    },

    {
      id: 12, nameKey: 'lvl12',
      birds: ['normal', 'speed', 'bomb', 'speed', 'bomb'],
      stars: [0, 50000, 62000],
      startHint: 'hintBoss2', theme: 'dusk', mood: 'boss',
      statics: [{ x: 1600, y: 860, w: 480, h: 200 }, { tri: [[1250, 960], [1360, 960], [1360, 760]] }],
      items: [

        post(1000, G, 110), post(1100, G, 110), beam(1050, G - 110, 140, 'stone'),
        enemy(1050, G, 'blue'), enemy(1050, G - 132, 'blue'),

        post(1420, 760, 130, 'stone', 28), post(1600, 760, 130, 'stone', 28), post(1780, 760, 130, 'stone', 28),
        beam(1600, 630, 400, 'stone', 26),
        enemy(1510, 760, 'blue'), enemy(1690, 760, 'red'),
        tnt(1455, 760, 38), tnt(1745, 760, 38),
        boulder(1384, 760, 20),

        post(1490, 604, 130, 'stone', 26), post(1710, 604, 130, 'stone', 26), beam(1600, 474, 260),
        enemy(1600, 604, 'boss'),
        enemy(1600, 452, 'red'),
      ],
    },

    {
      id: 13, nameKey: 'lvl13',
      birds: ['normal', 'speed', 'bomb', 'normal'],
      stars: [0, 36000, 46000],
      startHint: 'hintDomino', theme: 'night',
      statics: [{ x: 1790, y: 880, w: 200, h: 160 }],
      items: [

        post(960, G, 150), post(1045, G, 150), post(1130, G, 150), post(1215, G, 150), post(1300, G, 150),
        post(1400, G, 100, 'glass'), tnt(1400, G - 100, 36),

        post(1500, G, 110, 'glass'), post(1620, G, 110, 'glass'), beam(1560, G - 110, 170),
        enemy(1560, G, 'blue'), enemy(1560, G - 132, 'red'),

        post(1730, 800, 90, 'stone', 26), post(1850, 800, 90, 'stone', 26), beam(1790, 710, 170, 'wood', 24),
        enemy(1790, 800, 'red'), enemy(1790, 686, 'blue'),

        enemy(880, G, 'blue'),
      ],
    },

    {
      id: 14, nameKey: 'lvl14',
      birds: ['split', 'speed', 'bomb'],
      stars: [0, 44000, 56000],
      theme: 'night',
      statics: [],
      items: [

        post(1150, G, 190, 'stone', 34),

        post(1240, G, 110), post(1410, G, 110), post(1580, G, 110), beam(1410, G - 110, 380),
        enemy(1325, G, 'red'), enemy(1495, G, 'blue'),

        tnt(1290, G - 132, 40), enemy(1350, G - 132, 'blue'), tnt(1410, G - 132, 40), enemy(1470, G - 132, 'blue'), tnt(1530, G - 132, 40),
        post(1240, G - 132, 80, 'glass'), post(1580, G - 132, 80, 'glass'), beam(1410, G - 212, 380, 'stone', 22),
        enemy(1410, G - 234, 'red'),

        post(1730, G, 90, 'stone', 28), post(1850, G, 90, 'stone', 28), beam(1790, G - 90, 170, 'wood', 24),
        enemy(1790, G, 'red'),
      ],
    },

    {
      id: 15, nameKey: 'lvl15',
      birds: ['normal', 'speed', 'bomb', 'speed', 'bomb', 'normal'],
      stars: [0, 54000, 66000],
      startHint: 'hintBoss3', theme: 'night', mood: 'boss',

      statics: [{ x: 1375, y: 890, w: 250, h: 140 }, { x: 1690, y: 830, w: 380, h: 260 }, { tri: [[1140, 960], [1250, 960], [1250, 820]] }],
      items: [

        post(950, G, 100), post(1050, G, 100), beam(1000, G - 100, 140),
        enemy(1000, G, 'blue'),
        boulder(1000, G - 122, 26),

        post(1300, 820, 90, 'stone', 28), post(1420, 820, 90, 'stone', 28), beam(1360, 730, 170, 'stone', 24),
        enemy(1360, 820, 'red'), enemy(1360, 706, 'blue'),
        tnt(1463, 820, 38),

        enemy(1548, 700, 'blue'),
        post(1610, 700, 130, 'stone', 28), post(1790, 700, 130, 'stone', 28), beam(1700, 570, 240, 'wood', 24),
        enemy(1700, 700, 'boss'),
        post(1650, 546, 80, 'glass'), post(1750, 546, 80, 'glass'), beam(1700, 466, 150, 'glass'),
        enemy(1700, 546, 'red'),
        tri(1700, 444, 140, 44),
        tnt(1840, 700, 36),
      ],
    },

    {
      id: 16, nameKey: 'lvl16',
      birds: ['heavy', 'normal', 'heavy', 'normal'],
      theme: 'winter',
      statics: [],
      items: [

        post(1000, G, 80, 'stone', 30), post(1120, G, 80, 'stone', 30), beam(1060, G - 80, 190, 'stone', 30),
        enemy(1060, G, 'blue'),

        post(1310, G, 110, 'wood', 26), post(1450, G, 110, 'wood', 26), beam(1380, G - 110, 200, 'stone', 28),
        enemy(1380, G, 'red'),
        post(1330, G - 138, 70, 'glass'), post(1430, G - 138, 70, 'glass'), beam(1380, G - 208, 140, 'stone', 24),
        enemy(1380, G - 138, 'blue'),
        post(1620, G, 110, 'wood', 26), post(1760, G, 110, 'wood', 26), beam(1690, G - 110, 200, 'stone', 28),
        enemy(1690, G, 'blue'),
        tri(1690, G - 138, 180, 50, 'wood'),
        tnt(1535, G, 40),
      ],
    },

    {
      id: 17, nameKey: 'lvl17',
      birds: ['heavy', 'speed', 'heavy', 'bomb', 'normal'],
      startHint: 'hintWell', theme: 'winter',
      statics: [{ x: 1500, y: 860, w: 420, h: 200 }],
      items: [

        post(980, G, 120, 'glass'), post(1080, G, 120, 'glass'), beam(1030, G - 120, 150),
        enemy(1030, G, 'blue'), enemy(1030, G - 142, 'blue'),

        post(1360, 760, 200, 'stone', 34), post(1640, 760, 200, 'stone', 34),
        enemy(1440, 760, 'red'), enemy(1560, 760, 'red'),
        boulder(1500, 760, 24),
        beam(1500, 560, 316, 'wood', 22),
        enemy(1500, 538, 'blue'),

        post(1760, G, 90, 'stone', 26), post(1860, G, 90, 'stone', 26), beam(1810, G - 90, 140, 'wood', 24),
        enemy(1810, G, 'blue'),
      ],
    },

    {
      id: 18, nameKey: 'lvl18',
      birds: ['boomer', 'normal', 'boomer', 'speed', 'normal'],
      startHint: 'hintWall', theme: 'winter',
      statics: [],
      items: [

        post(1250, G, 270, 'stone', 46),
        enemy(1250, G - 270, 'blue'),

        post(1300, G, 120, 'stone', 24), post(1530, G, 120, 'glass', 18), beam(1415, G - 120, 260, 'stone', 30),
        enemy(1370, G, 'blue'), enemy(1455, G, 'blue'),
        enemy(1415, G - 150, 'red'),

        post(1780, G, 90, 'wood', 24), post(1880, G, 90, 'wood', 24), beam(1830, G - 90, 140, 'wood', 24),
        enemy(1830, G, 'blue'),
      ],
    },

    {
      id: 19, nameKey: 'lvl19',
      birds: ['heavy', 'boomer', 'split', 'bomb', 'normal'],
      theme: 'winter',
      statics: [{ x: 1600, y: 870, w: 520, h: 180 }, { tri: [[1240, 960], [1340, 960], [1340, 780]] }],
      items: [

        post(980, G, 160, 'glass'), post(1060, G, 160, 'glass'), beam(1020, G - 160, 120, 'glass'),
        enemy(1020, G - 182, 'blue'),
        enemy(1020, G, 'blue'),

        post(1390, 780, 150, 'stone', 36),
        post(1460, 780, 110), post(1600, 780, 110), beam(1530, 670, 200, 'stone', 26),
        enemy(1530, 780, 'red'),
        post(1480, 644, 80, 'glass'), post(1580, 644, 80, 'glass'), beam(1530, 564, 140, 'wood'),
        enemy(1530, 644, 'blue'),

        post(1680, 780, 110, 'stone', 26), post(1840, 780, 110, 'glass', 20), beam(1760, 670, 190, 'stone', 26),
        tnt(1720, 780, 38), enemy(1785, 780, 'red'),
      ],
    },

    {
      id: 20, nameKey: 'lvl20',
      birds: ['heavy', 'speed', 'boomer', 'bomb', 'heavy'],
      theme: 'winter',
      statics: [{ x: 1640, y: 850, w: 440, h: 220 }],
      items: [

        post(980, G, 100, 'stone', 28), post(1100, G, 100, 'stone', 28), beam(1040, G - 100, 180, 'stone', 26),
        enemy(1040, G, 'red'), enemy(1040, G - 126, 'blue'),
        tnt(1230, G, 40),

        post(1450, 740, 140, 'glass'), post(1830, 740, 140, 'glass'),
        post(1520, 740, 140, 'stone', 28), post(1760, 740, 140, 'stone', 28), beam(1640, 600, 360, 'stone', 28),
        enemy(1640, 740, 'red'),
        enemy(1485, 740, 'blue'),
        post(1560, 572, 100), post(1720, 572, 100), beam(1640, 472, 220, 'wood'),
        enemy(1640, 572, 'red'),
        tri(1640, 450, 200, 56, 'glass'),
      ],
    },

    {
      id: 21, nameKey: 'lvl21',
      birds: ['puff', 'normal', 'puff', 'speed', 'bomb', 'normal'],
      startHint: 'hintLedges', theme: 'volcano',

      statics: [{ x: 1200, y: 830, w: 110, h: 260 }, { x: 1480, y: 790, w: 150, h: 340 }, { x: 1760, y: 830, w: 110, h: 260 }],
      items: [
        ...shelter(970, G, 130, 105, 'blue', 'glass', 'wood', 'wood'),
        enemy(970, G - 129, 'blue'),
        enemy(1200, 700, 'blue'),
        enemy(1445, 620, 'red'), enemy(1518, 620, 'blue'),
        enemy(1760, 700, 'red'),

        post(1300, G, 80, 'glass'), post(1380, G, 80, 'glass'), beam(1340, G - 80, 120),
        enemy(1340, G, 'blue'),
        tnt(1340, G - 102, 36),
        tnt(1620, G, 40),
      ],
    },

    {
      id: 22, nameKey: 'lvl22',
      birds: ['puff', 'heavy', 'boomer', 'normal', 'speed', 'normal'],
      theme: 'volcano',
      statics: [{ x: 1110, y: 850, w: 220, h: 220 }, { x: 1750, y: 850, w: 260, h: 220 }],
      items: [

        beam(1420, 740, 470, 'wood', 24),
        enemy(1330, 718, 'blue'), enemy(1430, 718, 'red'), enemy(1530, 718, 'blue'),

        post(1380, G, 90, 'wood', 24), post(1480, G, 90, 'wood', 24), beam(1430, G - 90, 150, 'wood', 24),
        enemy(1430, G, 'red'),

        post(1680, 740, 100, 'glass', 24), post(1800, 740, 100, 'wood', 24), beam(1740, 640, 180, 'wood', 24),
        enemy(1740, 740, 'blue'),
        tnt(1080, 740, 38),
      ],
    },

    {
      id: 23, nameKey: 'lvl23',
      birds: ['split', 'puff', 'boomer', 'heavy', 'bomb', 'speed', 'normal'],
      theme: 'volcano',
      statics: [],
      items: [

        post(1000, G, 240, 'glass', 24), post(1080, G, 240, 'glass', 24), beam(1040, G - 240, 130, 'wood'),
        enemy(1040, G - 262, 'blue'),
        post(1240, G, 320, 'glass', 24), post(1320, G, 320, 'glass', 24), beam(1280, G - 320, 130, 'wood'),
        enemy(1280, G - 342, 'red'),

        post(1500, G, 130, 'stone', 30), post(1700, G, 130, 'stone', 30), beam(1600, G - 130, 260, 'stone', 26),
        enemy(1560, G, 'blue'), enemy(1640, G, 'red'),
        post(1530, G - 156, 90, 'wood'), post(1670, G - 156, 90, 'wood'), beam(1600, G - 246, 180, 'wood'),
        enemy(1600, G - 156, 'blue'),
        tri(1600, G - 268, 200, 70, 'glass'),

        post(1768, G, 140, 'stone', 34), enemy(1834, G, 'blue'), tnt(1889, G, 36),
      ],
    },

    {
      id: 24, nameKey: 'lvl24',
      birds: ['boomer', 'heavy', 'puff', 'bomb', 'normal'],
      theme: 'volcano',
      statics: [{ x: 1500, y: 860, w: 360, h: 200 }, { x: 1880, y: 840, w: 120, h: 240 }],
      items: [

        post(1080, G, 230, 'stone', 42),

        post(1120, G, 120, 'wood', 24), post(1280, G, 120, 'wood', 24), beam(1200, G - 120, 190, 'stone', 26),
        tnt(1160, G, 36), enemy(1225, G, 'red'),

        post(1360, 760, 170, 'stone', 32), post(1640, 760, 170, 'stone', 32),
        enemy(1440, 760, 'blue'), tnt(1500, 760, 40), enemy(1560, 760, 'red'),
        beam(1500, 590, 316, 'wood', 22),
        enemy(1450, 568, 'blue'), enemy(1550, 568, 'blue'),

        enemy(1770, G, 'red'), tnt(1712, G, 40),
      ],
    },

    {
      id: 25, nameKey: 'lvl25',
      birds: ['heavy', 'puff', 'boomer', 'bomb', 'split'],
      theme: 'volcano',

      statics: [{ x: 1330, y: 900, w: 240, h: 120 }, { x: 1680, y: 830, w: 460, h: 260 }, { tri: [[1110, 960], [1210, 960], [1210, 840]] }],
      items: [

        post(940, G, 110, 'glass'), post(1040, G, 110, 'glass'), beam(990, G - 110, 150, 'stone', 24),
        enemy(990, G, 'blue'), enemy(990, G - 134, 'red'),

        post(1270, 840, 90, 'stone', 28), post(1390, 840, 90, 'stone', 28), beam(1330, 750, 170, 'stone', 26),
        enemy(1330, 840, 'red'),
        tnt(1330, 724, 36),

        post(1500, 700, 180, 'stone', 40),
        post(1580, 700, 140, 'wood', 26), post(1800, 700, 140, 'wood', 26), beam(1690, 560, 300, 'stone', 28),
        enemy(1690, 700, 'red'),
        enemy(1860, 700, 'blue'),
        post(1610, 532, 90, 'glass'), post(1770, 532, 90, 'glass'), beam(1690, 442, 220, 'wood'),
        enemy(1690, 532, 'red'),
        tri(1690, 420, 200, 56, 'stone'),
      ],
    },
  ];

  const FAR_FORTS = [

    {
      birds: ['heavy', 'bomb', 'heavy', 'speed', 'normal', 'normal'],
      startHint: 'arena16', statics: [ledge(1595, 820, 510), ramp(1230, 1340, 820)],
      items: [
        ...shelter(875, G, 125, 105, 'blue', 'glass', 'wood', 'stone', 26),
        ...shelter(1130, G, 155, 133, 'red', 'wood', 'glass', 'stone', 26),
        boulder(1165, G - 159, 31), enemy(1080, G - 159, 'blue'),
        ...span(1455, 820, 135, 110, 'wood', 'glass', 'wood'),
        boulder(1440, 686, 34), enemy(1455, 820), tnt(1555, 820, 38),
        ...shelter(1735, 820, 145, 116, 'red', 'glass', 'wood', 'stone', 28),
        ...span(1735, 676, 100, 82, 'glass', 'wood', 'wood'),
        enemy(1735, 676), tri(1735, 570, 148, 40, 'glass'),
      ],
    },

    {
      birds: ['heavy', 'split', 'heavy', 'bomb', 'speed', 'normal'],
      startHint: 'arena17', statics: [ledge(1120, 833, 295), ledge(1635, 773, 430)],
      items: [
        ...span(1100, 833, 208, 145, 'stone', 'stone', 'wood'),
        enemy(1062, 833), enemy(1142, 833, 'red'), enemy(1100, 664),
        post(1005, 664, 67, 'glass'), post(1195, 664, 67, 'glass'),
        beam(1100, 597, 224, 'wood'),
        ...shelter(1345, G, 125, 106, 'blue', 'wood', 'glass', 'wood'),
        tnt(1388, 830, 40),
        ...span(1635, 773, 266, 157, 'stone', 'glass', 'wood', 26),
        enemy(1584, 773, 'red'), enemy(1684, 773), boulder(1751, 773, 21),
        ...span(1635, 590, 151, 82, 'glass', 'wood', 'wood'),
        enemy(1635, 590), tri(1635, 484, 170, 42, 'glass'),
      ],
    },

    {
      birds: ['boomer', 'bomb', 'boomer', 'heavy', 'speed', 'bomb', 'speed', 'normal'],
      startHint: 'arena18', statics: [ledge(1525, 845, 380)],
      items: [
        ...shelter(840, G, 122, 105, 'blue', 'glass', 'glass', 'wood'),
        enemy(840, 831),
        post(1035, G, 245, 'stone', 50), enemy(1035, 715),
        ...span(1199, G, 218, 125, 'stone', 'glass', 'stone', 28),
        enemy(1170, G, 'red'), enemy(1248, G), tnt(1280, G, 35),
        post(1404, 845, 208, 'stone', 44),
        ...span(1545, 845, 180, 126, 'stone', 'glass', 'stone', 26),
        enemy(1540, 845, 'red'), enemy(1545, 693),
        ...span(1545, 693, 112, 80, 'wood', 'glass', 'wood'),
        ...shelter(1794, G, 142, 121, 'red', 'glass', 'glass', 'wood'),
        enemy(1199, 807), tnt(1794, 815, 38),
      ],
    },

    {
      birds: ['split', 'heavy', 'bomb', 'boomer', 'heavy', 'speed', 'normal'],
      startHint: 'arena19', statics: [ledge(1460, 816, 760), ramp(950, 1080, 816)],
      items: [
        ...shelter(881, G, 128, 112, 'blue', 'wood', 'glass', 'wood'),
        ...shelter(1175, 816, 136, 145, 'red', 'glass', 'glass', 'stone', 25),
        ...span(1175, 646, 100, 87, 'wood', 'glass', 'wood'),
        enemy(1175, 646),
        ...shelter(1459, 816, 149, 116, 'blue', 'wood', 'glass', 'glass'),
        tnt(1389, 676, 38), boulder(1485, 676, 25),
        ...shelter(1743, 816, 128, 145, 'red', 'glass', 'stone', 'stone', 25),
        ...span(1743, 646, 98, 91, 'glass', 'wood', 'glass'),
        enemy(1743, 646), beam(1459, 646, 430, 'glass', 20),
      ],
    },

    {
      birds: ['heavy', 'bomb', 'boomer', 'heavy', 'bomb', 'speed', 'normal'],
      startHint: 'hintBoss4', mood: 'boss', statics: [ledge(1535, 790, 655), ramp(1095, 1208, 790)],
      items: [
        ...shelter(936, G, 146, 117, 'red', 'stone', 'glass', 'wood'),
        tnt(936, 819, 40), enemy(1069, G),
        ...shelter(1304, 790, 132, 120, 'blue', 'glass', 'wood', 'wood'),
        tnt(1350, 646, 36),
        ...span(1565, 790, 183, 143, 'wood', 'stone', 'stone', 31),
        enemy(1565, 790, 'boss'),
        ...span(1565, 616, 135, 105, 'glass', 'glass', 'wood'),
        enemy(1565, 616, 'red'), tri(1565, 487, 180, 52, 'glass'),
        ...span(1799, 790, 101, 123, 'wood', 'glass', 'wood'),
        enemy(1799, 790), enemy(1799, 643),
      ],
    },

    {
      birds: ['puff', 'puff', 'heavy', 'bomb', 'puff', 'speed', 'bomb'],
      startHint: 'arena21', statics: [ledge(1020, 830, 230), ledge(1345, 711, 190), ledge(1523, 848, 162), ledge(1741, 806, 270)],
      items: [
        ...span(1010, 830, 148, 102, 'glass', 'glass', 'wood'),
        enemy(1010, 830), enemy(1010, 704, 'blue'), tnt(1080, 704, 38),
        ...shelter(1193, G, 87, 98, 'blue', 'wood', 'glass', 'wood'),
        ...span(1345, 711, 127, 96, 'glass', 'wood', 'glass'),
        enemy(1345, 711, 'red'), enemy(1345, 591), tnt(1395, 591, 34),
        ...span(1518, 848, 125, 101, 'wood', 'glass', 'wood'),
        enemy(1518, 848, 'red'), boulder(1505, 723, 23),
        ...shelter(1710, 806, 138, 120, 'red', 'stone', 'glass', 'wood'),
        ...span(1710, 662, 92, 77, 'wood', 'glass', 'wood'),
        enemy(1710, 662), enemy(1835, 806), tnt(1778, 806, 34),
      ],
    },

    {
      birds: ['puff', 'bomb', 'heavy', 'boomer', 'bomb', 'speed', 'normal'],
      startHint: 'arena22', statics: [ledge(972, 786, 218), ledge(1745, 786, 275)],
      items: [
        ...shelter(934, 786, 115, 105, 'red', 'glass', 'wood', 'wood'),
        tnt(1050, 786, 35),
        ...span(1341, G, 176, 149, 'glass', 'wood', 'wood', 25),
        enemy(1341, G, 'red'), tnt(1281, G, 40), tnt(1400, G, 40),
        beam(1169, 786, 240, 'wood', 27), beam(1508, 786, 240, 'wood', 27),
        enemy(1140, 759), enemy(1233, 759), enemy(1449, 759), enemy(1549, 759, 'red'),
        ...shelter(1745, 786, 150, 121, 'red', 'wood', 'glass', 'stone', 26),
        ...span(1745, 639, 109, 88, 'glass', 'glass', 'wood'),
        enemy(1745, 639), tri(1745, 527, 148, 48),
        post(1116, G, 87, 'glass'), post(1563, G, 87, 'glass'),
        enemy(1153, G), enemy(1512, G),
      ],
    },

    {
      birds: ['heavy', 'split', 'boomer', 'bomb', 'heavy'],
      startHint: 'arena23', statics: [ledge(1540, 835, 560)],
      items: [
        ...span(933, G, 130, 180, 'glass', 'glass', 'wood'), enemy(933, 756), enemy(933, G),
        ...shelter(1145, G, 118, 104, 'red', 'wood', 'glass', 'wood'),
        ...span(1445, 835, 169, 145, 'stone', 'wood', 'stone', 26), enemy(1445, 835, 'red'),
        ...span(1445, 664, 131, 118, 'glass', 'glass', 'glass'), enemy(1445, 664),
        tri(1445, 522, 185, 72, 'glass'), boulder(1572, 835, 20),
        ...shelter(1720, 835, 134, 106, 'blue', 'wood', 'glass', 'wood'),
        tnt(1720, 705, 38), enemy(1864, G),
      ],
    },

    {
      birds: ['boomer', 'bomb', 'puff', 'heavy', 'bomb'],
      startHint: 'arena24', statics: [ledge(1660, 840, 360)],
      items: [
        ...shelter(890, G, 134, 104, 'red', 'stone', 'glass', 'wood'),
        tnt(945, 832, 38),
        post(1038, G, 194, 'stone', 38),
        ...span(1231, G, 290, 131, 'wood', 'glass', 'stone', 23),
        tnt(1118, G, 40), tnt(1227, G, 38), tnt(1344, G, 40),
        enemy(1169, G), enemy(1282, G, 'red'),
        ...span(1231, 806, 168, 86, 'glass', 'wood', 'wood'),
        enemy(1231, 806), boulder(1226, 696, 24),
        ...shelter(1655, 840, 183, 118, 'red', 'stone', 'wood', 'wood'),
        tnt(1591, 840, 35), tnt(1708, 840, 35),
        enemy(1655, 698), enemy(1868, G),
      ],
    },

    {
      birds: ['heavy', 'bomb', 'puff', 'boomer', 'heavy', 'bomb', 'split', 'normal'],
      startHint: 'hintBoss5', mood: 'boss',
      statics: [ledge(1140, 861, 245), ledge(1602, 761, 525), ramp(876, 1017, 861)],
      items: [
        ...shelter(778, G, 126, 104, 'blue', 'glass', 'glass', 'wood'),
        ...shelter(1145, 861, 143, 119, 'red', 'glass', 'wood', 'stone', 29),
        enemy(1145, 713), tnt(1205, 713, 34),
        post(1385, 761, 168, 'stone', 38),
        ...span(1585, 761, 191, 138, 'wood', 'glass', 'stone', 28),
        enemy(1585, 761, 'boss'), tnt(1653, 761, 36),
        ...span(1585, 595, 142, 96, 'glass', 'wood', 'wood'),
        enemy(1585, 595, 'red'), tri(1585, 475, 196, 57, 'glass'),
        ...shelter(1799, 761, 98, 99, 'red', 'glass', 'stone', 'wood'),
        enemy(1799, 638), boulder(1858, 638, 23),
      ],
    },
  ];

  const FINAL_STARS = [[76000, 106000], [88000, 120000], [86000, 118000], [89000, 120000], [104000, 133000],
    [99000, 131000], [110000, 138000], [89000, 122000], [100000, 133000], [110000, 142000]];

  const NEAR_WIDTH = 1920;
  FAR_FORTS.forEach((fort, i) => {
    const level = LEVELS[15 + i];
    level.width = NEAR_WIDTH * 2;
    level.maxLaunchSpeed = 43;
    level.birds.push(...fort.birds);
    level.items.push(...fort.items.map((item) => ({ ...item, x: item.x + NEAR_WIDTH })));
    level.statics.push(...fort.statics.map((s) => s.tri
      ? { tri: s.tri.map(([x, y]) => [x + NEAR_WIDTH, y]) }
      : { ...s, x: s.x + NEAR_WIDTH }));
    level.farHint = fort.startHint;
    level.mood = fort.mood || level.mood;
    level.stars = [0, ...FINAL_STARS[i]];
  });

  if (typeof module !== 'undefined' && module.exports) module.exports = LEVELS;
  root.YB = Object.assign(root.YB || {}, { LEVELS });
})(typeof window !== 'undefined' ? window : globalThis);
