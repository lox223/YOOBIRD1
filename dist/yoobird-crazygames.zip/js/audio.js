(function (root) {
  'use strict';

  const NOTE = {};
  (function buildNotes() {
    const names = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
    for (let o = 1; o <= 7; o++) names.forEach((n, i) => { NOTE[n + o] = 440 * Math.pow(2, ((o + 1) * 12 + i - 69) / 12); });
  })();
  const bars = (list) => list.join(' ').split(' ');

  const TUNES = {
    major: {
      melody: bars([
        'E5 . G5 . C6 . G5 . E5 . G5 . A5 G5 E5 .',
        'D5 . G5 . B5 . G5 . D5 . G5 . B5 A5 G5 .',
        'C5 . E5 . A5 . E5 . C6 . B5 . A5 . E5 .',
        'F5 . A5 . C6 . A5 . G5 . F5 . E5 . D5 .',
        'E5 . . G5 . . C6 . B5 . A5 . G5 . E5 .',
        'D5 . . G5 . . B5 . A5 . G5 . F5 . D5 .',
        'C5 . F5 . A5 . F5 . C6 . A5 . G5 . F5 .',
        'G5 . . . B5 . . . D6 . C6 . B5 . G5 .',

        'A5 . . C6 . . A5 . F5 . A5 . C6 . A5 .',
        'B5 . . D6 . . B5 . G5 . B5 . D6 . B5 .',
        'G5 . . B5 . . G5 . E5 . G5 . B5 . G5 .',
        'A5 . . C6 . . E6 . D6 . C6 . B5 . A5 .',
        'F5 . A5 . C6 . F6 . E6 . C6 . A5 . F5 .',
        'G5 . B5 . D6 . G6 . F6 . D6 . B5 . G5 .',
        'E6 . . D6 . . C6 . G5 . . E5 . . G5 .',
        'C6 . . . G5 . . . C5 . . . . . . .',
      ]),
      chords: [
        ['C3', 'C4', 'E4', 'G4'], ['G2', 'B3', 'D4', 'G4'], ['A2', 'C4', 'E4', 'A4'], ['F2', 'A3', 'C4', 'F4'],
        ['C3', 'C4', 'E4', 'G4'], ['G2', 'B3', 'D4', 'G4'], ['F2', 'A3', 'C4', 'F4'], ['G2', 'B3', 'D4', 'F4'],
        ['F2', 'A3', 'C4', 'F4'], ['G2', 'B3', 'D4', 'G4'], ['E2', 'G3', 'B3', 'E4'], ['A2', 'C4', 'E4', 'A4'],
        ['F2', 'A3', 'C4', 'F4'], ['G2', 'B3', 'D4', 'G4'], ['C3', 'C4', 'E4', 'G4'], ['C3', 'C4', 'E4', 'G4'],
      ],
    },
    minor: {
      melody: bars([
        'A4 . C5 . E5 . C5 . A4 . C5 . E5 . A5 .',
        'F4 . A4 . C5 . A4 . F5 . E5 . C5 . A4 .',
        'G4 . C5 . E5 . C5 . G5 . E5 . C5 . G4 .',
        'G4 . B4 . D5 . B4 . D5 . . B4 . . G4 .',
        'A4 . C5 . E5 . A5 . G5 . E5 . C5 . A4 .',
        'F4 . A4 . C5 . F5 . E5 . C5 . A4 . F4 .',
        'E4 . G#4 . B4 . E5 . D5 . B4 . G#4 . E4 .',
        'E5 . . . D5 . . . B4 . . . G#4 . . .',

        'D5 . F5 . A5 . F5 . D5 . F5 . A5 . D6 .',
        'C6 . A5 . E5 . A5 . C6 . . A5 . . E5 .',
        'B5 . G#5 . E5 . G#5 . B5 . . E6 . . B5 .',
        'A5 . . . E5 . . . C5 . E5 . A5 . . .',
        'D5 . F5 . A5 . D6 . C6 . A5 . F5 . D5 .',
        'E5 . A5 . C6 . E6 . D6 . C6 . A5 . E5 .',
        'F5 . A5 . C6 . A5 . F5 . . A5 . . C6 .',
        'B5 . . G#5 . . E5 . D5 . . B4 . . . .',
      ]),
      chords: [
        ['A2', 'C4', 'E4', 'A4'], ['F2', 'A3', 'C4', 'F4'], ['C3', 'C4', 'E4', 'G4'], ['G2', 'B3', 'D4', 'G4'],
        ['A2', 'C4', 'E4', 'A4'], ['F2', 'A3', 'C4', 'F4'], ['E2', 'G#3', 'B3', 'E4'], ['E2', 'G#3', 'B3', 'E4'],
        ['D3', 'A3', 'D4', 'F4'], ['A2', 'C4', 'E4', 'A4'], ['E2', 'G#3', 'B3', 'E4'], ['A2', 'C4', 'E4', 'A4'],
        ['D3', 'A3', 'D4', 'F4'], ['A2', 'C4', 'E4', 'A4'], ['F2', 'A3', 'C4', 'F4'], ['E2', 'G#3', 'B3', 'E4'],
      ],
    },
  };

  const MOODS = {
    day:    { tune: 'major', bpm: 116, lead: 'square',   leadVol: 0.060, cutoff: 2600, drums: 1,    four: false, arp: true },
    sunset: { tune: 'major', bpm: 104, lead: 'triangle', leadVol: 0.085, cutoff: 2000, drums: 0.7,  four: false, arp: false },
    night:  { tune: 'minor', bpm: 100, lead: 'triangle', leadVol: 0.085, cutoff: 1800, drums: 0.55, four: false, arp: true },
    winter: { tune: 'major', bpm: 96,  lead: 'sine',     leadVol: 0.095, cutoff: 3200, drums: 0.45, four: false, arp: true },
    volcano:{ tune: 'minor', bpm: 122, lead: 'square',   leadVol: 0.050, cutoff: 1500, drums: 1.0,  four: true,  arp: false },
    boss:   { tune: 'minor', bpm: 134, lead: 'sawtooth', leadVol: 0.050, cutoff: 2400, drums: 1.15, four: true,  arp: true },
  };
  const MUSIC_VOL = 0.30, SFX_VOL = 0.87;
  const NO_DETUNE = new Set(['click', 'score', 'bonus', 'star', 'win', 'lose', 'combo', 'sight', 'powerUp', 'nukeOffer', 'whoosh', 'ach', 'tick']);
  const BLOCKS = {

    wood:  { modes: [190, 406, 742, 1210],      color: 0.38, decay: 0.075, grit: [840, 2600] },
    glass: { modes: [960, 2190, 3420, 5175],    color: 0.77, decay: 0.16,  grit: [1900, 6200] },
    stone: { modes: [102, 244, 503, 910],       color: 0.24, decay: 0.11,  grit: [380, 1920] },
    tnt:   { modes: [144, 311, 831, 1560],     color: 0.43, decay: 0.093, grit: [650, 3200] },
  };

  function makeBlockBank(c) {
    const rate = 32000, bank = {};
    let seed = 9127;
    const rnd = () => ((seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0) / 4294967296);
    const tau = 2 * Math.PI;
    for (const [material, p] of Object.entries(BLOCKS)) {
      bank[material] = {};
      for (const kind of ['hit', 'ground', 'static', 'break']) {
        const broken = kind === 'break', soil = kind === 'ground', slab = kind === 'static';
        const len = Math.ceil(rate * (broken ? 0.57 : Math.max(0.19, p.decay * 2)));
        bank[material][kind] = Array.from({ length: 4 }, () => {
          const buffers = [c.createBuffer(1, len, rate), c.createBuffer(1, len, rate)];
          const [body, texture] = buffers.map((b) => b.getChannelData(0));
          const pitch = 0.91 + rnd() * 0.18;
          p.modes.forEach((hz, i) => {
            const f = hz * pitch * (broken ? 0.87 : soil ? 0.82 : 1) * (0.98 + rnd() * 0.04);
            const decay = p.decay * (soil ? 0.83 : 1) * (broken ? 1.35 : 1) * (i === 0 ? 1.18 : 1 - i * 0.14);
            const weight = (material === 'glass' ? [0.11, 0.24, 0.13, 0.06] : [0.27, 0.15, 0.08, 0.032])[i];
            const a = tau * f / rate, fall = Math.exp(-4.8 / (rate * decay));
            for (let j = 0, level = weight, end = Math.min(len, Math.ceil(decay * rate * 1.5)); j < end; j++, level *= fall) {
              body[j] += Math.sin(j * a) * level * Math.min(1, j / 34);
            }
          });
          if (soil || slab || (broken && material !== 'glass')) {
            const f = (soil ? 97 : slab ? 166 : 120) * pitch;
            for (let j = 0, end = Math.floor(rate * 0.19); j < end; j++) {
              const t = j / rate;
              body[j] += Math.sin(tau * f * (t * 0.62 + 0.38 * (1 - Math.exp(-t * 28)) / 28))
                * Math.min(1, j / 51) * Math.exp(-t * 44) * (soil ? 0.34 : 0.19);
            }
          }

          function grain(at, hz, duration, level, ring) {
            const start = Math.floor(at * rate), count = Math.min(len - start, Math.ceil(duration * rate));
            const slow = 1 - Math.exp(-tau * hz * 0.38 / rate), fast = 1 - Math.exp(-tau * hz * 1.55 / rate);
            const fall = Math.exp(-5 / count), w = tau * hz / rate;
            for (let j = 0, l = level, lo = 0, hi = 0; j < count; j++, l *= fall) {
              const n = rnd() * 2 - 1;
              lo += slow * (n - lo); hi += fast * (n - hi);
              texture[start + j] += ((hi - lo) * (1 - ring) * 2.4 + Math.sin(j * w) * ring)
                * l * Math.min(1, j / 17, (count - j) / 70);
            }
          }
          const [low, high] = p.grit;
          grain(0, (soil ? low * 0.65 : high * 0.65) * pitch, broken ? 0.093 : 0.041, broken ? 0.87 : 0.55, 0);
          if (soil) grain(0.008, low * 0.52, 0.13, 0.34, 0);
          if (slab) grain(0.006, low * 0.93, 0.065, 0.31, 0.14);
          const count = broken ? (material === 'glass' ? 10 : 7) : soil ? 4 : 2;
          for (let i = 0; i < count; i++) {
            const at = 0.009 + (i / count) ** 1.35 * (broken ? 0.37 : 0.09) + rnd() * 0.018;
            grain(at, low + rnd() * (high - low) * (soil ? 0.38 : 1), 0.021 + rnd() * (broken ? 0.098 : 0.037),
              (broken ? 0.44 : 0.21) * (1 - i / (count * 1.16)),
              material === 'glass' ? 0.46 + rnd() * 0.22 : p.color * 0.32);
          }
          return buffers;
        });
      }
    }
    return bank;
  }

  const A = {
    ctx: null, master: null, musicBus: null, sfxBus: null, worldBus: null, musicDuck: null,
    noiseBuf: null, reverb: null, delay: null, blockBank: null, blockQueue: [], blockLast: new Map(),
    musicOn: true, sfxOn: true, platformMuted: false,
    externalPause: 0,
    musicWanted: false, timer: null, step: 0, nextTime: 0,
    mood: 'day', nextMood: null,
    last: {}, _cur: null, _det: 1, lastCinematicDuck: -Infinity, duckUntil: 0,

    init() {
      if (this.ctx) return true;
      const AC = root.AudioContext || root.webkitAudioContext;
      if (!AC) return false;
      try { this.ctx = new AC(); } catch (e) { return false; }
      const c = this.ctx;
      const comp = c.createDynamicsCompressor();
      comp.threshold.value = -12; comp.knee.value = 14; comp.ratio.value = 5;
      comp.attack.value = 0.003; comp.release.value = 0.13;

      const headroom = c.createGain(), ceiling = c.createWaveShaper();
      headroom.gain.value = 0.5;
      ceiling.curve = Float32Array.from({ length: 2049 }, (_, i) => {
        const x = i / 512 - 2, a = Math.abs(x);
        return Math.sign(x) * (a <= 0.64 ? a : 0.64 + 0.26 * (1 - Math.exp((0.64 - a) / 0.26)));
      });
      comp.connect(headroom); headroom.connect(ceiling); ceiling.connect(c.destination);
      this.master = c.createGain(); this.master.gain.value = this.platformMuted ? 0 : 0.82;
      const dc = c.createBiquadFilter(); dc.type = 'highpass'; dc.frequency.value = 32; dc.Q.value = 0.2;
      this.master.connect(dc); dc.connect(comp);
      this.musicBus = c.createGain(); this.musicBus.gain.value = this.musicOn ? MUSIC_VOL : 0;
      this.musicDuck = c.createGain(); this.musicBus.connect(this.musicDuck); this.musicDuck.connect(this.master);
      this.sfxBus = c.createGain(); this.sfxBus.gain.value = this.sfxOn ? SFX_VOL : 0; this.sfxBus.connect(this.master);
      this.worldBus = c.createGain(); this.worldBus.connect(this.sfxBus);
      this.panLanes = c.createStereoPanner ? Array.from({ length: 17 }, (_, i) => {
        const p = c.createStereoPanner(); p.pan.value = (i - 8) * 0.08; p.connect(this.worldBus);
        return p;
      }) : null;
      this.blockBank = makeBlockBank(c);

      const len = c.sampleRate * 2;
      this.noiseBuf = c.createBuffer(1, len, c.sampleRate);
      const d = this.noiseBuf.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;

      try {
        const rl = Math.floor(c.sampleRate * 0.75), ir = c.createBuffer(2, rl, c.sampleRate);
        for (let ch = 0; ch < 2; ch++) {
          const x = ir.getChannelData(ch);
          const offset = Math.floor(c.sampleRate * (ch ? 0.021 : 0.016));
          for (let i = offset; i < rl; i++) x[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / rl, 3.5);
        }
        this.reverb = c.createConvolver(); this.reverb.buffer = ir;
        const high = c.createBiquadFilter(), low = c.createBiquadFilter(), room = c.createGain();
        high.type = 'highpass'; high.frequency.value = 270;
        low.type = 'lowpass'; low.frequency.value = 4200;
        room.gain.value = 0.18;
        this.worldBus.connect(room); room.connect(high); high.connect(low); low.connect(this.reverb);
        this.reverb.connect(this.sfxBus);
      } catch (e) { this.reverb = null; }

      this.delay = c.createDelay(1); this.delay.delayTime.value = 0.3;
      const fb = c.createGain(); fb.gain.value = 0.3;
      const dl = c.createBiquadFilter(); dl.type = 'lowpass'; dl.frequency.value = 1800;
      const dOut = c.createGain(); dOut.gain.value = 0.32;
      this.delay.connect(dl); dl.connect(fb); fb.connect(this.delay); dl.connect(dOut); dOut.connect(this.musicBus);
      return true;
    },

    setPlatformMuted(muted) {
      this.platformMuted = muted;
      if (this.master) this.master.gain.setTargetAtTime(muted ? 0 : 0.82, this.ctx.currentTime, 0.015);
    },

    unlock() {
      if (!this.init()) return;
      if ((this.ctx.state === 'suspended' || this.ctx.state === 'interrupted') && this.externalPause === 0) {
        this.ctx.resume().catch(() => {});
      }
      if (this.musicWanted && !this.timer) this._startScheduler();
    },

    pushPause() {
      this.externalPause++;
      if (this.ctx && this.ctx.state === 'running') this.ctx.suspend().catch(() => {});
    },
    popPause() {
      this.externalPause = Math.max(0, this.externalPause - 1);
      if (this.externalPause === 0 && this.ctx && this.ctx.state === 'suspended') this.ctx.resume().catch(() => {});
    },

    setMusic(on) {
      this.musicOn = on;
      if (this.musicBus) this.musicBus.gain.setTargetAtTime(on ? MUSIC_VOL : 0, this.ctx.currentTime, 0.05);
      if (on && this.musicWanted) this._startScheduler(); else if (!on) this._stopScheduler();
    },
    setSfx(on) {
      this.sfxOn = on;
      if (this.sfxBus) this.sfxBus.gain.setTargetAtTime(on ? SFX_VOL : 0, this.ctx.currentTime, 0.02);
      if (!on) {
        this.blockQueue.length = 0;
        this.duckUntil = 0;
        if (this.musicDuck) {
          const g = this.musicDuck.gain, t = this.ctx.currentTime;
          g.cancelScheduledValues(t); g.setTargetAtTime(1, t, 0.06);
        }
      }
    },

    duck(sec) {
      if (!this.ctx || !this.musicOn || !this.sfxOn) return;
      const g = this.musicDuck.gain, t = this.ctx.currentTime;
      this.duckUntil = t + sec;
      g.cancelScheduledValues(t); g.setValueAtTime(g.value, t);
      g.linearRampToValueAtTime(0.18, t + 0.22);
      g.setValueAtTime(0.18, t + Math.max(0.22, sec - 1.4));
      g.linearRampToValueAtTime(1, t + sec);
    },

    startMusic() { this.musicWanted = true; if (this.ctx && this.musicOn) this._startScheduler(); },
    stopMusic() { this.musicWanted = false; this._stopScheduler(); },

    setMood(m) { if (!MOODS[m]) m = 'day'; if (m !== this.mood) this.nextMood = m; else this.nextMood = null; },

    _startScheduler() {
      if (this.timer || !this.ctx || !this.musicOn) return;
      this.nextTime = this.ctx.currentTime + 0.1;
      this.timer = setInterval(() => this._schedule(), 50);
    },
    _stopScheduler() { if (this.timer) { clearInterval(this.timer); this.timer = null; } },

    _schedule() {
      const c = this.ctx;
      if (!c || c.state !== 'running') return;
      if (this.nextTime < c.currentTime - 0.3) this.nextTime = c.currentTime + 0.05;
      while (this.nextTime < c.currentTime + 0.25) {
        if (this.nextMood && this.step % 4 === 0) {
          const from = MOODS[this.mood].tune, to = MOODS[this.nextMood].tune;
          this.mood = this.nextMood; this.nextMood = null;
          if (from !== to) this.step = 0; else this.step -= this.step % 16;
        }
        const M = MOODS[this.mood], sd = 60 / M.bpm / 4;
        this.delay.delayTime.setValueAtTime(sd * 3, this.nextTime);
        this._playStep(this.step, this.nextTime, sd, M);
        this.nextTime += sd;
        this.step = (this.step + 1) % 256;
      }
    },

    _playStep(s, t, sd, M) {
      const T = TUNES[M.tune], bar = Math.floor(s / 16), i = s % 16, ch = T.chords[bar], partB = bar >= 8;
      const bus = this.musicBus, dv = M.drums;

      const n = T.melody[s];
      if (n && n !== '.') {
        let len = 1; while (len < 4 && T.melody[(s + len) % 256] === '.') len++;
        const f = NOTE[n], d = sd * len * 0.92;
        this._pluck({ type: M.lead, f, t, d, vol: M.leadVol, cutoff: M.cutoff, dest: bus, send: true });
        this._pluck({ type: 'triangle', f: f * 1.006, t, d: d * 0.8, vol: M.leadVol * 0.55, cutoff: M.cutoff, dest: bus });
        this._tone({ type: 'sine', f: f * 2, t, a: 0.005, d: sd * 1.1, vol: 0.018, dest: bus });
        this._tone({ type: 'sine', f: f * 0.5, t, a: 0.008, d: d * 0.82, vol: M.leadVol * 0.16, dest: bus, lp: M.cutoff * 0.55 });
      }

      if (i === 0) for (let k = 1; k < 4; k++) {
        this._tone({ type: 'triangle', f: NOTE[ch[k]], t, a: sd * 3, d: sd * 12, vol: 0.022, dest: bus });
        this._tone({ type: 'sine', f: NOTE[ch[k]] * 1.004, t, a: sd * 3, d: sd * 12, vol: 0.02, dest: bus });
      }

      const bassOn = M.four ? (i % 2 === 0) : (i === 0 || i === 6 || i === 8 || i === 11 || i === 14);
      if (bassOn) {
        const up = M.four ? (i % 4 === 2) : (i === 6 || i === 14);
        const f = NOTE[ch[0]] * (up ? 2 : 1);
        this._tone({ type: 'triangle', f, t, a: 0.005, d: sd * (M.four ? 1.3 : 1.9), vol: 0.2, dest: bus });
        this._tone({ type: 'sine', f: f / (up ? 2 : 1), t, a: 0.005, d: sd * 1.6, vol: 0.12, dest: bus });
      }

      if (i % 4 === 2) for (let k = 1; k < 4; k++) this._tone({ type: 'triangle', f: NOTE[ch[k]], t, a: 0.004, d: sd * 0.85, vol: 0.032, dest: bus });
      if (partB && M.arp) this._tone({ type: 'triangle', f: NOTE[ch[1 + (i % 3)]] * 2, t, a: 0.003, d: sd * 0.7, vol: 0.022, dest: bus });

      const kick = M.four ? (i % 4 === 0) : (i === 0 || i === 8 || (i === 10 && bar % 2 === 1) || (i === 7 && partB));
      if (kick) {
        this._tone({ type: 'sine', f: 150, f2: 40, t, a: 0.002, d: 0.17, vol: 0.42 * dv, dest: bus });
        this._noise({ t, d: 0.02, vol: 0.08 * dv, filter: 'lowpass', freq: 1200, dest: bus });
      }
      if (i === 4 || i === 12) {
        this._noise({ t, d: 0.13, vol: 0.13 * dv, filter: 'bandpass', freq: 1900, q: 0.8, dest: bus });
        this._tone({ type: 'triangle', f: 210, f2: 150, t, a: 0.002, d: 0.08, vol: 0.09 * dv, dest: bus });
        if (partB) this._noise({ t: t + 0.012, d: 0.09, vol: 0.07 * dv, filter: 'bandpass', freq: 1300, q: 1.4, dest: bus });
      }
      if (i % 2 === 0) this._noise({ t, d: i % 4 === 2 ? 0.07 : 0.028, vol: (i % 4 === 2 ? 0.055 : 0.032) * dv, filter: 'highpass', freq: 7500, dest: bus });
      else if (partB || M.four) this._noise({ t, d: 0.02, vol: 0.016 * dv, filter: 'highpass', freq: 9000, dest: bus });

      if (bar % 8 === 7 && i >= 12) this._noise({ t, d: 0.07, vol: (0.06 + (i - 12) * 0.025) * dv, filter: 'bandpass', freq: 1700 + (i - 12) * 250, q: 1, dest: bus });
    },

    _env(g, t, a, d, vol) {
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(Math.max(0.0002, vol), t + a);
      g.gain.exponentialRampToValueAtTime(0.0001, t + a + d);
    },

    _tone({ type = 'sine', f = 440, f2 = null, t = 0, a = 0.005, d = 0.2, vol = 0.3, dest = null, lp = 0, vib = 0 }) {
      const c = this.ctx;
      const k = dest ? 1 : this._det;
      const o = c.createOscillator(), g = c.createGain();
      o.type = type;
      o.frequency.setValueAtTime(f * k, t);
      if (f2) o.frequency.exponentialRampToValueAtTime(Math.max(20, f2 * k), t + a + d);
      let node = o;
      if (lp) { const fl = c.createBiquadFilter(); fl.type = 'lowpass'; fl.frequency.value = lp; o.connect(fl); node = fl; }
      if (vib) {
        const l = c.createOscillator(), lg = c.createGain();
        l.frequency.value = vib; lg.gain.value = f * 0.03; l.connect(lg); lg.connect(o.frequency);
        l.start(t); l.stop(t + a + d + 0.05);
      }
      node.connect(g); g.connect(dest || this._cur || this.sfxBus);
      this._env(g, t, a, d, vol);
      o.start(t); o.stop(t + a + d + 0.05);
    },

    _pluck({ type, f, t, d, vol, cutoff, dest, send }) {
      const c = this.ctx;
      const o = c.createOscillator(), fl = c.createBiquadFilter(), g = c.createGain();
      o.type = type; o.frequency.setValueAtTime(f, t);
      fl.type = 'lowpass'; fl.Q.value = 2;
      fl.frequency.setValueAtTime(cutoff * 1.6, t);
      fl.frequency.exponentialRampToValueAtTime(Math.max(300, cutoff * 0.35), t + Math.max(0.08, d));
      o.connect(fl); fl.connect(g); g.connect(dest);
      if (send && this.delay) g.connect(this.delay);
      this._env(g, t, 0.006, d, vol);
      o.start(t); o.stop(t + d + 0.06);
    },

    _noise({ t = 0, a = 0.003, d = 0.2, vol = 0.3, filter = 'lowpass', freq = 1000, freq2 = null, q = 1, dest = null }) {
      const c = this.ctx;
      const s = c.createBufferSource(); s.buffer = this.noiseBuf;
      s.loop = true;
      const fl = c.createBiquadFilter(); fl.type = filter; fl.Q.value = q;
      fl.frequency.setValueAtTime(freq, t);
      if (freq2) fl.frequency.exponentialRampToValueAtTime(freq2, t + a + d);
      const g = c.createGain();
      s.connect(fl); fl.connect(g); g.connect(dest || this._cur || this.sfxBus);
      this._env(g, t, a, d, vol);
      s.start(t, Math.random() * 1.5); s.stop(t + a + d + 0.05);
    },

    _impactDuck(t, power) {
      if (!this.musicOn || t < this.duckUntil || t - this.lastCinematicDuck < 0.15) return;
      this.lastCinematicDuck = t;
      const g = this.musicDuck.gain;
      if (g.cancelAndHoldAtTime) g.cancelAndHoldAtTime(t);
      else { g.cancelScheduledValues(t); g.setValueAtTime(g.value, t); }
      g.linearRampToValueAtTime(1 - 0.43 * power, t + 0.018);
      g.exponentialRampToValueAtTime(1, t + 0.22 + power * 0.25);
    },

    setListener(left, right) {
      this.listenerLeft = left;
      this.listenerWidth = right - left;
    },

    _worldAt(x) {
      const k = (x - (this.listenerLeft || 0)) / (this.listenerWidth || 1920);
      return this.panLanes ? this.panLanes[Math.max(0, Math.min(16, Math.round(k * 16)))] : this.worldBus;
    },

    queueBlock(d, broken = false) {
      if (!this.ctx || !this.sfxOn || this.ctx.state !== 'running' || !BLOCKS[d.m]) return;
      const kind = broken ? 'break' : d.surface === 'ground' ? 'ground' : d.surface ? 'static' : 'hit';
      const v = broken ? 0.78 + 0.22 * Math.min(1, Math.sqrt(d.mass / 12)) : d.v;
      const rank = v + (broken ? 0.48 : d.surface ? 0.05 : 0);
      this.blockQueue.push({ m: d.m, x: d.x, mass: d.mass, kind, v, rank });
    },

    flushBlocks() {
      const queue = this.blockQueue;
      if (!queue.length) return;
      if (!this.sfxOn || this.ctx.state !== 'running') { queue.length = 0; return; }
      const now = this.ctx.currentTime;
      queue.sort((a, b) => b.rank - a.rank);
      let count = 0;
      const occupied = new Set();
      for (const d of queue) {
        const bucket = Math.floor(d.x / 120);
        const key = d.m + ':' + d.kind + ':' + bucket, spot = d.m + ':' + bucket;
        const prior = this.blockLast.get(key);
        if (occupied.has(spot) || (prior && now - prior.t < (d.kind === 'break' ? 0.078 : 0.062) && d.v < prior.v * 1.55)) continue;

        const mix = 1 / (1 + count * 0.23);
        this._block(d, now + count * 0.003, mix, prior);
        this.blockLast.set(key, { t: now, v: d.v, variant: d.variant });
        occupied.add(spot);
        if (++count === 5) break;
      }
      queue.length = 0;
    },

    _block(d, t, mix, prior) {
      const bank = this.blockBank[d.m][d.kind];
      d.variant = prior ? (prior.variant + 1 + Math.floor(Math.random() * (bank.length - 1))) % bank.length
        : Math.floor(Math.random() * bank.length);
      const c = this.ctx, dest = this._worldAt(d.x);
      const playback = Math.max(0.76, Math.min(1.28, Math.pow(4 / d.mass, 0.12))) * (0.94 + d.v * 0.1);
      const amount = mix * Math.pow(d.v, 0.8) * (d.kind === 'break' ? 0.96 : 0.77);
      bank[d.variant].forEach((buffer, i) => {
        const src = c.createBufferSource(), gain = c.createGain();
        src.buffer = buffer; src.playbackRate.value = playback;
        gain.gain.value = amount * (i ? 0.62 + d.v * 0.28 : 1);
        src.connect(gain); gain.connect(dest);
        src.onended = () => { src.disconnect(); gain.disconnect(); };
        src.start(t);
      });
    },

    play(name, o = {}) {
      if (!this.ctx || !this.sfxOn || this.ctx.state !== 'running') return;
      const now = this.ctx.currentTime;
      const gap = o.gap != null ? o.gap : 0.045;
      const fn = SFX[name];
      if (!fn || (this.last[name] != null && now - this.last[name] < gap)) return;
      this.last[name] = now;
      this._det = NO_DETUNE.has(name) ? 1 : 0.94 + Math.random() * 0.12;
      this._cur = o.x != null ? this._worldAt(o.x) : null;
      if (name === 'explode' || name === 'slam' || name === 'quake' || (name === 'enemyDie' && o.t === 'boss')) {
        this._impactDuck(now, name === 'explode' || name === 'slam' ? 1 : 0.65);
      }
      try { fn.call(this, now, o.v == null ? 1 : Math.max(0, Math.min(1, o.v)), o); }
      finally { this._cur = null; this._det = 1; }
    },
  };

  const rand = (a, b) => a + Math.random() * (b - a);

  const SFX = {
    click(t) {
      this._tone({ type: 'triangle', f: 740, f2: 580, t, a: 0.002, d: 0.055, vol: 0.14, lp: 2800 });
      this._noise({ t, a: 0.001, d: 0.016, vol: 0.10, filter: 'bandpass', freq: 2100, q: 1.2 });
    },
    whoosh(t) {
      this._noise({ t, a: 0.05, d: 0.28, vol: 0.14, filter: 'bandpass', freq: 500, freq2: 2400, q: 1.2 });
    },
    grab(t) {
      this._tone({ type: 'sawtooth', f: 180, f2: 320, t, d: 0.12, vol: 0.08, lp: 900 });
      this._tone({ type: 'sine', f: 1800, f2: 2300, t: t + 0.02, d: 0.05, vol: 0.08 });
    },

    stretch(t, v) {
      this._tone({ type: 'sawtooth', f: 110 + v * 240, f2: 130 + v * 260, t, a: 0.004, d: 0.045, vol: 0.05, lp: 700 + v * 900 });
      this._noise({ t, d: 0.02, vol: 0.02, filter: 'bandpass', freq: 900 + v * 1400, q: 4 });
    },
    hop(t) {
      this._tone({ type: 'sine', f: 520, f2: 980, t, d: 0.09, vol: 0.12 });
      this._tone({ type: 'sine', f: 1900, f2: 2500, t: t + 0.05, d: 0.05, vol: 0.07 });
    },

    chirp(t) {
      const n = 2 + Math.floor(Math.random() * 2);
      for (let i = 0; i < n; i++) this._tone({ type: 'sine', f: rand(2300, 2800), f2: rand(3000, 3600), t: t + i * 0.09, a: 0.004, d: 0.05, vol: 0.05 });
    },
    launch(t, v) {
      const power = 0.46 + 0.54 * v;

      this._tone({ type: 'triangle', f: 180 + 100 * v, f2: 72, t, a: 0.002, d: 0.19, vol: 0.36 * power, vib: 28 });
      this._noise({ t, a: 0.001, d: 0.045, vol: 0.29 * power, filter: 'bandpass', freq: 1600 + 1350 * v, freq2: 740 });

      this._noise({ t: t + 0.018, a: 0.028, d: 0.24 + 0.14 * v, vol: 0.28 * power, filter: 'bandpass', freq: 840 + 1100 * v, freq2: 470, q: 0.95 });

      this._tone({ type: 'sine', f: 1310, f2: 2320, t: t + 0.05, a: 0.016, d: 0.075, vol: 0.11 });
      this._tone({ type: 'sine', f: 1980, f2: 1460, t: t + 0.13, a: 0.014, d: 0.10, vol: 0.08 });
    },
    birdHit(t, v) {
      this._tone({ type: 'triangle', f: 245 - v * 72, f2: 88, t, a: 0.002, d: 0.12, vol: 0.25 * v });
      this._noise({ t, a: 0.002, d: 0.072, vol: 0.24 * v, filter: 'bandpass', freq: 1250, freq2: 420, q: 0.8 });
      this._tone({ type: 'sine', f: 940 + 720 * v, f2: 690, t: t + 0.015, a: 0.008, d: 0.095, vol: 0.09 * v });
    },
    boost(t) {
      this._noise({ t, a: 0.01, d: 0.35, vol: 0.3, filter: 'bandpass', freq: 700, freq2: 4500, q: 2 });
      this._tone({ type: 'sawtooth', f: 300, f2: 1400, t, d: 0.22, vol: 0.08, lp: 2500 });
      this._tone({ type: 'sine', f: 2200, f2: 3400, t: t + 0.02, d: 0.08, vol: 0.14 });
    },

    split(t) {
      this._noise({ t, a: 0.002, d: 0.08, vol: 0.22, filter: 'bandpass', freq: 1800, q: 1.5 });
      this._tone({ type: 'sine', f: 700, f2: 1400, t, d: 0.07, vol: 0.18 });
      [2100, 2600, 3100].forEach((f, i) => this._tone({ type: 'sine', f, f2: f * 1.25, t: t + 0.03 + i * 0.05, d: 0.06, vol: 0.12 }));
    },

    dive(t) {
      this._tone({ type: 'sine', f: 1800, f2: 380, t, a: 0.01, d: 0.45, vol: 0.13 });
      this._noise({ t, a: 0.02, d: 0.35, vol: 0.18, filter: 'bandpass', freq: 2500, freq2: 600, q: 2 });
    },

    slam(t) {
      this._tone({ type: 'sine', f: 110, f2: 32, t, d: 0.55, vol: 0.7 });
      this._noise({ t, a: 0.002, d: 0.4, vol: 0.55, filter: 'lowpass', freq: 1400, freq2: 120, q: 0.8 });
      this._tone({ type: 'square', f: 70, f2: 45, t, d: 0.18, vol: 0.08, lp: 600 });
    },

    boomerang(t) {
      this._noise({ t, a: 0.01, d: 0.18, vol: 0.22, filter: 'bandpass', freq: 900, freq2: 3500, q: 3 });
      this._noise({ t: t + 0.16, a: 0.01, d: 0.2, vol: 0.2, filter: 'bandpass', freq: 3500, freq2: 900, q: 3 });
      this._tone({ type: 'triangle', f: 600, f2: 1300, t, d: 0.12, vol: 0.1 });
      this._tone({ type: 'triangle', f: 1300, f2: 700, t: t + 0.14, d: 0.14, vol: 0.09 });
    },

    inflate(t) {
      this._noise({ t, a: 0.03, d: 0.3, vol: 0.3, filter: 'lowpass', freq: 600, freq2: 3000, q: 1 });
      this._tone({ type: 'sine', f: 220, f2: 900, t, a: 0.02, d: 0.28, vol: 0.2 });
      this._tone({ type: 'sine', f: 120, f2: 60, t: t + 0.05, d: 0.3, vol: 0.35 });
    },

    pop(t) {
      this._noise({ t, a: 0.001, d: 0.06, vol: 0.45, filter: 'highpass', freq: 1200 });
      this._tone({ type: 'sine', f: 900, f2: 300, t, d: 0.08, vol: 0.18 });
      [1800, 2400].forEach((f, i) => this._tone({ type: 'sine', f, f2: f * 1.3, t: t + 0.04 + i * 0.05, d: 0.05, vol: 0.08 }));
    },
    explode(t, v, o) {
      const box = o.tnt;
      this._noise({ t, a: 0.001, d: 0.086, vol: box ? 0.78 : 0.58, filter: 'bandpass', freq: box ? 3800 : 2450, freq2: 630, q: 0.75 });
      this._tone({ type: 'triangle', f: box ? 156 : 118, f2: 48, t, a: 0.003, d: box ? 0.44 : 0.62, vol: box ? 0.49 : 0.62, lp: 940 });
      this._noise({ t: t + 0.01, a: 0.016, d: box ? 0.59 : 0.89, vol: 0.61, filter: 'lowpass', freq: 1550, freq2: 155, q: 0.55 });
      for (let i = 0; i < 4; i++) this._noise({ t: t + 0.07 + i * rand(0.034, 0.063), d: 0.063, vol: (0.29 - i * 0.047), filter: 'bandpass', freq: rand(470, box ? 2600 : 1300), q: 1.6 });
    },
    poof(t) {
      this._noise({ t, a: 0.02, d: 0.18, vol: 0.12, filter: 'bandpass', freq: 1300, q: 1.2 });
      this._tone({ type: 'sine', f: 900, f2: 1600, t, d: 0.08, vol: 0.05 });
    },
    enemyHurt(t, v, o) {
      const base = { red: 300, boss: 190 }[o.t] || 460;
      const level = 0.42 + v * 0.58;
      this._noise({ t, a: 0.002, d: 0.051, vol: 0.12 * level, filter: 'bandpass', freq: 640, q: 0.8 });
      this._tone({ type: 'triangle', f: base * 1.55, f2: base * 0.76, t, a: 0.006, d: 0.17, vol: 0.22 * level, vib: 18 });
      this._tone({ type: 'sine', f: base * 2.8, f2: base * 1.25, t: t + 0.02, d: 0.08, vol: 0.075 * level });
    },
    enemyDie(t, v, o) {
      const base = { red: 260, boss: 150 }[o.t] || 400;
      if (o.t === 'boss') {
        this._tone({ type: 'sine', f: 90, f2: 30, t, d: 0.7, vol: 0.5 });
        this._tone({ type: 'sawtooth', f: 220, f2: 55, t: t + 0.1, a: 0.02, d: 1.0, vol: 0.12, lp: 900, vib: 5 });
      }
      this._noise({ t, a: 0.002, d: 0.22, vol: 0.4, filter: 'lowpass', freq: 3500, freq2: 300 });
      this._tone({ type: 'sine', f: 900, f2: 300, t, d: 0.06, vol: 0.25 });
      this._tone({ type: 'sawtooth', f: base * 1.5, f2: base * 0.35, t: t + 0.05, d: 0.55, vol: 0.14, lp: 1400, vib: 9 });
      this._tone({ type: 'triangle', f: 1300, f2: 2400, t: t + 0.12, d: 0.12, vol: 0.08 });
    },
    taunt(t, v, o) {
      const base = { red: 330, boss: 220 }[o.t] || 480;
      for (let i = 0; i < 3; i++) this._tone({ type: 'square', f: base * (1.25 - i * 0.08), f2: base * (1.05 - i * 0.08), t: t + i * 0.13, a: 0.01, d: 0.09, vol: 0.07, lp: 1800, vib: 12 });
    },
    score(t) {
      this._tone({ type: 'square', f: 880, t, d: 0.07, vol: 0.06, lp: 3000 });
      this._tone({ type: 'square', f: 1320, t: t + 0.07, d: 0.1, vol: 0.06, lp: 3000 });
    },

    combo(t, v, o) {
      const f = 660 * Math.pow(2, (Math.min(6, o.i || 2) * 2) / 12);
      this._tone({ type: 'triangle', f, t, d: 0.12, vol: 0.2 });
      this._tone({ type: 'triangle', f: f * 1.5, t: t + 0.07, d: 0.2, vol: 0.18 });
      this._tone({ type: 'sine', f: f * 3, t: t + 0.07, d: 0.25, vol: 0.05 });
    },
    bonus(t) {
      this._tone({ type: 'triangle', f: 1046, t, d: 0.1, vol: 0.15 });
      this._tone({ type: 'triangle', f: 1568, t: t + 0.08, d: 0.18, vol: 0.15 });
      this._tone({ type: 'sine', f: 2093, t: t + 0.08, d: 0.2, vol: 0.06 });
    },
    star(t, v, o) {
      const f = [784, 988, 1175][o.i || 0];
      this._tone({ type: 'triangle', f, t, d: 0.4, vol: 0.22 });
      this._tone({ type: 'sine', f: f * 2, t: t + 0.03, d: 0.35, vol: 0.08 });
      this._tone({ type: 'sine', f: f * 3, t: t + 0.06, d: 0.25, vol: 0.04 });
      this._noise({ t, d: 0.25, vol: 0.04, filter: 'highpass', freq: 8000 });
    },
    sight(t) {
      this._tone({ type: 'sine', f: 1200, t, d: 0.07, vol: 0.12 });
      this._tone({ type: 'sine', f: 1800, t: t + 0.08, d: 0.12, vol: 0.12 });
      this._tone({ type: 'triangle', f: 2400, t: t + 0.16, d: 0.18, vol: 0.08 });
    },
    powerUp(t) {
      [392, 523, 659, 784, 1046].forEach((f, i) => this._tone({ type: 'square', f, t: t + i * 0.05, d: 0.1, vol: 0.07, lp: 2800 }));
      this._tone({ type: 'sawtooth', f: 110, f2: 220, t, d: 0.35, vol: 0.12, lp: 900 });
    },
    quake(t) {
      this._noise({ t, a: 0.05, d: 1.5, vol: 0.6, filter: 'lowpass', freq: 220, freq2: 90, q: 1 });
      this._tone({ type: 'sine', f: 48, f2: 34, t, a: 0.05, d: 1.4, vol: 0.55, vib: 7 });
      for (let i = 0; i < 6; i++) this._noise({ t: t + 0.1 + i * 0.2 + Math.random() * 0.1, d: 0.12, vol: 0.25, filter: 'bandpass', freq: 200 + Math.random() * 300, q: 2 });
    },
    nukeOffer(t) {
      this._tone({ type: 'sine', f: 660, t, d: 0.1, vol: 0.06 });
      this._tone({ type: 'sine', f: 990, t: t + 0.1, d: 0.14, vol: 0.05 });
    },
    nukeFall(t) {

      this._tone({ type: 'sawtooth', f: 520, f2: 70, t, a: 0.02, d: 1.0, vol: 0.12, lp: 1200 });
      this._noise({ t, a: 0.05, d: 0.9, vol: 0.18, filter: 'bandpass', freq: 3000, freq2: 300, q: 1.2 });

      this._tone({ type: 'sine', f: 2100, f2: 520, t: t + 0.1, a: 0.2, d: 1.25, vol: 0.16, vib: 5 });
      this._tone({ type: 'sine', f: 2140, f2: 530, t: t + 0.1, a: 0.2, d: 1.25, vol: 0.07 });
    },
    nukeBoom(t) {

      this._noise({ t, a: 0.003, d: 0.25, vol: 0.72, filter: 'highpass', freq: 800 });
      this._tone({ type: 'sine', f: 140, f2: 30, t, a: 0.006, d: 2.6, vol: 0.79 });
      this._tone({ type: 'triangle', f: 75, f2: 32, t, a: 0.014, d: 3.2, vol: 0.48 });

      this._noise({ t, a: 0.02, d: 4.2, vol: 0.86, filter: 'lowpass', freq: 2300, freq2: 135, q: 0.6 });
      this._noise({ t: t + 0.15, a: 0.3, d: 3.5, vol: 0.45, filter: 'bandpass', freq: 440, freq2: 125, q: 0.8 });

      for (let i = 0; i < 18; i++) this._noise({ t: t + 0.2 + Math.random() * 2.2, d: 0.06 + Math.random() * 0.1, vol: 0.12 + Math.random() * 0.12, filter: 'bandpass', freq: 300 + Math.random() * 1800, q: 3 });

      for (let k = 1; k <= 3; k++) this._noise({ t: t + k * 0.55, a: 0.02, d: 0.9, vol: 0.35 / k, filter: 'lowpass', freq: 900 / k, q: 0.7 });

      this._tone({ type: 'sine', f: 3800, t: t + 0.05, a: 0.1, d: 2.2, vol: 0.025 });
    },
    ach(t) {
      [784, 988, 1175, 1568].forEach((f, i) => {
        this._tone({ type: 'triangle', f, t: t + i * 0.07, d: 0.22, vol: 0.16 });
        this._tone({ type: 'sine', f: f * 2, t: t + i * 0.07, d: 0.18, vol: 0.05 });
      });
      this._noise({ t: t + 0.2, d: 0.4, vol: 0.05, filter: 'highpass', freq: 8000 });
    },
    tick(t, v) {
      this._tone({ type: 'square', f: 900 + v * 700, t, d: 0.03, vol: 0.04, lp: 3500 });
    },
    win(t) {
      const seq = [523, 659, 784, 1046, 1319];
      seq.forEach((f, i) => {
        this._tone({ type: 'square', f, t: t + i * 0.1, d: 0.14, vol: 0.07, lp: 3200 });
        this._tone({ type: 'triangle', f, t: t + i * 0.1, d: 0.16, vol: 0.14 });
      });
      [523, 659, 784, 1046].forEach((f) => this._tone({ type: 'triangle', f, t: t + 0.55, a: 0.02, d: 0.9, vol: 0.09 }));
      this._tone({ type: 'sine', f: 131, t: t + 0.55, a: 0.02, d: 0.9, vol: 0.2 });
      this._noise({ t: t + 0.55, d: 0.5, vol: 0.06, filter: 'highpass', freq: 7000 });
    },
    lose(t) {
      const seq = [[392, 370], [349, 330], [311, 294], [294, 262]];
      seq.forEach(([a, b], i) => this._tone({
        type: 'sawtooth', f: a, f2: b, t: t + i * 0.32, a: 0.02, d: i === 3 ? 0.8 : 0.28,
        vol: 0.12, lp: 1300, vib: i === 3 ? 6 : 0,
      }));
    },
  };

  root.YB = Object.assign(root.YB || {}, { Audio: A, AudioData: { TUNES, MOODS } });
})(typeof window !== 'undefined' ? window : globalThis);
