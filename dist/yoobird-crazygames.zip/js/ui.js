(function (root) {
  'use strict';
  const { Game, LEVELS, I18n, Audio: A, Platform: P, Render: R } = root.YB;
  const $ = (s) => document.querySelector(s);
  const $$ = (s) => document.querySelectorAll(s);
  const MAIN = ['loading', 'menu', 'levels'];
  const MODALS = ['pause', 'win', 'lose', 'settings', 'ach', 'wardrobe'];
  const LOCK_SVG = '<svg class="lock" viewBox="0 0 24 24"><path d="M6 10V8a6 6 0 1 1 12 0v2h1v12H5V10zm2 0h8V8a4 4 0 1 0-8 0z"/></svg>';
  const fmt = (v) => v.toLocaleString(I18n.lang);

  const ACH = ['first', 'oneshot', 'combo3', 'combo5', 'clean', 'king', 'citadel', 'iceking', 'final', 'nuke', 'slam2', 'boomer', 'puff3', 'tnt10', 'kills100', 'stars15', 'stars30', 'stars60', 'stars45'];

  const SKINS = [{ id: 'none', need: 0 }, { id: 'cap', need: 5 }, { id: 'glasses', need: 10 }, { id: 'bandana', need: 18 }, { id: 'tophat', need: 28 }, { id: 'crown', need: 40 }, { id: 'scarf', need: 52 }, { id: 'pilot', need: 66 }];

  const THEME_CLASS = { noon: 'w-noon', sunset: 'w-sunset', dusk: 'w-dusk', night: 'w-night', winter: 'w-winter', volcano: 'w-volcano' };

  const UI = {
    save: null, achQueue: [], achBusy: false,

    show(name) {
      MAIN.forEach((n) => $('#screen-' + n).classList.toggle('hidden', n !== name));
      ['#hud', '#boosters'].forEach((sel) => $(sel).classList.toggle('hidden', name !== 'game'));
      this.refreshNukeBtn();
      if (name === 'menu' || name === 'levels') this.refreshStars();
    },
    modal(name, on) { $('#screen-' + name).classList.toggle('hidden', !on); },
    closeModals() { MODALS.forEach((m) => this.modal(m, false)); },

    totalStars() { return this.save.stars.reduce((a, b) => a + (b || 0), 0); },
    refreshStars() { const t = `${this.totalStars()} / ${LEVELS.length * 3}`; $$('.ts-val').forEach((e) => { e.textContent = t; }); },
    tip() { const tips = I18n.t('tips').split('|'); return tips[(Math.random() * tips.length) | 0]; },

    setScore(v) {
      $('#hud-score').textContent = fmt(v);
      const st = Game.def && Game.def.stars;
      if (!st) return;
      $('#star-fill').style.width = Math.min(100, (v / st[2]) * 100) + '%';
      $('#star-t1').style.left = (st[1] / st[2]) * 100 + '%';
      $('#star-t1').classList.toggle('on', v >= st[1]);
      $('#star-t2').classList.toggle('on', v >= st[2]);
    },
    setEnemies(n) {
      const el = $('#hud-enemies');
      if (el.textContent !== String(n)) { el.textContent = n; el.parentNode.classList.remove('bump'); void el.offsetWidth; el.parentNode.classList.add('bump'); }
    },
    hideToast() { clearTimeout(this._toastT); $('#toast').classList.add('hidden'); },
    toast(key) {
      const el = $('#toast');
      el.textContent = I18n.t(key);
      el.classList.remove('hidden'); el.style.animation = 'none'; void el.offsetWidth; el.style.animation = '';
      clearTimeout(this._toastT);
      this._toastT = setTimeout(() => el.classList.add('hidden'), 3200);
    },
    syncGameplay() {
      if (Game.running() && (Game.phase === 'ready' || Game.shots > 0 || Game.nuke.mode)) P.gameplayStart();
      else P.gameplayStop();
    },
    togglePause() { if ($('#screen-pause').classList.contains('hidden')) this.act('pause'); else this.act('resume'); },
    persist() { P.save(this.save); },

    unlock(id) {
      if (!this.save || this.save.ach[id]) return;
      this.save.ach[id] = 1; this.persist();
      this.achQueue.push(id);
      if (!this.achBusy) this.nextAch();
    },
    nextAch() {
      const id = this.achQueue.shift();
      if (!id) { this.achBusy = false; return; }
      this.achBusy = true;
      const el = $('#ach-toast');
      el.querySelector('b').textContent = I18n.t('ach_' + id);
      el.classList.remove('hidden'); el.style.animation = 'none'; void el.offsetWidth; el.style.animation = '';
      A.play('ach', { gap: 0 });
      setTimeout(() => { el.classList.add('hidden'); setTimeout(() => this.nextAch(), 250); }, 2600);
    },
    checkProgressAch() {
      const t = this.totalStars(), st = this.save.stats;
      if (t >= 15) this.unlock('stars15');
      if (t >= 30) this.unlock('stars30');
      if (t >= 60) this.unlock('stars60');
      if (t >= LEVELS.length * 3) this.unlock('stars45');
      if ((st.kills || 0) >= 100) this.unlock('kills100');
      if ((st.tnt || 0) >= 10) this.unlock('tnt10');
    },
    buildAch() {
      const list = $('#ach-list'); list.innerHTML = '';
      const got = ACH.filter((id) => this.save.ach[id]).length;
      ACH.forEach((id) => {
        const on = !!this.save.ach[id];
        const d = document.createElement('div');
        d.className = 'ach' + (on ? ' on' : '');
        d.innerHTML = `<i></i><div><b>${I18n.t('ach_' + id)}</b><small>${I18n.t('ach_' + id + '_d')}</small></div>`;
        list.appendChild(d);
      });
      $('#screen-ach .title').textContent = `${I18n.t('achTitle')} ${got}/${ACH.length}`;
    },

    buildSkins() {
      const list = $('#skin-list'); list.innerHTML = '';
      const total = this.totalStars();
      SKINS.forEach((sk) => {
        const open = total >= sk.need, cur = (this.save.skin || 'none') === sk.id;
        const b = document.createElement('button');
        b.className = 'skin' + (open ? '' : ' locked') + (cur ? ' current' : '');
        b.dataset.action = 'skin'; b.dataset.skin = sk.id;
        const cv = document.createElement('canvas'); cv.width = 192; cv.height = 208;
        const c = cv.getContext('2d'); c.scale(2, 2); c.translate(46, 66);
        if (!open) c.globalAlpha = 0.45;
        R.chick(c, 0, 0, 28, 0, 'normal', { skin: sk.id, time: 0 });
        b.appendChild(cv);
        const lab = document.createElement('span');
        lab.innerHTML = open ? (cur ? I18n.t('skinOn') : I18n.t('skin_' + sk.id)) : `<i></i>${sk.need}`;
        b.appendChild(lab);
        list.appendChild(b);
      });
    },

    showWin(r) {

      this.unlock('first');
      if (r.shots === 1 && r.level >= 1) this.unlock('oneshot');
      if (r.level >= 6 && !r.used.booster && !r.used.nuke) this.unlock('clean');
      if (r.level === 14) this.unlock('citadel');
      if (r.level === 19) this.unlock('iceking');
      if (r.level === LEVELS.length - 1) this.unlock('final');
      this.checkProgressAch();

      $('#win-score').textContent = '0';
      $('#win-best').textContent = fmt(r.best);
      $('#win-record').classList.toggle('hidden', !r.newRecord);
      $('#btn-next').classList.toggle('hidden', !r.hasNext);
      $('#win-alldone').classList.toggle('hidden', r.hasNext);
      $('#win-stats').innerHTML = `<span>${I18n.t('statShots')}: <b>${r.shots}</b></span><span>${I18n.t('statLeft')}: <b>${r.left}</b></span>`
        + (r.combo >= 2 ? `<span>${I18n.t('statCombo')}: <b>x${r.combo}</b></span>` : '');
      $('#win-next').textContent = r.need > 0 ? `${I18n.t('needMore')}: ${fmt(r.need)}` : '';
      $('#win-nuke').classList.toggle('hidden', !r.nukeEarned);
      const stars = $$('#screen-win .stars i');
      stars.forEach((s) => s.classList.remove('on'));
      this.modal('win', true);
      const result = Game.sim;
      const visible = () => Game.sim === result && Game.state === 'win';
      const motion = !Game.reducedMotion;
      for (let i = 0; i < r.stars; i++) {
        const reveal = () => {
          if (!visible()) return;
          stars[i].classList.add('on');
          A.play('star', { i, gap: 0 });
        };
        if (motion) setTimeout(reveal, 110 + i * 170); else reveal();
      }
      const el = $('#win-score');
      if (!motion) { el.textContent = fmt(r.score); return; }
      const t0 = performance.now();
      const step = (now) => {
        if (!visible()) return;
        const k = Math.min(1, (now - t0) / 610);
        el.textContent = fmt(Math.round(r.score * (1 - (1 - k) ** 3)));
        if (k < 1) requestAnimationFrame(step);
      };
      requestAnimationFrame(step);
    },
    showLose(r) {
      this.checkProgressAch();
      $('#lose-left').textContent = `${I18n.t('enemiesLeft')}: ${r.left}`;
      $('#lose-tip').textContent = this.tip();
      this.modal('lose', true);
    },

    refreshBoosters() {
      const G = Game;
      $('#hud-birds').textContent = G.queue.length + (G.ready ? 1 : 0);
      ['sight', 'power', 'quake'].forEach((b) => {
        const el = $('#b-' + b), n = G.boosters[b];
        el.querySelector('i').textContent = n;
        el.classList.toggle('used', n <= 0 && !G.active[b]);
        el.classList.toggle('active', !!G.active[b]);
        el.classList.toggle('na', n > 0 && !G.active[b] && (b === 'sight' || b === 'power') && !G.ready);
      });
      this.refreshNukeBtn();
    },

    refreshNukeBtn() {
      const n = this.save.nukes || 0;
      const button = $('#nuke-btn');
      const inGame = !$('#hud').classList.contains('hidden');
      button.classList.toggle('hidden', !inGame || n <= 0 || Game.nuke.used);
      button.classList.toggle('stock', n > 0);
      $('#nuke-stock').textContent = n > 0 ? String(n) : '';
    },

    WORLDS: [{ key: 'world1', from: 0, to: 15, cols: 8 }, { key: 'world2', from: 15, to: 25, cols: 5 }],
    buildLevels(page) {
      const W = this.WORLDS;
      if (page == null) {
        const cur = Math.min(LEVELS.length, this.save.unlocked) - 1;
        page = Math.max(0, W.findIndex((w) => cur >= w.from && cur < w.to));
      }
      page = Math.max(0, Math.min(W.length - 1, page)); this.levelPage = page;
      const w = W[page];
      $('#world-name').textContent = I18n.t(w.key);
      $('#world-prev').classList.toggle('hidden', page === 0);
      $('#world-next').classList.toggle('hidden', page === W.length - 1);
      $$('.world-dots i').forEach((d, k) => d.classList.toggle('on', k === page));
      const grid = $('#level-grid'); grid.innerHTML = '';
      grid.style.setProperty('--level-columns', w.cols);
      LEVELS.forEach((lv, i) => {
        if (i < w.from || i >= w.to) return;
        const locked = i + 1 > this.save.unlocked;
        const st = this.save.stars[i] || 0;
        const b = document.createElement('button');
        b.className = `level-card ${THEME_CLASS[lv.theme] || 'w-noon'}` + (locked ? ' locked' : '') + (!locked && !st ? ' current' : '') + (st === 3 ? ' gold' : '');
        b.dataset.action = 'level'; b.dataset.level = i;
        b.innerHTML = `<span class="num">${i + 1}</span>${locked ? LOCK_SVG : ''}<span class="name">${I18n.t(lv.nameKey)}</span>`
          + `<span class="mini-stars">${[0, 1, 2].map((k) => `<i class="${k < st ? 'on' : ''}"></i>`).join('')}</span>`;
        grid.appendChild(b);
      });
    },

    refreshSettings() {
      const s = this.save.settings;
      $('#tg-music').classList.toggle('on', s.music);
      $('#tg-sfx').classList.toggle('on', s.sfx);
      $('#tg-vib').classList.toggle('on', s.vib !== false);
      $('#pz-music').classList.toggle('off', !s.music);
      $('#pz-sfx').classList.toggle('off', !s.sfx);
      $$('[data-action="lang"]').forEach((b) => b.classList.toggle('active', b.dataset.lang === I18n.lang));
      this._resetArmed = false; $('#btn-reset span').textContent = I18n.t('reset');
    },

    hudTitle() {
      if (!Game.def) return;
      $('#hud-level').textContent = `${I18n.t('level')} ${Game.levelIdx + 1} · ${I18n.t(Game.def.nameKey)}`;
    },

    updateGuide() {
      const active = Game.running() && Game.levelIdx === 0 && Game.shots === 0 && !Game.nuke.mode;
      const guide = $('#shot-guide');
      guide.classList.toggle('hidden', !active);
      if (!active) return;
      const touch = root.matchMedia('(pointer: coarse)').matches;
      let key = touch ? 'guideTouch' : 'guideDesktop';
      if (Game.drag?.keyboard) key = 'guideKeyboardAim';
      else if (Game.drag) key = Game.canRelease() ? 'guideRelease' : 'guidePull';
      const text = I18n.t(key);
      if (guide.textContent !== text) guide.textContent = text;
    },

    startLevel(i) {
      P.gameplayStop();
      this.closeModals();
      this.hideToast();
      this.show('game');
      Game.startLevel(i);
      this.hudTitle();
      this.updateGuide();
      Game.canvas.focus({ preventScroll: true });
      this.syncGameplay();
    },

    toMenu() {
      this.closeModals();
      Game.state = 'menu'; Game.sim = null; Game.parts = []; R.setTheme('noon'); A.setMood('day');
      P.gameplayStop();
      this.show('menu');
      this.updateGuide();
      $('[data-action=play]').focus({ preventScroll: true });
    },

    act(a, el) {
      const s = this.save;
      switch (a) {
        case 'play': this.startLevel(Math.min(LEVELS.length, s.unlocked) - 1); break;
        case 'levels': this.buildLevels(); this.show('levels'); break;
        case 'world-prev': this.buildLevels(this.levelPage - 1); A.play('click'); break;
        case 'world-next': this.buildLevels(this.levelPage + 1); A.play('click'); break;
        case 'settings': this.refreshSettings(); this.modal('settings', true); break;
        case 'ach': this.buildAch(); this.modal('ach', true); break;
        case 'close-ach': this.modal('ach', false); break;
        case 'wardrobe': this.buildSkins(); this.modal('wardrobe', true); break;
        case 'close-wardrobe': this.modal('wardrobe', false); break;
        case 'skin': {
          const sk = SKINS.find((x) => x.id === el.dataset.skin);
          if (this.totalStars() < sk.need) { this.toast('skinLocked'); return; }
          s.skin = sk.id; R.setSkin(sk.id); this.persist(); this.buildSkins(); break;
        }
        case 'back':
          if (!$('#screen-settings').classList.contains('hidden')) this.modal('settings', false);
          else this.show('menu');
          break;
        case 'level': {
          const i = +el.dataset.level;
          if (i + 1 > s.unlocked) { this.toast('locked'); return; }
          this.startLevel(i); break;
        }
        case 'toggle-music': s.settings.music = !s.settings.music; A.setMusic(s.settings.music); this.refreshSettings(); this.persist(); break;
        case 'toggle-sfx': s.settings.sfx = !s.settings.sfx; A.setSfx(s.settings.sfx); this.refreshSettings(); this.persist(); break;
        case 'toggle-vib': s.settings.vib = s.settings.vib === false; this.refreshSettings(); this.persist(); if (s.settings.vib) P.haptic('medium'); break;
        case 'reset':

          if (!this._resetArmed) { this._resetArmed = true; $('#btn-reset span').textContent = I18n.t('resetSure'); return; }
          s.unlocked = 1; s.stars = []; s.best = []; s.ach = {}; s.stats = {}; s.skin = 'none'; s.nukes = 0;
          R.setSkin('none'); this.persist(); this.refreshSettings(); this.refreshStars(); this.toast('resetDone');
          break;
        case 'lang':
          s.settings.lang = el.dataset.lang; I18n.set(s.settings.lang); this.refreshSettings(); this.persist(); this.hudTitle(); this.updateGuide();
          break;
        case 'pause':
          if (Game.state !== 'play') return;
          Game.paused = true; Game.drag = null; P.gameplayStop(); this.refreshSettings();
          $('#pause-tip').textContent = this.tip();
          this.modal('pause', true); this.updateGuide(); break;
        case 'resume': this.modal('pause', false); Game.paused = false; this.updateGuide(); Game.canvas.focus({ preventScroll: true }); this.syncGameplay(); break;
        case 'restart': this.startLevel(Game.levelIdx); break;
        case 'retry': this.startLevel(Game.levelIdx); break;
        case 'menu': this.toMenu(); break;
        case 'next': this.startLevel(Math.min(LEVELS.length - 1, Game.levelIdx + 1)); break;
        case 'booster':
          if (!Game.useBooster(el.dataset.b)) this.toast('boosterNA');
          break;
        case 'nuke': {
          if (!Game.canNuke() || !(s.nukes > 0)) return;
          s.nukes--; Game.startNukeAim(); this.persist();
          Game.canvas.focus({ preventScroll: true });
          break;
        }
      }
    },

    extPause(reason, on) {
      const has = Game.extPause.has(reason);
      if (on && !has) {
        Game.extPause.add(reason); Game.drag = null; A.pushPause();
      } else if (!on && has) {
        Game.extPause.delete(reason); A.popPause();
      }
      this.updateGuide();
      this.syncGameplay();
    },

    async boot() {
      const bar = $('.loader span');
      bar.style.width = '30%';
      await P.init();
      bar.style.width = '65%';
      const loaded = P.load();
      this.save = Object.assign({ unlocked: 1, stars: [], best: [], settings: {}, ach: {}, stats: {}, skin: 'none' }, loaded || {});
      this.save.settings = Object.assign({ music: true, sfx: true, vib: true, lang: null }, this.save.settings);
      ['ach', 'stats'].forEach((k) => { if (!this.save[k] || typeof this.save[k] !== 'object') this.save[k] = {}; });
      Game.save = this.save;
      R.setSkin(this.save.skin);

      I18n.set(this.save.settings.lang || P.lang());
      $('#load-tip').textContent = this.tip();
      A.musicOn = this.save.settings.music; A.sfxOn = this.save.settings.sfx;
      document.addEventListener('visibilitychange', () => this.extPause('hidden', document.hidden));
      root.addEventListener('pagehide', () => this.extPause('page', true));
      root.addEventListener('pageshow', () => this.extPause('page', false));

      document.addEventListener('click', (e) => {
        const b = e.target.closest('[data-action]');
        if (!b) return;
        A.unlock(); A.play('click');
        this.act(b.dataset.action, b);
      });

      const unlock = () => { A.unlock(); A.startMusic(); };
      root.addEventListener('pointerdown', unlock, { once: false, passive: true });
      root.addEventListener('touchend', unlock, { passive: true });
      root.addEventListener('keydown', unlock, { once: false });

      document.addEventListener('contextmenu', (e) => e.preventDefault());
      document.addEventListener('selectstart', (e) => e.preventDefault());
      document.addEventListener('dblclick', (e) => e.preventDefault());
      document.addEventListener('wheel', (e) => { if (e.ctrlKey) e.preventDefault(); }, { passive: false });

      Game.init($('#game'), this);
      bar.style.width = '100%';
      P.loadingReady();
      this.show('menu');
      $('[data-action=play]').focus({ preventScroll: true });
    },
  };

  root.YB.UI = UI;
  document.addEventListener('DOMContentLoaded', () => UI.boot());
})(window);
