/* CrazyGames HTML5 SDK adapter. Standalone previews use browser storage. */
(function (root) {
  'use strict';
  const SAVE_KEY = 'yoobird_save_v1';

  async function waitForSDK() {
    if (root.CrazyGames?.SDK) return root.CrazyGames.SDK;
    const script = document.getElementById('crazygames-sdk');
    if (!script || root.location.protocol === 'file:') return null;
    await new Promise((resolve) => {
      function done() {
        clearTimeout(timeout);
        script.removeEventListener('load', done);
        script.removeEventListener('error', done);
        resolve();
      }
      const timeout = setTimeout(done, 4000);
      script.addEventListener('load', done);
      script.addEventListener('error', done);
    });
    return root.CrazyGames?.SDK;
  }

  const P = {
    sdk: null,
    playing: false,

    async init() {
      const sdk = await waitForSDK();
      if (!sdk || sdk.environment === 'disabled') return;
      try {
        await sdk.init();
      } catch (error) {
        console.warn('CrazyGames SDK initialization failed.', error);
        return;
      }
      if (!['local', 'crazygames'].includes(sdk.environment)) return;
      this.sdk = sdk;
      this.event('loadingStart');
      try {
        const setAudio = (settings) => root.YB.Audio.setPlatformMuted(!!settings?.muteAudio);
        setAudio(sdk.game.settings);
        sdk.game.addSettingsChangeListener(setAudio);
      } catch (error) {
        console.warn('CrazyGames settings are unavailable.', error);
      }
    },

    lang() {
      return String(this.sdk?.user?.systemInfo?.locale || 'en').toLowerCase().split(/[-_]/)[0];
    },

    event(name) {
      try { this.sdk?.game[name]?.(); }
      catch (error) { console.warn('CrazyGames event failed:', name, error); }
    },

    loadingReady() { this.event('loadingStop'); },

    gameplayStart() {
      if (this.playing) return;
      this.playing = true;
      this.event('gameplayStart');
    },

    gameplayStop() {
      if (!this.playing) return;
      this.playing = false;
      this.event('gameplayStop');
    },

    load() {
      try {
        const store = this.sdk ? this.sdk.data : root.localStorage;
        return JSON.parse(store.getItem(SAVE_KEY) || 'null');
      } catch (error) {
        console.warn('Saved progress could not be read.', error);
        return null;
      }
    },

    save(data) {
      try {
        const store = this.sdk ? this.sdk.data : root.localStorage;
        store.setItem(SAVE_KEY, JSON.stringify(data));
      } catch (error) {
        console.warn('Progress could not be saved.', error);
      }
    },

    haptic(style) {
      const ua = navigator.userActivation;
      if (!navigator.vibrate || (ua && !ua.hasBeenActive) || !root.matchMedia('(pointer: coarse)').matches) return;
      navigator.vibrate(style === 'heavy' ? 40 : style === 'medium' ? 22 : 10);
    },
  };

  root.YB = Object.assign(root.YB || {}, { Platform: P });
})(window);
